(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/CustomTabBar" ], {
    "080c": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("19d4"), o = e("4a1c");
        for (var a in o) "default" !== a && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(a);
        e("1245");
        var r = e("2877"), c = Object(r["a"])(o["default"], u["a"], u["b"], !1, null, null, null);
        n["default"] = c.exports;
    },
    1245: function(t, n, e) {
        "use strict";
        var u = e("7713"), o = e.n(u);
        o.a;
    },
    "19d4": function(t, n, e) {
        "use strict";
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, o = [];
        e.d(n, "a", function() {
            return u;
        }), e.d(n, "b", function() {
            return o;
        });
    },
    "4a1c": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("8afa"), o = e.n(u);
        for (var a in u) "default" !== a && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(a);
        n["default"] = o.a;
    },
    7713: function(t, n, e) {},
    "8afa": function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = {
                name: "CustomTabBar",
                props: {
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    cur: {
                        type: Number,
                        default: 0
                    },
                    position: {
                        type: String,
                        default: "bottom"
                    },
                    styleType: {
                        type: String,
                        default: "style1"
                    },
                    fixedTop: {
                        type: Boolean,
                        default: !1
                    }
                },
                data: function() {
                    return {};
                },
                computed: {
                    getGlobalColor: function() {
                        return getApp().common.globle.color;
                    }
                },
                methods: {
                    tabChange: function(n, e, u) {
                        this.$emit("update:cur", e, u), "bottom" === this.position && this.cur !== e && t.reLaunch({
                            url: n
                        });
                    }
                }
            };
            n.default = e;
        }).call(this, e("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/CustomTabBar-create-component", {
    "yb_shopv2/component/CustomTabBar-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("080c"));
    }
}, [ [ "yb_shopv2/component/CustomTabBar-create-component" ] ] ]);