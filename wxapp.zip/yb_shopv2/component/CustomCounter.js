(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/CustomCounter" ], {
    "0f0a": function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("e96a"), a = n.n(u);
        for (var i in u) "default" !== i && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(i);
        e["default"] = a.a;
    },
    "2f1a": function(t, e, n) {
        "use strict";
        var u = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
        n.d(e, "a", function() {
            return u;
        }), n.d(e, "b", function() {
            return a;
        });
    },
    "40cc": function(t, e, n) {
        "use strict";
        var u = n("ffed"), a = n.n(u);
        a.a;
    },
    "57d3": function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("2f1a"), a = n("0f0a");
        for (var i in a) "default" !== i && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        n("40cc");
        var f = n("2877"), r = Object(f["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        e["default"] = r.exports;
    },
    e96a: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var u = {
            name: "CustomCounter",
            props: {
                value: {
                    type: Number,
                    default: 1
                }
            },
            methods: {
                reduce: function() {
                    1 !== this.value && this.$emit("input", this.value - 1);
                },
                plus: function() {
                    this.$emit("input", this.value + 1);
                },
                valueChange: function(t) {
                    this.$emit("input", t.target.value);
                }
            }
        };
        e.default = u;
    },
    ffed: function(t, e, n) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/CustomCounter-create-component", {
    "yb_shopv2/component/CustomCounter-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("57d3"));
    }
}, [ [ "yb_shopv2/component/CustomCounter-create-component" ] ] ]);