(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/IntegralDistributionList" ], {
    "35f8": function(t, n, e) {
        "use strict";
        e.r(n);
        var o = e("91aa"), i = e.n(o);
        for (var a in o) "default" !== a && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(a);
        n["default"] = i.a;
    },
    "91aa": function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = r(e("3b18")), i = r(e("c8bc")), a = e("21b4");
            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var u = function() {
                return e.e("yb_shopv2/component/CustomNoData").then(e.bind(null, "8a57"));
            }, s = {
                data: function() {
                    return {
                        info: [],
                        pageHeight: "auto",
                        pageIndex: 0,
                        params: {
                            distribution_id: getApp().distribution ? getApp().distribution.id : "",
                            page: 1
                        },
                        requestUrl: "",
                        nodata: !1
                    };
                },
                filters: {
                    formatAccount: function(t) {
                        return t && "string" === typeof t ? t.substr(t.length - 4) : t;
                    }
                },
                created: function() {},
                components: {
                    nodata: u
                },
                mixins: [ o.default, i.default ],
                methods: {
                    page_onLoad: function(n) {
                        var e = this;
                        t.showLoading({
                            title: "加载中"
                        }), e.pageIndex = Number(n.index);
                        var o = {
                            0: "我的团队",
                            1: "我的客户",
                            2: "佣金明细",
                            3: "积分明细",
                            4: "提现明细",
                            5: "我的银行卡"
                        };
                        e.title = o[e.pageIndex], 0 == e.pageIndex && (e.requestUrl = "Distribution_getTeamList"), 
                        1 == e.pageIndex && (e.requestUrl = "Distribution_getCustomerList"), 2 == e.pageIndex && (e.requestUrl = "Distribution_getCommissionList"), 
                        3 == e.pageIndex && (e.requestUrl = "Integralmall_getIntegralLog"), 4 == e.pageIndex && (e.requestUrl = "Distribution_getWithdrawList"), 
                        5 == e.pageIndex && (e.requestUrl = "Distribution_getWithdrawMethodList"), t.$on("addCard", function() {
                            e.requestUrl = "Distribution_getWithdrawMethodList", e.getInfo(), console.log("新添加银行卡");
                        }), e.getInfo();
                    },
                    page_onPullDownRefresh: function() {
                        this.params.page = 1, this.getInfo();
                    },
                    page_onReachBottom: function() {
                        5 != this.pageIndex && (this.nodata || (this.params.page += 1, this.getInfo()));
                    },
                    getInfo: function() {
                        var n = this, e = n.params;
                        3 == n.pageIndex && (e = {
                            user_id: getApp().user.userid
                        }), 1 == n.params.page && (n.info = []), getApp().Req.get(n.requestUrl, e, function(e) {
                            n.info = n.info.concat(e.data), 0 === e.data.length ? n.nodata = !0 : n.nodata = !1, 
                            t.stopPullDownRefresh(), t.hideLoading(), console.log(e, "获取信息成功");
                        }, function(e) {
                            n.nodata = !0, t.stopPullDownRefresh(), t.hideLoading(), t.showToast({
                                icon: "none",
                                title: "获取信息失败，请稍后再试"
                            });
                        });
                    },
                    delAccount: function(n) {
                        var e = this;
                        t.showModal({
                            title: "确定要删除此账户吗？",
                            success: function(t) {
                                t.confirm ? getApp().Req.get("Distribution_delWithdrawMethod", {
                                    id: n
                                }, function(t) {
                                    e.info = e.info.filter(function(t) {
                                        return t.id != n;
                                    }), 0 === e.info.length && (e.nodata = !0), (0, a.success)("删除成功");
                                }, function(t) {
                                    (0, a.warning)("删除失败");
                                }) : t.cancel && console.log("用户点击取消");
                            }
                        });
                    }
                }
            };
            n.default = s;
        }).call(this, e("543d")["default"]);
    },
    bde9: function(t, n, e) {
        "use strict";
        e.r(n);
        var o = e("e9cc"), i = e("35f8");
        for (var a in i) "default" !== a && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(a);
        e("c51b");
        var r = e("2877"), u = Object(r["a"])(i["default"], o["a"], o["b"], !1, null, null, null);
        n["default"] = u.exports;
    },
    c51b: function(t, n, e) {
        "use strict";
        var o = e("f0f6"), i = e.n(o);
        i.a;
    },
    e9cc: function(t, n, e) {
        "use strict";
        var o = function() {
            var t = this, n = t.$createElement, e = (t._self._c, t.__map(t.info, function(n, e) {
                var o = t._f("formatAccount")(n.account);
                return {
                    $orig: t.__get_orig(n),
                    f0: o
                };
            }));
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, i = [];
        e.d(n, "a", function() {
            return o;
        }), e.d(n, "b", function() {
            return i;
        });
    },
    f0f6: function(t, n, e) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/IntegralDistributionList-create-component", {
    "yb_shopv2/component/IntegralDistributionList-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("bde9"));
    }
}, [ [ "yb_shopv2/component/IntegralDistributionList-create-component" ] ] ]);