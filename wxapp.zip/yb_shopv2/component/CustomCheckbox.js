(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/CustomCheckbox" ], {
    2174: function(e, t, n) {},
    "50d2": function(e, t, n) {
        "use strict";
        n.r(t);
        var u = n("a40e"), a = n("a48b");
        for (var c in a) "default" !== c && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(c);
        n("5dc0");
        var i = n("2877"), o = Object(i["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        t["default"] = o.exports;
    },
    5938: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = {
            name: "CustomCheckbox",
            props: {
                value: {
                    type: [ String, Number, Boolean ],
                    default: ""
                },
                checkedBox: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                label: {
                    type: String,
                    default: ""
                },
                banner: {
                    type: Boolean,
                    default: !1
                }
            },
            computed: {
                checked: function() {
                    return this.checkedBox.indexOf(this.value);
                }
            },
            methods: {
                checkboxClick: function() {
                    if ("boolean" !== typeof this.value) {
                        var e = JSON.parse(JSON.stringify(this.checkedBox));
                        -1 !== this.checked ? e.splice(this.checked, 1) : e.push(this.value), this.$emit("input", e);
                    } else this.$emit("allChecked", !this.value);
                }
            }
        };
        t.default = u;
    },
    "5dc0": function(e, t, n) {
        "use strict";
        var u = n("2174"), a = n.n(u);
        a.a;
    },
    a40e: function(e, t, n) {
        "use strict";
        var u = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, a = [];
        n.d(t, "a", function() {
            return u;
        }), n.d(t, "b", function() {
            return a;
        });
    },
    a48b: function(e, t, n) {
        "use strict";
        n.r(t);
        var u = n("5938"), a = n.n(u);
        for (var c in u) "default" !== c && function(e) {
            n.d(t, e, function() {
                return u[e];
            });
        }(c);
        t["default"] = a.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/CustomCheckbox-create-component", {
    "yb_shopv2/component/CustomCheckbox-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("50d2"));
    }
}, [ [ "yb_shopv2/component/CustomCheckbox-create-component" ] ] ]);