(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/non_native_tabbar" ], {
    "0276": function(t, a, n) {
        "use strict";
        var i = n("2ee2"), e = n.n(i);
        e.a;
    },
    "03c02": function(t, a, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var n = {
                props: {
                    now_index: 0
                },
                data: function() {
                    return {
                        tabbar: {},
                        list: [],
                        nativeTabbar: !1
                    };
                },
                methods: {
                    redirectToPage: function(a) {
                        a !== this.now_index && t.$emit("tabbar_index", a);
                    },
                    initdata: function() {
                        var t = this, a = getApp();
                        t.nativeTabbar = a.siteInfo.native_tabbar || !1 === a.tabbar.show, t.nativeTabbar || (a.tabbar.list ? (t.tabbar = a.tabbar, 
                        t.list = a.tabbar.list) : a.getTabbarData(function() {
                            t.tabbar = a.tabbar, t.list = a.tabbar.list;
                        }));
                    }
                },
                created: function() {
                    this.initdata(), t.$on("COMMON_COMPLETE", this.initdata);
                },
                destroyed: function() {
                    t.$off("COMMON_COMPLETE", this.initdata);
                }
            };
            a.default = n;
        }).call(this, n("543d")["default"]);
    },
    "2ee2": function(t, a, n) {},
    4376: function(t, a, n) {
        "use strict";
        n.r(a);
        var i = n("03c02"), e = n.n(i);
        for (var r in i) "default" !== r && function(t) {
            n.d(a, t, function() {
                return i[t];
            });
        }(r);
        a["default"] = e.a;
    },
    afd2: function(t, a, n) {
        "use strict";
        var i = function() {
            var t = this, a = t.$createElement;
            t._self._c;
        }, e = [];
        n.d(a, "a", function() {
            return i;
        }), n.d(a, "b", function() {
            return e;
        });
    },
    bba1: function(t, a, n) {
        "use strict";
        n.r(a);
        var i = n("afd2"), e = n("4376");
        for (var r in e) "default" !== r && function(t) {
            n.d(a, t, function() {
                return e[t];
            });
        }(r);
        n("0276");
        var o = n("2877"), u = Object(o["a"])(e["default"], i["a"], i["b"], !1, null, null, null);
        a["default"] = u.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/non_native_tabbar-create-component", {
    "yb_shopv2/component/non_native_tabbar-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("bba1"));
    }
}, [ [ "yb_shopv2/component/non_native_tabbar-create-component" ] ] ]);