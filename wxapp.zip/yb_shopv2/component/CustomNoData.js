(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/CustomNoData" ], {
    3870: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = {
            name: "CustomNoData",
            props: {
                title: {
                    type: String,
                    default: "暂无数据"
                }
            }
        };
        n.default = u;
    },
    "5a21": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("3870"), a = e.n(u);
        for (var r in u) "default" !== r && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(r);
        n["default"] = a.a;
    },
    7993: function(t, n, e) {},
    "8a57": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("e65b"), a = e("5a21");
        for (var r in a) "default" !== r && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        e("e780");
        var o = e("2877"), c = Object(o["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        n["default"] = c.exports;
    },
    e65b: function(t, n, e) {
        "use strict";
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, a = [];
        e.d(n, "a", function() {
            return u;
        }), e.d(n, "b", function() {
            return a;
        });
    },
    e780: function(t, n, e) {
        "use strict";
        var u = e("7993"), a = e.n(u);
        a.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/CustomNoData-create-component", {
    "yb_shopv2/component/CustomNoData-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("8a57"));
    }
}, [ [ "yb_shopv2/component/CustomNoData-create-component" ] ] ]);