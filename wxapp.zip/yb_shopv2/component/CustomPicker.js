(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/CustomPicker" ], {
    3012: function(e, t, i) {
        "use strict";
        var n = function() {
            var e = this, t = e.$createElement, i = (e._self._c, e.formatValue(e.value));
            e.$mp.data = Object.assign({}, {
                $root: {
                    m0: i
                }
            });
        }, r = [];
        i.d(t, "a", function() {
            return n;
        }), i.d(t, "b", function() {
            return r;
        });
    },
    "4c4b": function(e, t, i) {
        "use strict";
        i.r(t);
        var n = i("513f"), r = i.n(n);
        for (var a in n) "default" !== a && function(e) {
            i.d(t, e, function() {
                return n[e];
            });
        }(a);
        t["default"] = r.a;
    },
    "513f": function(e, t, i) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var n = i("b1b6"), r = function() {
            return Promise.all([ i.e("common/vendor"), i.e("components/w-picker/w-picker") ]).then(i.bind(null, "b76a"));
        }, a = {
            name: "CustomPicker",
            props: {
                value: {
                    type: [ String, Array, Number ],
                    default: ""
                },
                mode: {
                    type: String,
                    default: "date"
                },
                range: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                setPlaceholder: {
                    type: String,
                    default: ""
                },
                code: {
                    type: [ Array, Number, String ],
                    default: function() {
                        return [];
                    }
                }
            },
            data: function() {
                return {
                    cityData: [],
                    pickerData: [],
                    pickerValueKey: [],
                    pickerMode: "",
                    deep: !1,
                    active: {},
                    dateArray: [],
                    init: !0,
                    defaultCode: []
                };
            },
            watch: {
                defaultCode: {
                    handler: function(e) {
                        console.log(e, "值改变了！！！！！！！！！！！！！！！！！！！");
                    },
                    deep: !0
                }
            },
            computed: {
                globalColor: function() {
                    return getApp().common.globle.color;
                }
            },
            mounted: function() {
                this.getCityData(), this.initConfig();
            },
            components: {
                WPicker: r
            },
            methods: {
                initConfig: function() {
                    var e = this;
                    if ("date" === this.mode) this.pickerData = this.range, this.pickerValueKey = this.value.split("-"), 
                    this.deep = !1; else if ("region" === this.mode) "number" === typeof this.code || "string" === typeof this.code ? this.$set(this, "defaultCode", [ String(this.code).substr(0, 2), String(this.code).substr(0, 4), String(this.code) ]) : Array.isArray(this.code) && (1 === this.code.length ? this.$set(this, "defaultCode", [ String(this.code[0]).substr(0, 2), String(this.code[0]).substr(0, 4), String(this.code[0]) ]) : 3 === this.code.length && this.$set(this, "defaultCode", [ String(this.code[2]).substr(0, 2), String(this.code[2]).substr(0, 4), String(this.code[2]) ])); else {
                        var t = this.range.findIndex(function(t) {
                            return t.value === e.value;
                        });
                        this.pickerData = this.range, this.pickerValueKey = -1 === t ? [ 0 ] : [ t ], this.deep = !1;
                    }
                    console.log(this.defaultCode, "defaultdefaultdefaultdefaultdefaultdefaultdefaultdefaultdefaultdefaultdefaultdefaultdefaultdefaultdefault"), 
                    this.$nextTick(function() {
                        e.init = !1;
                    });
                },
                formatValue: function(e) {
                    if ("date" === this.mode) return e || this.setPlaceholder;
                    if ("region" === this.mode) return e.filter(function(e) {
                        return e;
                    }).length ? e.join(" ") : this.setPlaceholder;
                    if (this.range && this.range.length) {
                        var t = this.range.find(function(t) {
                            return t.value === e;
                        });
                        return t ? t.label : this.setPlaceholder;
                    }
                    return e;
                },
                handlerPickerShow: function() {
                    this.$refs.wPicker.show();
                },
                pickerConfirm: function(e) {
                    var t = this;
                    console.log(e, "确认！！！！！！！！！！！！"), "region" === this.mode ? setTimeout(function() {
                        var i = t.active.checkValue ? t.active.checkValue : e.checkValue;
                        t.$emit("change", {
                            detail: {
                                value: t.active.checkArr ? t.active.checkArr : e.checkArr,
                                code: i.map(function(e) {
                                    return 2 === e.length ? String(e) + "0000" : 4 === e.length ? String(e) + "00" : e;
                                })
                            }
                        });
                    }, 500) : "date" === this.mode ? setTimeout(function() {
                        t.$emit("change", {
                            detail: {
                                value: t.active.result ? t.active.result : e.result
                            }
                        });
                    }, 500) : (console.log(e.defaultVal), setTimeout(function() {
                        t.$emit("change", {
                            detail: {
                                value: t.active.result ? t.active.defaultVal[0] : e.defaultVal[0]
                            }
                        });
                    }, 500));
                },
                pickerChange: function(e) {
                    this.active = e;
                },
                getCityData: function() {
                    var e = this;
                    (0, n.get)("Member_getArea", {
                        user_id: getApp().user.userid
                    }).then(function(t) {
                        e.cityData = t.data;
                    });
                },
                pickerCancel: function() {
                    this.$refs.wPicker.hide();
                }
            }
        };
        t.default = a;
    },
    5605: function(e, t, i) {
        "use strict";
        i.r(t);
        var n = i("3012"), r = i("4c4b");
        for (var a in r) "default" !== a && function(e) {
            i.d(t, e, function() {
                return r[e];
            });
        }(a);
        i("fb05");
        var u = i("2877"), o = Object(u["a"])(r["default"], n["a"], n["b"], !1, null, null, null);
        t["default"] = o.exports;
    },
    "7cf3": function(e, t, i) {},
    fb05: function(e, t, i) {
        "use strict";
        var n = i("7cf3"), r = i.n(n);
        r.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/CustomPicker-create-component", {
    "yb_shopv2/component/CustomPicker-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("5605"));
    }
}, [ [ "yb_shopv2/component/CustomPicker-create-component" ] ] ]);