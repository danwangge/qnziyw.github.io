(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/floatbtn" ], {
    "08e2": function(t, e, i) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = {
                data: function() {
                    return {
                        init: {},
                        opentype: {
                            service: "contact"
                        }
                    };
                },
                watch: {},
                methods: {
                    gfbtn_click: function(e) {
                        switch (e) {
                          case "service":
                            if ("contact" === this.opentype.service) return;
                            var i = "";
                            i = 1 === this.init.service.type ? "/yb_shopv2/native/all/index?type=chat&type_name=客服&id=0&url=&title=客服" : "/yb_shopv2/native/all/index?type=web&type_name=在线客服&url=" + this.init.service.value.trim() + "&title=在线客服", 
                            console.log(i), t.navigateTo({
                                url: i
                            });
                            break;

                          case "tel":
                            var n = this.init.tel.value.trim();
                            t.makePhoneCall({
                                phoneNumber: n
                            });
                            break;

                          default:
                            break;
                        }
                    },
                    initdata: function() {
                        getApp().common.float && (this.init = getApp().common.float, this.init && this.init.service && (this.init.service.value.trim().length > 0 || this.init.service.type > 0) && (this.opentype.service = ""));
                    }
                },
                created: function() {
                    this.initdata(), t.$on("COMMON_COMPLETE", this.initdata);
                },
                destroyed: function() {
                    t.$off("COMMON_COMPLETE", this.initdata);
                }
            };
            e.default = i;
        }).call(this, i("543d")["default"]);
    },
    "115e": function(t, e, i) {
        "use strict";
        var n = i("261a"), a = i.n(n);
        a.a;
    },
    "261a": function(t, e, i) {},
    5926: function(t, e, i) {
        "use strict";
        i.r(e);
        var n = i("ee17"), a = i("fd00");
        for (var r in a) "default" !== r && function(t) {
            i.d(e, t, function() {
                return a[t];
            });
        }(r);
        i("115e");
        var c = i("2877"), o = Object(c["a"])(a["default"], n["a"], n["b"], !1, null, null, null);
        e["default"] = o.exports;
    },
    ee17: function(t, e, i) {
        "use strict";
        var n = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
        i.d(e, "a", function() {
            return n;
        }), i.d(e, "b", function() {
            return a;
        });
    },
    fd00: function(t, e, i) {
        "use strict";
        i.r(e);
        var n = i("08e2"), a = i.n(n);
        for (var r in n) "default" !== r && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(r);
        e["default"] = a.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/floatbtn-create-component", {
    "yb_shopv2/component/floatbtn-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("5926"));
    }
}, [ [ "yb_shopv2/component/floatbtn-create-component" ] ] ]);