(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/CustomCountDown" ], {
    "1a6c": function(t, e, i) {
        "use strict";
        var n = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, r = [];
        i.d(e, "a", function() {
            return n;
        }), i.d(e, "b", function() {
            return r;
        });
    },
    "452c": function(t, e, i) {},
    5728: function(t, e, i) {
        "use strict";
        i.r(e);
        var n = i("5d03"), r = i.n(n);
        for (var a in n) "default" !== a && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(a);
        e["default"] = r.a;
    },
    "5d03": function(t, e, i) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var n = {
            name: "CustomCountDown",
            props: {
                title: {
                    type: [ String, Boolean ],
                    default: "距结束"
                },
                time: {
                    type: [ String, Number ],
                    default: ""
                },
                textColor: {
                    type: String,
                    default: "#ffffff"
                },
                bgColor: {
                    type: String,
                    default: "#FF5245"
                },
                baseColor: {
                    type: String,
                    default: "rgba(153,153,153,1)"
                },
                fontSize: {
                    type: String,
                    default: "20rpx"
                }
            },
            data: function() {
                return {
                    privateTime: 0,
                    showArray: [],
                    timer: null,
                    init: !0
                };
            },
            mounted: function() {
                this.init = !1, this.initTime();
            },
            watch: {
                time: function(t) {
                    this.init = !1, this.initTime();
                }
            },
            destroyed: function() {
                clearInterval(this.timer);
            },
            methods: {
                initTime: function() {
                    var t = this;
                    clearInterval(this.timer), this.privateTime = "string" === typeof this.time || 13 === String(this.time).length ? (new Date(this.time).getTime() - new Date().getTime()) / 1e3 : this.time / 1e3, 
                    this.privateTime <= 0 ? this.privateTime = 0 : (this.showArray = this.computedNowToDate(this.privateTime), 
                    this.timer = setInterval(function() {
                        if (t.privateTime--, t.privateTime <= 0) return t.privateTime = 0, void clearInterval(t.timer);
                        t.showArray = t.computedNowToDate(t.privateTime);
                    }, 1e3));
                },
                computedNowToDate: function(t) {
                    var e = t;
                    if (e <= 0) return !1;
                    this.privateTime || (this.privateTime = e);
                    var i = parseInt(String(e % 60)), n = parseInt(String(e / 60 % 60)), r = parseInt(String(e / 3600 % 24)), a = parseInt(String(e / 86400));
                    return i = i < 10 ? "0" + i : i, n = n < 10 ? "0" + n : n, r = r < 10 ? "0" + r : r, 
                    [ a, r, n, i ];
                }
            }
        };
        e.default = n;
    },
    "91f3": function(t, e, i) {
        "use strict";
        var n = i("452c"), r = i.n(n);
        r.a;
    },
    ad8f: function(t, e, i) {
        "use strict";
        i.r(e);
        var n = i("1a6c"), r = i("5728");
        for (var a in r) "default" !== a && function(t) {
            i.d(e, t, function() {
                return r[t];
            });
        }(a);
        i("91f3");
        var o = i("2877"), u = Object(o["a"])(r["default"], n["a"], n["b"], !1, null, null, null);
        e["default"] = u.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/CustomCountDown-create-component", {
    "yb_shopv2/component/CustomCountDown-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("ad8f"));
    }
}, [ [ "yb_shopv2/component/CustomCountDown-create-component" ] ] ]);