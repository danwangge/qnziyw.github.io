(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/CustomNewUser" ], {
    "0ac2": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("12e7"), u = e("1fad");
        for (var i in u) "default" !== i && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(i);
        e("1689");
        var a = e("2877"), r = Object(a["a"])(u["default"], o["a"], o["b"], !1, null, null, null);
        t["default"] = r.exports;
    },
    "12e7": function(n, t, e) {
        "use strict";
        var o = function() {
            var n = this, t = n.$createElement;
            n._self._c;
        }, u = [];
        e.d(t, "a", function() {
            return o;
        }), e.d(t, "b", function() {
            return u;
        });
    },
    1689: function(n, t, e) {
        "use strict";
        var o = e("d75e"), u = e.n(o);
        u.a;
    },
    "1fad": function(n, t, e) {
        "use strict";
        e.r(t);
        var o = e("5c09"), u = e.n(o);
        for (var i in o) "default" !== i && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        t["default"] = u.a;
    },
    "5c09": function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = function() {
            return Promise.all([ e.e("common/vendor"), e.e("yb_shopv2/module/ModuleCoupon") ]).then(e.bind(null, "5950"));
        }, u = {
            name: "CustomNewUser",
            props: {
                visible: {
                    type: Boolean,
                    default: !1
                },
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                }
            },
            data: function() {
                return {
                    show: !1,
                    animation: !0
                };
            },
            watch: {
                visible: function(n) {
                    var t = this;
                    n && (this.show = !0, this.$nextTick(function() {
                        t.animation = !1;
                    }));
                }
            },
            mounted: function() {},
            components: {
                ModuleCoupon: o
            },
            methods: {
                hide: function() {
                    var n = this;
                    this.animation = !0, this.$nextTick(function() {
                        n.show = !1, setTimeout(function() {
                            n.$emit("update:visible", !1);
                        }, 300);
                    });
                }
            }
        };
        t.default = u;
    },
    d75e: function(n, t, e) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/CustomNewUser-create-component", {
    "yb_shopv2/component/CustomNewUser-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("0ac2"));
    }
}, [ [ "yb_shopv2/component/CustomNewUser-create-component" ] ] ]);