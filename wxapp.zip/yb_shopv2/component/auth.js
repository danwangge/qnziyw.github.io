(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/auth" ], {
    "1a25": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("565b"), i = n.n(o);
        for (var s in o) "default" !== s && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(s);
        t["default"] = i.a;
    },
    "565b": function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                props: {
                    type: "",
                    page_info: {}
                },
                data: function() {
                    return {
                        auth_item: {},
                        button_type: "",
                        button_scope: "",
                        auth_show: !1,
                        user: {},
                        inited: !1
                    };
                },
                watch: {
                    type: {
                        handler: function() {
                            this.checkAuthShow();
                        },
                        immediate: !0,
                        deep: !0
                    },
                    page_info: {
                        handler: function() {
                            this.inited = !1, this.checkAuthShow();
                        },
                        immediate: !0,
                        deep: !0
                    },
                    user: {
                        handler: function() {
                            this.inited = !1, this.checkAuthShow();
                        },
                        immediate: !0,
                        deep: !0
                    }
                },
                methods: {
                    submit_click: function() {
                        console.log("submit_click !!!!!!");
                    },
                    authCallback: function(t) {
                        console.log("onGetAuthorize: ", t), this.auth_show = !1;
                        var n = this;
                        "login" === this.type ? my.getOpenUserInfo({
                            fail: function(t) {
                                e.showToast({
                                    icon: "none",
                                    duration: 3e3,
                                    title: "授权失败,请在支付宝小程序开发者中心检查是否有对应权限"
                                });
                            },
                            success: function(t) {
                                var o = JSON.parse(t.response).response;
                                if ("10000" !== o.code) e.showToast({
                                    icon: "none",
                                    duration: 3e3,
                                    title: "授权失败,请在支付宝小程序开发者中心检查是否有对应权限"
                                }); else {
                                    var i = {
                                        detail: {
                                            errMsg: "getUserInfo:ok"
                                        }
                                    };
                                    o.avatarUrl = o.avatar, i.detail.userInfo = o, n.getUserInfo(i);
                                }
                            }
                        }) : "phone" === this.type && my.getPhoneNumber({
                            success: function(t) {
                                console.log("phone res: ", t);
                                var n = JSON.parse(t.response).response;
                                console.log("phone: ", n);
                                var o = getApp().user;
                                getApp().Req.get("user_getPhone", {
                                    userid: o.userid,
                                    phonedata: n
                                }, function(t) {
                                    console.log("getPhone: ", t), t = t.info, "10000" === t.code ? (o.phone = t.mobile, 
                                    e.setStorageSync("user", o)) : e.showToast({
                                        icon: "none",
                                        duration: 3e3,
                                        title: t.subMsg || "授权失败,请在支付宝小程序开发者中心检查是否有对应权限"
                                    });
                                });
                            },
                            fail: function(t) {
                                e.showToast({
                                    icon: "none",
                                    duration: 3e3,
                                    title: "授权失败,请在支付宝小程序开发者中心检查是否有对应权限"
                                });
                            }
                        });
                    },
                    authError: function(e) {
                        console.log("onAuthError: ", e);
                    },
                    getUserInfo: function(t) {
                        this.auth_show = !1;
                        var n = "page" === this.page_info.type ? "page_" + this.page_info.id : this.page_info.type, o = this.page_info.title ? this.page_info.title : "";
                        if ("getUserInfo:ok" === t.detail.errMsg) {
                            var i = t.detail.userInfo;
                            getApp().user.user_headimg = i.avatarUrl, getApp().user.nick_name = i.nickName, 
                            e.setStorageSync("user", getApp().user);
                            var s = e.getStorageSync("user"), a = s.userid, u = getApp().platForm;
                            getApp().Req.get("user_authlog", {
                                userid: a,
                                auth_page_key: n,
                                auth_page_name: o,
                                platForm: u
                            }, function(e) {
                                var t = getApp().user;
                                getApp().Req.get("user_update", {
                                    userid: t.userid,
                                    image: t.user_headimg,
                                    nick: t.nick_name
                                }).then(function(e) {
                                    e.info && e.info.user_headimg && (getApp().user.user_headimg = e.info.user_headimg);
                                });
                            });
                        }
                    },
                    getPhoneNumber: function(t) {
                        if (console.log("getPhoneNumber: ", t), this.auth_show = !1, "getPhoneNumber:ok" === t.detail.errMsg) {
                            var n = getApp().user, o = t.detail.encryptedData, i = t.detail.iv;
                            getApp().Req.get("user_getPhone", {
                                userid: n.userid,
                                phonedata: o,
                                iv: i
                            }, function(t) {
                                console.log("getPhone: ", t), 0 === t.code ? (n.phone = t.info, e.setStorageSync("user", n)) : e.showToast({
                                    icon: "none",
                                    duration: 3e3,
                                    title: "授权失败,请检查小程序参数是否配置正确或小程序是否有对应权限"
                                });
                            });
                        } else {
                            var s = 6 == getApp().platForm ? "暂不支持" : "授权失败,请检查小程序参数是否配置正确或小程序是否有对应权限";
                            e.showToast({
                                icon: "none",
                                duration: 3e3,
                                title: s
                            });
                        }
                    },
                    cancelAuth: function() {
                        this.auth_show = !1, console.log("取消显示");
                    },
                    checkAuthShow: function() {
                        if (console.log(this.type, "this.type"), console.log(getApp().common.login_auth, "登录授权"), 
                        console.log(getApp().common.phone_auth, "手机号授权"), "" !== this.type && getApp().common.login_auth && getApp().common.phone_auth && ("" === this.button_type && ("login" === this.type ? (this.auth_item = getApp().common.login_auth, 
                        this.button_type = "getUserInfo") : "phone" === this.type && (this.auth_item = getApp().common.phone_auth, 
                        this.button_type = "getPhoneNumber")), getApp().auth.auth_phone_page && getApp().auth.auth_user_page && this.page_info && this.page_info.type && !this.inited)) {
                            var e = getApp().auth.auth_user_page, t = getApp().auth.auth_phone_page, n = "page" === this.page_info.type ? "page_" + this.page_info.id : this.page_info.type, o = getApp().user, i = !1;
                            "login" === this.type && (i = e.indexOf(n) >= 0, o && o.user_headimg && o.user_headimg.length > 0 && o.nick_name && o.nick_name.length > 0 && (i = !1)), 
                            "phone" === this.type && (i = t.indexOf(n) >= 0, o && o.phone && o.phone.length > 0 && (i = !1)), 
                            this.auth_show = i, this.inited = !0;
                        }
                    }
                },
                created: function() {
                    getApp().user && (this.user = getApp().user), this.checkAuthShow();
                },
                mounted: function() {
                    getApp().user && (this.user = getApp().user), this.checkAuthShow();
                }
            };
            t.default = n;
        }).call(this, n("543d")["default"]);
    },
    "8b3d": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("e430"), i = n("1a25");
        for (var s in i) "default" !== s && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(s);
        n("c73d");
        var a = n("2877"), u = Object(a["a"])(i["default"], o["a"], o["b"], !1, null, null, null);
        t["default"] = u.exports;
    },
    "9c74": function(e, t, n) {},
    c73d: function(e, t, n) {
        "use strict";
        var o = n("9c74"), i = n.n(o);
        i.a;
    },
    e430: function(e, t, n) {
        "use strict";
        var o = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, i = [];
        n.d(t, "a", function() {
            return o;
        }), n.d(t, "b", function() {
            return i;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/auth-create-component", {
    "yb_shopv2/component/auth-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("8b3d"));
    }
}, [ [ "yb_shopv2/component/auth-create-component" ] ] ]);