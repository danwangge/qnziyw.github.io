(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/component/CustomButton" ], {
    "088b": function(t, n, u) {
        "use strict";
        u.r(n);
        var e = u("232c"), o = u("0ca3");
        for (var r in o) "default" !== r && function(t) {
            u.d(n, t, function() {
                return o[t];
            });
        }(r);
        u("59d9");
        var a = u("2877"), c = Object(a["a"])(o["default"], e["a"], e["b"], !1, null, null, null);
        n["default"] = c.exports;
    },
    "0ca3": function(t, n, u) {
        "use strict";
        u.r(n);
        var e = u("77b1"), o = u.n(e);
        for (var r in e) "default" !== r && function(t) {
            u.d(n, t, function() {
                return e[t];
            });
        }(r);
        n["default"] = o.a;
    },
    "232c": function(t, n, u) {
        "use strict";
        var e = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, o = [];
        u.d(n, "a", function() {
            return e;
        }), u.d(n, "b", function() {
            return o;
        });
    },
    "59d9": function(t, n, u) {
        "use strict";
        var e = u("7199"), o = u.n(e);
        o.a;
    },
    7199: function(t, n, u) {},
    "77b1": function(t, n, u) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var e = {
            name: "CustomButton",
            props: {
                type: {
                    type: String,
                    default: ""
                },
                title: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {};
            },
            methods: {
                buttonClick: function(t) {
                    this.$emit("click", t);
                }
            }
        };
        n.default = e;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/component/CustomButton-create-component", {
    "yb_shopv2/component/CustomButton-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("088b"));
    }
}, [ [ "yb_shopv2/component/CustomButton-create-component" ] ] ]);