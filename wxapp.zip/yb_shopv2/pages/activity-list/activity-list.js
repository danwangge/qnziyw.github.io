(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/activity-list/activity-list" ], {
    "0bb5": function(t, e, i) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = r(i("c8bc")), n = r(i("3b18")), s = r(i("ffc5")), u = i("b1b6");
            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var l = function() {
                return i.e("yb_shopv2/component/CustomTabBar").then(i.bind(null, "080c"));
            }, o = function() {
                return Promise.all([ i.e("common/vendor"), i.e("yb_shopv2/module/ModuleGoodList") ]).then(i.bind(null, "47e1"));
            }, c = {
                name: "seckill-list",
                props: {
                    classId: {
                        type: Number,
                        default: 0
                    },
                    activeType: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        tabBarList: [ {
                            id: "1",
                            title: "正在进行"
                        }, {
                            id: "2",
                            title: "已结束"
                        } ],
                        list: [],
                        page_path: "pages/seckill-list/seckill-list",
                        timer: null,
                        statusCur: 0,
                        activityMap: {
                            seckill: {
                                buttonText: "去秒杀",
                                api: "Seckill_getSeckillList"
                            },
                            group: {
                                buttonText: "去拼团",
                                api: "Group_getGroupList"
                            },
                            bargain: {
                                buttonText: "去砍价",
                                api: "Bargain_getBargainList"
                            }
                        }
                    };
                },
                mixins: [ a.default, n.default, s.default ],
                components: {
                    ModuleGoodList: o,
                    CustomTabBar: l
                },
                mounted: function() {
                    this.getPageData();
                },
                methods: {
                    page_onPullDownRefresh: function() {
                        this.page = 1, this.getPageData();
                    },
                    getPageData: function() {
                        var e = this;
                        this.activityMap[this.activeType] && (0, u.get)(this.activityMap[this.activeType].api, {
                            class_id: this.classId,
                            page: this.page,
                            status: this.tabBarList[this.statusCur].id,
                            user_id: getApp().user.userid
                        }).then(function(i) {
                            t.stopPullDownRefresh(), console.log(i.data, "列表数据列表数据列表数据列表数据列表数据列表数据列表数据列表数据列表数据列表数据列表数据");
                            var a = i.data.map(function(t) {
                                return {
                                    id: t.id,
                                    image: t.pic,
                                    title: t.title,
                                    price: t.activity_price || t.bottom_price,
                                    level: t.level,
                                    mchPrice: t.price,
                                    endTime: 1e3 * t.end_time,
                                    link: {
                                        type: "good_detail",
                                        id: t.id,
                                        activity: e.activeType
                                    }
                                };
                            });
                            e.list = 1 === e.page ? a : e.list.concat(a);
                        });
                    },
                    computedNowToDate: function(t) {
                        var e = parseInt(String((new Date(t).getTime() - new Date().getTime()) / 1e3)), i = parseInt(String(e % 60)), a = parseInt(String(e / 60 % 60)), n = parseInt(String(e / 3600 % 24)), s = parseInt(String(e / 86400));
                        return i = i < 10 ? "0" + i : i, a = a < 10 ? "0" + a : a, n = n < 10 ? "0" + n : n, 
                        [ s, n, a, i ];
                    },
                    activityStatusChange: function(t) {
                        this.statusCur = t, this.getPageData();
                    }
                }
            };
            e.default = c;
        }).call(this, i("543d")["default"]);
    },
    "701a": function(t, e, i) {
        "use strict";
        i.r(e);
        var a = i("0bb5"), n = i.n(a);
        for (var s in a) "default" !== s && function(t) {
            i.d(e, t, function() {
                return a[t];
            });
        }(s);
        e["default"] = n.a;
    },
    "922d": function(t, e, i) {
        "use strict";
        var a = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, n = [];
        i.d(e, "a", function() {
            return a;
        }), i.d(e, "b", function() {
            return n;
        });
    },
    de50: function(t, e, i) {
        "use strict";
        i.r(e);
        var a = i("922d"), n = i("701a");
        for (var s in n) "default" !== s && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(s);
        var u = i("2877"), r = Object(u["a"])(n["default"], a["a"], a["b"], !1, null, null, null);
        e["default"] = r.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/activity-list/activity-list-create-component", {
    "yb_shopv2/pages/activity-list/activity-list-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("de50"));
    }
}, [ [ "yb_shopv2/pages/activity-list/activity-list-create-component" ] ] ]);