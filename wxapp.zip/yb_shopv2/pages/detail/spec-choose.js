(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/detail/spec-choose" ], {
    "0cdf": function(t, n, o) {
        "use strict";
        var e = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, i = [];
        o.d(n, "a", function() {
            return e;
        }), o.d(n, "b", function() {
            return i;
        });
    },
    "3bd1": function(t, n, o) {},
    "4e1a": function(t, n, o) {
        "use strict";
        o.r(n);
        var e = o("dd87"), i = o.n(e);
        for (var c in e) "default" !== c && function(t) {
            o.d(n, t, function() {
                return e[t];
            });
        }(c);
        n["default"] = i.a;
    },
    "859c": function(t, n, o) {
        "use strict";
        var e = o("3bd1"), i = o.n(e);
        i.a;
    },
    "98a5": function(t, n, o) {
        "use strict";
        o.r(n);
        var e = o("0cdf"), i = o("4e1a");
        for (var c in i) "default" !== c && function(t) {
            o.d(n, t, function() {
                return i[t];
            });
        }(c);
        o("859c");
        var u = o("2877"), a = Object(u["a"])(i["default"], e["a"], e["b"], !1, null, null, null);
        n["default"] = a.exports;
    },
    dd87: function(t, n, o) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = c(o("c8bc")), i = o("b1b6");
            function c(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var u = function() {
                return o.e("yb_shopv2/component/CustomCounter").then(o.bind(null, "57d3"));
            }, a = function() {
                return o.e("yb_shopv2/component/CustomRadioGroup").then(o.bind(null, "7c57"));
            }, s = {
                name: "spec-choose",
                props: {
                    activityInfo: {
                        type: Object,
                        default: function() {
                            return [];
                        }
                    },
                    productInfo: {
                        type: Object,
                        default: function() {}
                    },
                    specList: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    goCarVisible: {
                        type: Boolean,
                        default: !1
                    },
                    goCarShow: {
                        type: Boolean,
                        default: !1
                    },
                    goCarAnimate: {
                        type: Boolean,
                        default: !0
                    },
                    goCarStatus: {
                        type: Number,
                        default: 1
                    }
                },
                mixins: [ e.default ],
                data: function() {
                    return {
                        skuInfo: {
                            id: 0,
                            label: "",
                            price: 0,
                            stock: 0,
                            image: ""
                        }
                    };
                },
                watch: {
                    specList: {
                        handler: function(t) {
                            var n = t.filter(function(t) {
                                return t.checked;
                            });
                            n.length && n.length === this.specList.length ? this.updateSkuInfo() : (this.skuInfo.id = 0, 
                            this.skuInfo.label = "", this.skuInfo.price = 0, this.skuInfo.stock = 0, this.skuInfo.image = 0);
                        },
                        deep: !0
                    }
                },
                computed: {
                    specComputedLabel: function() {
                        var t = this.specList.filter(function(t) {
                            return t.checked;
                        }), n = "", o = "";
                        return t.forEach(function(t) {
                            n && (n += ";", o += ";"), n += "".concat(t.value, ":").concat(t.checked), o += "".concat(t.label, ":").concat(t.children.find(function(n) {
                                return n.value === t.checked;
                            }).label);
                        }), {
                            key: n,
                            value: o
                        };
                    },
                    canNotPay: function() {
                        var t = this, n = [ function() {
                            return t.specList.filter(function(t) {
                                return t.checked;
                            }).length !== t.specList.length ? "请选择商品规格" : "";
                        }, function() {
                            return t.activityInfo && t.activityInfo.id ? t.activityInfo.activity_stock <= 0 : 0 !== t.skuInfo.id ? t.skuInfo.stock <= 0 || t.skuInfo.stock < t.productInfo.pay_count ? "商品库存不足" : "" : t.productInfo.stock <= 0 || t.productInfo.stock < t.productInfo.pay_count ? "商品库存不足" : "";
                        }, function() {
                            return 0 !== t.productInfo.max_buy && t.productInfo.pay_count > t.productInfo.max_buy ? "商品最多限购".concat(t.productInfo.max_buy, "件") : "";
                        }, function() {
                            return 0 !== t.productInfo.min_buy && t.productInfo.pay_count < t.productInfo.min_buy ? "商品最少限购".concat(t.productInfo.min_buy, "件") : "";
                        }, function() {
                            return t.activityInfo && t.activityInfo.integral && t.activityInfo.user_integral < t.activityInfo.integral * t.productInfo.pay_count ? "您的积分不足，当前积分".concat(t.activityInfo.user_integral) : "";
                        } ];
                        return n.map(function(t) {
                            return t();
                        }).filter(function(t) {
                            return t;
                        });
                    }
                },
                components: {
                    CustomCounter: u,
                    CustomRadioGroup: a
                },
                methods: {
                    closeDialog: function(n) {
                        var o = this;
                        if ("success" === n) {
                            if (console.log(this.activityInfo, "详情页确认详情页确认详情页确认详情页确认详情页确认详情页确认详情页确认详情页确认详情页确认"), 
                            console.log(this.productInfo.pay_count, "详情页确认详情页确认详情页确认详情页确认详情页确认详情页确认详情页确认详情页确认详情页确认"), 
                            this.canNotPay.length) return void t.showToast({
                                title: this.canNotPay[0],
                                icon: "none"
                            });
                            this.$emit("goodConfirmClick", this.goCarStatus, this.skuInfo, this.activityInfo && this.activityInfo.id);
                        }
                        this.$emit("update:goCarAnimate", !0), this.$emit("update:goCarShow", !1), setTimeout(function() {
                            o.$emit("update:goCarVisible", !1);
                        }, 300);
                    },
                    updateSkuInfo: function() {
                        var t = this;
                        (0, i.get)("Goods_getGoodsSkuAttr", {
                            spec_id_group: this.specComputedLabel.key,
                            goods_id: this.productInfo.id,
                            user_id: getApp().user.userid
                        }).then(function(n) {
                            console.log(n), t.$set(t, "skuInfo", {
                                id: n.data.id,
                                label: n.data.spec_name_group,
                                price: n.data.level && n.data.level.level ? n.data.level.level_money : n.data.price,
                                stock: n.data.stock,
                                image: n.data.sku_img
                            });
                        });
                    },
                    cancelRadioChecked: function(t, n, o) {
                        n || this.$emit("radioChecked", t, 0, o);
                    },
                    specChange: function(t, n, o) {
                        this.$emit("radioChecked", t, n, o);
                    },
                    updatePayCount: function(n) {
                        (this.activityInfo && 0 !== this.activityInfo.id ? n > this.activityInfo.activity_stock : 0 !== this.skuInfo.id ? n > this.skuInfo.stock : n > this.productInfo.stock) ? t.showToast({
                            icon: "none",
                            title: "超过库存数量"
                        }) : this.$emit("updatePayCount", n);
                    }
                }
            };
            n.default = s;
        }).call(this, o("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/detail/spec-choose-create-component", {
    "yb_shopv2/pages/detail/spec-choose-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("98a5"));
    }
}, [ [ "yb_shopv2/pages/detail/spec-choose-create-component" ] ] ]);