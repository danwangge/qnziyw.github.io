(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/detail/detail" ], {
    "133f": function(t, i, o) {
        "use strict";
        var e = function() {
            var t = this, i = t.$createElement, o = (t._self._c, t._f("formatterPriceYuan")(t.activityInfo && t.activityInfo.activity_price)), e = t._f("formatterPriceFen")(t.activityInfo && t.activityInfo.activity_price), n = t._f("formatterPriceYuan")(t.activityInfo && t.activityInfo.activity_price), a = t._f("formatterPriceFen")(t.activityInfo && t.activityInfo.activity_price), c = t._f("formatterPriceYuan")(t.activityInfo && t.activityInfo.bottom_price), r = t._f("formatterPriceFen")(t.activityInfo && t.activityInfo.bottom_price), s = Number(t.activityInfo && t.activityInfo.cashprice), u = t._f("formatterPriceYuan")(t.activityInfo && t.activityInfo.cashprice), d = t._f("formatterPriceFen")(t.activityInfo && t.activityInfo.cashprice);
            t._isMounted || (t.e0 = function(i) {
                t.productInfo.pay_count = i;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    f0: o,
                    f1: e,
                    f2: n,
                    f3: a,
                    f4: c,
                    f5: r,
                    m0: s,
                    f6: u,
                    f7: d
                }
            });
        }, n = [];
        o.d(i, "a", function() {
            return e;
        }), o.d(i, "b", function() {
            return n;
        });
    },
    1464: function(t, i, o) {},
    "28e8": function(t, i, o) {
        "use strict";
        var e = o("1464"), n = o.n(e);
        n.a;
    },
    6593: function(t, i, o) {
        "use strict";
        (function(t) {
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var e = r(o("c8bc")), n = r(o("3b18")), a = o("b1b6"), c = r(o("21b4"));
            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var s = function() {
                return o.e("yb_shopv2/component/CustomTabBar").then(o.bind(null, "080c"));
            }, u = function() {
                return o.e("yb_shopv2/component/CustomButton").then(o.bind(null, "088b"));
            }, d = function() {
                return o.e("yb_shopv2/pages/detail/spec-choose").then(o.bind(null, "98a5"));
            }, f = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/module/ModuleComment") ]).then(o.bind(null, "298a"));
            }, l = function() {
                return o.e("yb_shopv2/component/CustomCountDown").then(o.bind(null, "ad8f"));
            }, p = function() {
                return Promise.all([ o.e("common/vendor"), o.e("components/mpvue-wxparse/wxParse") ]).then(o.bind(null, "6bf0"));
            }, h = {
                name: "detail",
                props: {
                    goodId: {
                        type: [ String, Number ],
                        default: ""
                    },
                    activity: {
                        type: String,
                        default: ""
                    },
                    groupNo: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        collectionStatus: 0,
                        productInfo: {},
                        activityInfo: {},
                        detailTabList: [ {
                            title: "商品详情"
                        }, {
                            title: "商品属性"
                        }, {
                            title: "商品评价"
                        } ],
                        attrList: [],
                        specList: [],
                        tabCur: 0,
                        goCarVisible: !1,
                        goCarShow: !1,
                        goCarAnimate: !0,
                        goCarStatus: 1,
                        autoplay: !0,
                        interval: 2e3,
                        duration: 500,
                        commentList: [],
                        cartCount: 0,
                        page_path: "pages/detail/detail",
                        activityMap: {
                            bargain: {
                                api: "Bargain_getBargain",
                                order_type: 2
                            },
                            seckill: {
                                api: "Seckill_getSeckill",
                                order_type: 3
                            },
                            group: {
                                api: "Group_getGroup",
                                order_type: 4
                            },
                            integral: {
                                api: "Integralmall_getIntegralGoods",
                                order_type: 5
                            }
                        }
                    };
                },
                mixins: [ e.default, n.default ],
                filters: {
                    formatterPriceYuan: function(t) {
                        return t ? String(t).match(/^\S+\./) && String(t).match(/^\S+\./)[0] || t : "0";
                    },
                    formatterPriceFen: function(t) {
                        return t && String(t).match(/\./) ? String(t).replace(/^\S+\./, "") : ".00";
                    }
                },
                watch: {},
                mounted: function() {},
                computed: {
                    businessInfo: function() {
                        return getApp().business;
                    },
                    globalColor: function() {
                        return getApp().common.globle.color;
                    },
                    activityEnd: function() {
                        var t = this.activityInfo && 1e3 * this.activityInfo.end_time || 0 - new Date().getTime();
                        return this.activity && t < 0;
                    }
                },
                components: {
                    CustomTabBar: s,
                    WxParse: p,
                    CustomButton: u,
                    PageSpecChoose: d,
                    ModuleComment: f,
                    CustomCountDown: l
                },
                methods: {
                    page_onPullDownRefresh: function() {
                        this.getGoodsDetail(this.goodId);
                    },
                    page_onLoad: function(i) {
                        this.title = "商品详情", t.showLoading({
                            title: "加载中"
                        }), t.setNavigationBarColor({
                            frontColor: "#000000",
                            backgroundColor: "#ffffff"
                        });
                    },
                    page_onShow: function() {
                        this.getGoodsDetail(this.goodId);
                    },
                    goodsToCollection: function() {
                        var i = this;
                        this.collectionLoading || (this.collectionLoading = !0, (0, a.get)("Member_userCollectionEdit", {
                            goods_id: this.productInfo.id,
                            user_id: getApp().user.userid
                        }).then(function(o) {
                            i.collectionLoading = !1, i.collectionStatus = o.data, t.showToast({
                                title: o.msg
                            });
                        }));
                    },
                    getGoodsDetail: function(i) {
                        var o = this;
                        (0, a.get)(this.activity ? this.activityMap[this.activity].api : "Goods_getGoodsInfo", this.activity ? {
                            id: i,
                            user_id: getApp().user.userid
                        } : {
                            goods_id: i,
                            user_id: getApp().user.userid
                        }).then(function(i) {
                            t.hideLoading(), t.stopPullDownRefresh(), console.log(i, "详情数据详情数据详情数据详情数据详情数据详情数据详情数据"), 
                            o.collectionStatus = i.data.collection_status, o.activityInfo = i.data.activity, 
                            o.productInfo = i.data.goods, o.cartCount = i.data.cart_count, o.$set(o.productInfo, "banner", JSON.parse(i.data.goods.pic_group)), 
                            o.$set(o.productInfo, "pay_count", 1), o.attrList = i.data.attr_relate, o.specList = [], 
                            i.data.spec_relate.forEach(function(t) {
                                var i = o.specList.find(function(i) {
                                    return i.value === t.spec_id;
                                });
                                i ? i.children.push({
                                    value: t.value_id,
                                    label: t.spec_value_name
                                }) : o.specList.push({
                                    value: t.spec_id,
                                    label: t.spec_name,
                                    checked: 0,
                                    children: [ {
                                        value: t.value_id,
                                        label: t.spec_value_name
                                    } ]
                                }), console.log(o.specList);
                            }), setTimeout(function() {
                                t.hideLoading();
                            }, 100);
                        });
                    },
                    handlerTabCur: function(t) {
                        var i = this;
                        this.tabCur = t, 2 === this.tabCur && (0, a.get)("Goods_getComment", {
                            goods_id: this.productInfo.id,
                            page: 1
                        }).then(function(t) {
                            i.commentList = t.data;
                        });
                    },
                    showDialog: function(i) {
                        var o = this;
                        if (1 === i || 2 === i || 3 === i || 5 === i || 6 === i || 7 === i) {
                            if (this.activity && this.activityInfo && 0 == this.activityInfo.end_time) return void t.showToast({
                                title: "活动已结束",
                                icon: "none"
                            });
                            if (!this.productInfo.is_buy) return void t.showToast({
                                title: "商品暂不可购买",
                                icon: "none"
                            });
                            this.goCarStatus = i, this.goCarVisible = !0, this.goCarShow = !0, this.$nextTick(function() {
                                o.goCarAnimate = !1;
                            });
                        } else 4 === i && this.jump({
                            type: "bargain_detail",
                            launch_id: this.activityInfo.launch_id,
                            activity_id: this.activityInfo.id
                        });
                    },
                    handlerRadioChecked: function(t, i, o) {
                        this.specList[o].checked = i;
                    },
                    handlerGoodConfirm: function(i, o, e) {
                        var n = this;
                        if (o = o || {}, 1 == i) (0, a.get)("Goods_addCart", {
                            goods_id: this.productInfo.id,
                            user_id: getApp().user.userid,
                            sku_id: o.id,
                            num: this.productInfo.pay_count,
                            goods_name: this.productInfo.goods_name,
                            goods_images: this.productInfo.pic
                        }).then(function(i) {
                            t.showToast({
                                title: "商品加入购物车",
                                duration: 2e3
                            }), n.cartCount += n.productInfo.pay_count, n.productInfo.pay_count = 1;
                        }); else if (2 == i || 5 == i || 6 == i || 7 == i) {
                            var c = {}, r = 0, s = 1;
                            c.id = this.productInfo.id, c.title = this.productInfo.goods_name, c.count = this.productInfo.pay_count, 
                            c.image = this.productInfo.pic, c.skuId = o.id, c.cate = o.label, c.shoppingId = this.productInfo.shipping_id, 
                            2 === i ? c.price = o.id ? o.price : this.productInfo.price : (c.price = this.activityInfo && this.activityInfo.id ? this.activityInfo.activity_price || this.activityInfo.bottom_price || this.activityInfo.cashprice : o.id ? o.price : this.productInfo.price, 
                            r = this.activityInfo && this.activityInfo.id, s = this.activity ? this.activityMap[this.activity].order_type : 1), 
                            this.jump({
                                type: "confirm_order",
                                params: JSON.stringify([ c ]),
                                order_type: s,
                                activity_id: r || null,
                                group_no: this.groupNo || null
                            });
                        } else 3 == i && (0, a.get)("Bargain_createBargain", {
                            user_id: getApp().user.userid,
                            activity_id: e,
                            goods: JSON.stringify([ {
                                goods_id: this.productInfo.id,
                                sku_id: o.id,
                                num: this.productInfo.pay_count,
                                template_id: 0
                            } ])
                        }).then(function(i) {
                            t.showToast({
                                title: "发起砍价成功！"
                            }), console.log(i, "成功发起砍价的回调成功发起砍价的回调成功发起砍价的回调成功发起砍价的回调成功发起砍价的回调"), n.jump({
                                type: "bargain_detail",
                                launch_id: i.data.launch_id,
                                activity_id: n.activityInfo.id
                            });
                        });
                    },
                    goToHome: function() {
                        c.default.jump("/yb_shopv2/native/tabbar0/index", 3);
                    }
                }
            };
            i.default = h;
        }).call(this, o("543d")["default"]);
    },
    "7f82": function(t, i, o) {
        "use strict";
        o.r(i);
        var e = o("6593"), n = o.n(e);
        for (var a in e) "default" !== a && function(t) {
            o.d(i, t, function() {
                return e[t];
            });
        }(a);
        i["default"] = n.a;
    },
    bcf0: function(t, i, o) {
        "use strict";
        o.r(i);
        var e = o("133f"), n = o("7f82");
        for (var a in n) "default" !== a && function(t) {
            o.d(i, t, function() {
                return n[t];
            });
        }(a);
        o("28e8");
        var c = o("2877"), r = Object(c["a"])(n["default"], e["a"], e["b"], !1, null, null, null);
        i["default"] = r.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/detail/detail-create-component", {
    "yb_shopv2/pages/detail/detail-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("bcf0"));
    }
}, [ [ "yb_shopv2/pages/detail/detail-create-component" ] ] ]);