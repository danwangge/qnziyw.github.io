(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/information/information" ], {
    "2da3": function(e, t, i) {
        "use strict";
        var a = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, n = [];
        i.d(t, "a", function() {
            return a;
        }), i.d(t, "b", function() {
            return n;
        });
    },
    "30ea": function(e, t, i) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = u(i("c8bc")), n = u(i("3b18")), r = i("b1b6");
            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var o = function() {
                return i.e("yb_shopv2/component/CustomPrimaryList").then(i.bind(null, "a6ff"));
            }, s = function() {
                return i.e("yb_shopv2/component/CustomButton").then(i.bind(null, "088b"));
            }, p = [ {
                value: 0,
                label: "男"
            }, {
                value: 1,
                label: "女"
            } ], c = {
                name: "information",
                data: function() {
                    return {
                        submitData: {
                            user_headimg: getApp().user.user_headimg || "",
                            nick_name: getApp().user.nick_name || "",
                            sex: null === getApp().user.sex ? "" : getApp().user.sex,
                            birthday: getApp().user.birthday || "",
                            area: getApp().user.area || "",
                            phone: getApp().user.phone || "",
                            wechat: getApp().user.wechat || "",
                            qq: getApp().user.qq || "",
                            province: getApp().user.province || "",
                            city: getApp().user.city || "",
                            district: getApp().user.district || ""
                        },
                        page_path: "pages/information/information"
                    };
                },
                mixins: [ a.default, n.default ],
                computed: {
                    list: function() {
                        return [ [ {
                            title: "修改头像",
                            name: "user_headimg",
                            rightType: "image",
                            image: this.submitData.user_headimg
                        } ], [ {
                            title: "昵称",
                            name: "nick_name",
                            rightType: "input",
                            input: {
                                placeholder: "请输入昵称",
                                value: this.submitData.nick_name
                            },
                            hiddenArrow: !0
                        }, {
                            title: "性别",
                            name: "sex",
                            rightType: "picker",
                            pickerRange: p,
                            pickerRangeKey: "name",
                            pickerMode: "selector",
                            picker: {
                                placeholder: "选择性别",
                                value: this.submitData.sex
                            }
                        }, {
                            title: "出生日期",
                            name: "birthday",
                            rightType: "picker",
                            pickerMode: "date",
                            picker: {
                                placeholder: "选择生日",
                                value: this.submitData.birthday
                            }
                        }, {
                            title: "地区",
                            name: "area",
                            rightType: "picker",
                            pickerMode: "region",
                            picker: {
                                placeholder: "选择地区",
                                value: this.submitData.area,
                                code: [ this.submitData.province, this.submitData.city, this.submitData.district ]
                            }
                        } ], [ {
                            title: "手机号",
                            name: "phone",
                            hiddenArrow: !0,
                            rightType: "input",
                            input: {
                                placeholder: "请输入手机号",
                                value: this.submitData.phone
                            }
                        }, {
                            title: "微信号",
                            name: "wechat",
                            rightType: "input",
                            hiddenArrow: !0,
                            input: {
                                placeholder: "请输入微信号",
                                value: this.submitData.wechat
                            }
                        }, {
                            title: "QQ号",
                            name: "qq",
                            rightType: "input",
                            hiddenArrow: !0,
                            input: {
                                placeholder: "请输入QQ号",
                                value: this.submitData.qq
                            }
                        } ] ];
                    }
                },
                components: {
                    CustomPrimaryList: o,
                    CustomButton: s
                },
                methods: {
                    page_onLoad: function(t) {
                        this.title = "修改信息", e.setNavigationBarColor({
                            frontColor: "#000000",
                            backgroundColor: "#ffffff"
                        });
                    },
                    handlerListChange: function(e, t, i, a, n) {
                        console.log(t, "valueeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"), this.submitData[e.name] = t, 
                        "region" === e.pickerMode && (this.submitData.province = n[0], this.submitData.city = n[1], 
                        this.submitData.district = n[2]);
                    },
                    page_onPullDownRefresh: function() {
                        e.stopPullDownRefresh();
                    },
                    handlerInfoSave: function() {
                        if (this.submitData.nick_name) {
                            var t = JSON.parse(JSON.stringify(this.submitData)), i = p.find(function(e) {
                                return e.name === t.sex;
                            });
                            t.sex = i ? i.id : "", t.user_id = getApp().user.userid, e.showLoading({
                                title: "保存中。。。"
                            }), (0, r.get)("Member_userInfoUpdate", t).then(function(i) {
                                for (var a in t) t.hasOwnProperty(a) && (getApp().user[a] = t[a]);
                                e.hideLoading(), e.showToast({
                                    title: "保存成功！"
                                }), e.setStorageSync("user", getApp().user);
                            }).catch(function(t) {
                                e.hideLoading();
                            });
                        } else e.showToast({
                            title: "请输入昵称",
                            icon: "none"
                        });
                    }
                }
            };
            t.default = c;
        }).call(this, i("543d")["default"]);
    },
    "50a0": function(e, t, i) {
        "use strict";
        i.r(t);
        var a = i("30ea"), n = i.n(a);
        for (var r in a) "default" !== r && function(e) {
            i.d(t, e, function() {
                return a[e];
            });
        }(r);
        t["default"] = n.a;
    },
    dc23: function(e, t, i) {
        "use strict";
        var a = i("dcde"), n = i.n(a);
        n.a;
    },
    dcde: function(e, t, i) {},
    f35e: function(e, t, i) {
        "use strict";
        i.r(t);
        var a = i("2da3"), n = i("50a0");
        for (var r in n) "default" !== r && function(e) {
            i.d(t, e, function() {
                return n[e];
            });
        }(r);
        i("dc23");
        var u = i("2877"), o = Object(u["a"])(n["default"], a["a"], a["b"], !1, null, null, null);
        t["default"] = o.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/information/information-create-component", {
    "yb_shopv2/pages/information/information-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("f35e"));
    }
}, [ [ "yb_shopv2/pages/information/information-create-component" ] ] ]);