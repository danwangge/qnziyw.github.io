(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/applyDistribution/distributionAgreement" ], {
    "71ba": function(t, e, a) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var n = i(a("3b18"));
        function i(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var u = {
            mixins: [ n.default ],
            data: function() {
                return {
                    agreeDetail: {},
                    detail: "<p>分销商申请协议</p>"
                };
            },
            methods: {
                page_onLoad: function() {
                    var t = this;
                    t.title = "分销商申请协议", getApp().Req.get("Distribution_getDistributionSetting", {}, function(e) {
                        var a = [];
                        -1 != e.data.withdraw_type.indexOf("wechat") && a.push("微信"), -1 != e.data.withdraw_type.indexOf("alipay") && a.push("支付宝"), 
                        -1 != e.data.withdraw_type.indexOf("bank_card") && a.push("银行卡"), e.data.withdraw_type = a, 
                        t.agreeDetail = e.data, console.log(t.agreeDetail, "分销商信息");
                    });
                }
            }
        };
        e.default = u;
    },
    ab09: function(t, e, a) {
        "use strict";
        var n = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, i = [];
        a.d(e, "a", function() {
            return n;
        }), a.d(e, "b", function() {
            return i;
        });
    },
    abfd: function(t, e, a) {},
    bee1: function(t, e, a) {
        "use strict";
        var n = a("abfd"), i = a.n(n);
        i.a;
    },
    c6ad: function(t, e, a) {
        "use strict";
        a.r(e);
        var n = a("71ba"), i = a.n(n);
        for (var u in n) "default" !== u && function(t) {
            a.d(e, t, function() {
                return n[t];
            });
        }(u);
        e["default"] = i.a;
    },
    ce6f: function(t, e, a) {
        "use strict";
        a.r(e);
        var n = a("ab09"), i = a("c6ad");
        for (var u in i) "default" !== u && function(t) {
            a.d(e, t, function() {
                return i[t];
            });
        }(u);
        a("bee1");
        var r = a("2877"), d = Object(r["a"])(i["default"], n["a"], n["b"], !1, null, null, null);
        e["default"] = d.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/applyDistribution/distributionAgreement-create-component", {
    "yb_shopv2/pages/applyDistribution/distributionAgreement-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("ce6f"));
    }
}, [ [ "yb_shopv2/pages/applyDistribution/distributionAgreement-create-component" ] ] ]);