(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/applyDistribution/applyDistribution" ], {
    "038b": function(e, t, n) {
        "use strict";
        var a = n("58c5"), o = n.n(a);
        o.a;
    },
    "2bb4": function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = r(n("3b18")), o = r(n("c8bc")), i = n("21b4");
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var s = "", l = {
                mixins: [ a.default, o.default ],
                data: function() {
                    return {
                        verCodeTxt: "获取验证码",
                        choosed: !1,
                        applyParams: {
                            name: "",
                            mobile: "",
                            code: "",
                            pid: getApp().distribution.pid,
                            user_id: getApp().user.userid
                        }
                    };
                },
                computed: {
                    pageHeight: function() {
                        return e.getSystemInfoSync().windowHeight;
                    }
                },
                methods: {
                    page_onLoad: function(e) {
                        var t = this;
                        t.title = "申请分销商";
                    },
                    page_onPullDownRefresh: function() {
                        this.applyParams.name = "", this.applyParams.mobile = "", this.applyParams.code = "", 
                        this.verCodeTxt = "获取验证码", clearInterval(s), e.stopPullDownRefresh();
                    },
                    choosedAgreement: function() {
                        this.choosed = !0;
                    },
                    getVerCode: function() {
                        var e = this;
                        "获取验证码" == e.verCodeTxt && (getApp().Req.get("Sms_sendVerificationCode", {
                            phone: e.applyParams.mobile
                        }), e.verCodeTxt = 60, s = setInterval(function() {
                            e.verCodeTxt--, e.verCodeTxt <= 0 && (clearInterval(s), e.verCodeTxt = "获取验证码");
                        }, 1e3));
                    },
                    confirmApply: function() {
                        console.log(this.applyParams, "申请参数");
                        var t = this;
                        this.applyParams.name ? this.applyParams.mobile ? 11 == this.applyParams.mobile.length ? this.applyParams.code ? this.choosed ? getApp().Req.get("Sms_checkVerificationCode", {
                            phone: t.applyParams.mobile,
                            code: t.applyParams.code
                        }, function(e) {
                            200 == e.code && (delete t.applyParams.code, getApp().Req.get("Distribution_applyDistributionUser", t.applyParams, function(e) {
                                200 == e.code && (console.log(e, "申请分销商信息"), (0, i.success)("申请成功"), (0, i.jump)("/yb_shopv2/native/all/index?type=page_distribution", 2));
                            }, function(e) {
                                (0, i.warning)("请稍后再试");
                            }));
                        }, function(n) {
                            e.showToast({
                                icon: "none",
                                title: n.msg
                            }), t.applyParams.code = "", t.verCodeTxt = "获取验证码", clearInterval(s), console.log(n, "验证码错误信息");
                        }) : (0, i.warning)("请勾选协议") : (0, i.warning)("请输入验证码") : (0, i.warning)("手机号格式错误") : (0, 
                        i.warning)("请输入手机号") : (0, i.warning)("请输入姓名");
                    }
                }
            };
            t.default = l;
        }).call(this, n("543d")["default"]);
    },
    "58c5": function(e, t, n) {},
    "736c": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("2bb4"), o = n.n(a);
        for (var i in a) "default" !== i && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        t["default"] = o.a;
    },
    bf67: function(e, t, n) {
        "use strict";
        var a = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, o = [];
        n.d(t, "a", function() {
            return a;
        }), n.d(t, "b", function() {
            return o;
        });
    },
    c69b: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("bf67"), o = n("736c");
        for (var i in o) "default" !== i && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        n("038b");
        var r = n("2877"), s = Object(r["a"])(o["default"], a["a"], a["b"], !1, null, null, null);
        t["default"] = s.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/applyDistribution/applyDistribution-create-component", {
    "yb_shopv2/pages/applyDistribution/applyDistribution-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("c69b"));
    }
}, [ [ "yb_shopv2/pages/applyDistribution/applyDistribution-create-component" ] ] ]);