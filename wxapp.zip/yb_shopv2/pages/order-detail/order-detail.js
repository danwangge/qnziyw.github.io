(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/order-detail/order-detail" ], {
    "151f": function(e, o, n) {
        "use strict";
        var t = function() {
            var e = this, o = e.$createElement;
            e._self._c;
        }, r = [];
        n.d(o, "a", function() {
            return t;
        }), n.d(o, "b", function() {
            return r;
        });
    },
    "4d4e": function(e, o, n) {
        "use strict";
        var t = n("8946"), r = n.n(t);
        r.a;
    },
    "4f40": function(e, o, n) {
        "use strict";
        n.r(o);
        var t = n("151f"), r = n("5ae9");
        for (var i in r) "default" !== i && function(e) {
            n.d(o, e, function() {
                return r[e];
            });
        }(i);
        n("4d4e");
        var d = n("2877"), a = Object(d["a"])(r["default"], t["a"], t["b"], !1, null, null, null);
        o["default"] = a.exports;
    },
    "5ae9": function(e, o, n) {
        "use strict";
        n.r(o);
        var t = n("751d"), r = n.n(t);
        for (var i in t) "default" !== i && function(e) {
            n.d(o, e, function() {
                return t[e];
            });
        }(i);
        o["default"] = r.a;
    },
    "751d": function(e, o, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var t = d(n("c8bc")), r = d(n("3b18")), i = n("b1b6");
            function d(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var a = function() {
                return Promise.all([ n.e("common/vendor"), n.e("yb_shopv2/module/ModuleGoodList") ]).then(n.bind(null, "47e1"));
            }, u = function() {
                return n.e("yb_shopv2/component/CustomPrimaryList").then(n.bind(null, "a6ff"));
            }, s = {
                name: "order-detail",
                props: {
                    orderId: {
                        type: Number,
                        default: 0
                    }
                },
                data: function() {
                    return {
                        orderInfo: {}
                    };
                },
                mixins: [ t.default, r.default ],
                computed: {
                    jumpMap: function() {
                        return this.orderInfo.self_mention_info && this.orderInfo.self_mention_info.id ? {
                            type: "map",
                            url: {
                                lat: this.orderInfo.self_mention_info.address.postion_lat,
                                lng: this.orderInfo.self_mention_info.address.postion_lng,
                                address: this.orderInfo.self_mention_info.address.addr,
                                city: this.orderInfo.self_mention_info.address.city
                            }
                        } : {};
                    },
                    expressInfoConfig: function() {
                        return [ {
                            title: "物流信息",
                            link: {
                                type: "express",
                                id: this.orderId
                            }
                        } ];
                    },
                    globalColor: function() {
                        return getApp().common.globle.color;
                    }
                },
                mounted: function() {
                    this.getOrderDetail();
                },
                components: {
                    ModuleGoodList: a,
                    CustomPrimaryList: u
                },
                methods: {
                    page_onLoad: function() {
                        this.title = "订单详情", e.setNavigationBarColor({
                            frontColor: "#000000",
                            backgroundColor: "#ffffff"
                        });
                    },
                    page_onPullDownRefresh: function() {
                        this.getOrderDetail();
                    },
                    getOrderDetail: function() {
                        var o = this;
                        (0, i.get)("Order_getOrderDetails", {
                            user_id: getApp().user.userid,
                            order_id: this.orderId
                        }).then(function(n) {
                            e.stopPullDownRefresh(), console.log(n.data), o.orderInfo = n.data, o.orderInfo.goods_item = o.orderInfo.goods_item.map(function(e) {
                                return {
                                    title: e.goods_name,
                                    price: e.goods_price,
                                    image: e.pic_url,
                                    count: e.num
                                };
                            });
                        });
                    },
                    orderPay: function() {
                        var e = this;
                        this.payLoading || (this.payLoading = !0, (0, i.payRequest)({
                            order_no: this.orderInfo.order_no,
                            order_id: this.orderInfo.order_id,
                            order_type: 0
                        }).then(function(o) {
                            e.payLoading = !1;
                        }).catch(function(o) {
                            e.payLoading = !1;
                        }));
                    }
                }
            };
            o.default = s;
        }).call(this, n("543d")["default"]);
    },
    8946: function(e, o, n) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/order-detail/order-detail-create-component", {
    "yb_shopv2/pages/order-detail/order-detail-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("4f40"));
    }
}, [ [ "yb_shopv2/pages/order-detail/order-detail-create-component" ] ] ]);