(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/mine-evaluate/mine-evaluate" ], {
    "09e1": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("73e0"), o = n("d67a");
        for (var u in o) "default" !== u && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(u);
        var i = n("2877"), r = Object(i["a"])(o["default"], a["a"], a["b"], !1, null, null, null);
        t["default"] = r.exports;
    },
    "73e0": function(e, t, n) {
        "use strict";
        var a = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, o = [];
        n.d(t, "a", function() {
            return a;
        }), n.d(t, "b", function() {
            return o;
        });
    },
    "8a31": function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = r(n("c8bc")), o = r(n("3b18")), u = r(n("ffc5")), i = n("b1b6");
            function r(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var l = function() {
                return Promise.all([ n.e("common/vendor"), n.e("yb_shopv2/module/ModuleComment") ]).then(n.bind(null, "298a"));
            }, f = function() {
                return n.e("yb_shopv2/component/CustomNoData").then(n.bind(null, "8a57"));
            }, s = {
                name: "mine-evaluate",
                data: function() {
                    return {
                        list: [],
                        page_path: "pages/mine-evaluate/mine-evaluate",
                        init: !0
                    };
                },
                mixins: [ a.default, o.default, u.default ],
                mounted: function() {
                    this.getPageData();
                },
                components: {
                    ModuleComment: l,
                    CustomNoData: f
                },
                methods: {
                    page_onLoad: function(t) {
                        this.title = "我的评价", e.showLoading({
                            title: "加载中"
                        }), e.setNavigationBarColor({
                            frontColor: "#000000",
                            backgroundColor: "#ffffff"
                        });
                    },
                    getPageData: function() {
                        var t = this;
                        (0, i.get)("Member_getUserComment", {
                            user_id: getApp().user.userid,
                            page: this.page
                        }).then(function(n) {
                            t.init = !1, e.hideLoading(), e.stopPullDownRefresh();
                            var a = n.data.map(function(e) {
                                return e.good_info = {
                                    title: e.goods_name,
                                    image: e.goods_pic,
                                    price: e.goods_price
                                }, e;
                            });
                            t.list = 1 === t.page ? a : t.list.concat(a), a.length < 20 && (t.end = !0);
                        });
                    }
                }
            };
            t.default = s;
        }).call(this, n("543d")["default"]);
    },
    d67a: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("8a31"), o = n.n(a);
        for (var u in a) "default" !== u && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(u);
        t["default"] = o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/mine-evaluate/mine-evaluate-create-component", {
    "yb_shopv2/pages/mine-evaluate/mine-evaluate-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("09e1"));
    }
}, [ [ "yb_shopv2/pages/mine-evaluate/mine-evaluate-create-component" ] ] ]);