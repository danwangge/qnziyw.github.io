(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/product/list/index" ], {
    "02d9": function(t, e, o) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = i(o("3b18"));
            function i(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var a = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/product2") ]).then(o.bind(null, "837c"));
            }, r = {
                mixins: [ n.default ],
                data: function() {
                    return {
                        cate: [],
                        topRefresh: 0,
                        bottomRefresh: 0,
                        item: {
                            class_ids: 0,
                            data_type: "auto",
                            id: "product-list-2",
                            num: 10,
                            order: "create_time",
                            showtitle: !0,
                            sort: "desc",
                            css: {
                                "product-list-2": "background-color:rgba(255, 255, 255, 1.0);background:rgba(255, 255, 255, 1.0);",
                                "product-list-2 &group_item": "border-top:1px solid #f1f1f1;border-right:1px solid #f1f1f1;border-bottom:1px solid #f1f1f1;border-left:1px solid #f1f1f1;border-radius:4px 4px 4px 4px;",
                                "product-list-2 &group_title": "background-color:rgba(0, 0, 0, 0.2);background:rgba(0, 0, 0, 0.2);font-family:Arial;font-size:13.00px;color:#fff;font-weight:400;font-style:normal;text-decoration:unset;text-align:left;",
                                "product-list-2 &item_image": "height:120.00px;"
                            },
                            animation: {},
                            list: []
                        },
                        page_path: "pages/product/list/index",
                        globle: getApp().common.globle
                    };
                },
                components: {
                    plist: a
                },
                methods: {
                    page_onLoad: function(e) {
                        this.title = "产品列表", t.showLoading({
                            title: "加载中"
                        }), this.getCataData();
                    },
                    page_onPullDownRefresh: function() {
                        this.topRefresh += 1;
                    },
                    page_onReachBottom: function() {
                        this.bottomRefresh += 1;
                    },
                    getCataData: function() {
                        var e = this;
                        getApp().Req.get("product_productClass", {}, function(o) {
                            t.hideLoading(), e.cate = o.info;
                        });
                    },
                    cate_select: function(e) {
                        e = e || {
                            id: 0,
                            name: "产品列表"
                        }, e.id + "" !== this.item.class_ids + "" && (t.showLoading({
                            title: "加载中"
                        }), this.item.class_ids = e.id, this.item.page = 1, this.title = e.name);
                    }
                }
            };
            e.default = r;
        }).call(this, o("543d")["default"]);
    },
    "6ffb": function(t, e, o) {
        "use strict";
        var n = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, i = [];
        o.d(e, "a", function() {
            return n;
        }), o.d(e, "b", function() {
            return i;
        });
    },
    b21b: function(t, e, o) {
        "use strict";
        o.r(e);
        var n = o("6ffb"), i = o("b98b");
        for (var a in i) "default" !== a && function(t) {
            o.d(e, t, function() {
                return i[t];
            });
        }(a);
        o("be36");
        var r = o("2877"), s = Object(r["a"])(i["default"], n["a"], n["b"], !1, null, null, null);
        e["default"] = s.exports;
    },
    b98b: function(t, e, o) {
        "use strict";
        o.r(e);
        var n = o("02d9"), i = o.n(n);
        for (var a in n) "default" !== a && function(t) {
            o.d(e, t, function() {
                return n[t];
            });
        }(a);
        e["default"] = i.a;
    },
    be36: function(t, e, o) {
        "use strict";
        var n = o("ea79"), i = o.n(n);
        i.a;
    },
    ea79: function(t, e, o) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/product/list/index-create-component", {
    "yb_shopv2/pages/product/list/index-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("b21b"));
    }
}, [ [ "yb_shopv2/pages/product/list/index-create-component" ] ] ]);