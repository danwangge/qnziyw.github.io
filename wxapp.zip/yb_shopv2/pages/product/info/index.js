(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/product/info/index" ], {
    1758: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = o(n("3b18"));
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var a = function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/mpvue-wxparse/wxParse") ]).then(n.bind(null, "6bf0"));
            }, u = {
                mixins: [ i.default ],
                data: function() {
                    return {
                        id: "",
                        detail: {},
                        video_show: !1,
                        page_path: "pages/product/info/index"
                    };
                },
                components: {
                    wxParse: a
                },
                methods: {
                    page_onLoad: function(e) {
                        this.id = e.id, t.showLoading({
                            title: "加载中"
                        }), this.getPageData();
                    },
                    getPageData: function() {
                        var e = this;
                        getApp().Req.get("product_product_info", {
                            id: this.id
                        }, function(n) {
                            t.hideLoading();
                            var i = n.info;
                            i.content = i.content.replace(/\<img/gi, '<img style="width:100%;height:auto" '), 
                            e.detail = i, e.title = n.info.title, e.video_show = i.video_url && i.video_url.length > 0;
                        });
                    }
                }
            };
            e.default = u;
        }).call(this, n("543d")["default"]);
    },
    "350b": function(t, e, n) {
        "use strict";
        var i = n("47f3"), o = n.n(i);
        o.a;
    },
    4686: function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("ac29"), o = n("9ded");
        for (var a in o) "default" !== a && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        n("350b");
        var u = n("2877"), r = Object(u["a"])(o["default"], i["a"], i["b"], !1, null, null, null);
        e["default"] = r.exports;
    },
    "47f3": function(t, e, n) {},
    "9ded": function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("1758"), o = n.n(i);
        for (var a in i) "default" !== a && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        e["default"] = o.a;
    },
    ac29: function(t, e, n) {
        "use strict";
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, o = [];
        n.d(e, "a", function() {
            return i;
        }), n.d(e, "b", function() {
            return o;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/product/info/index-create-component", {
    "yb_shopv2/pages/product/info/index-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("4686"));
    }
}, [ [ "yb_shopv2/pages/product/info/index-create-component" ] ] ]);