(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/search/index" ], {
    1244: function(e, t, a) {
        "use strict";
        var n = function() {
            var e = this, t = e.$createElement;
            e._self._c;
            e._isMounted || (e.e0 = function(t) {
                e.search_val = "", e.cancel();
            });
        }, c = [];
        a.d(t, "a", function() {
            return n;
        }), a.d(t, "b", function() {
            return c;
        });
    },
    "4c89": function(e, t, a) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = o(a("3b18")), c = o(a("c8bc"));
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var r = function() {
                return Promise.all([ a.e("common/vendor"), a.e("yb_shopv2/module/ModuleGoodList") ]).then(a.bind(null, "47e1"));
            }, s = {
                mixins: [ n.default, c.default ],
                data: function() {
                    return {
                        show_cancel: !1,
                        search_val: "",
                        search_placeholder: "",
                        search_type: "",
                        curr_kw: "",
                        search_keyword: [],
                        list: [],
                        page_path: "pages/search/index",
                        globle: getApp().common.globle,
                        page: 1,
                        end: !1,
                        init: !0
                    };
                },
                components: {
                    ModuleGoodList: r
                },
                methods: {
                    page_onLoad: function(e) {
                        console.log("search_op", e), this.title = e.type_name, this.search_placeholder = e.search_tip, 
                        e.search_article && e.search_product ? this.search_type = "article,product" : e.search_article ? this.search_type = "article" : e.search_product && (this.search_type = "product"), 
                        console.log(this.search_type), e.search_keyword && (this.search_keyword = e.search_keyword.split(","), 
                        console.log("search_keyword", this.search_keyword));
                    },
                    page_onPullDownRefresh: function() {
                        e.showLoading({
                            title: "加载中"
                        }), this.page = 1, this.end = !1, this.search(this.search_val, "");
                    },
                    page_onReachBottom: function() {
                        this.end || this.search(this.search_val, "");
                    },
                    search: function(t, a) {
                        var n = this;
                        n.curr_kw != t && (n.page = 1, n.end = !1, n.list = []), n.curr_kw != t || "click" != a ? (n.curr_kw = t, 
                        t && (n.search_val = t), "" != n.search_val ? getApp().Req.get("search_data", {
                            search_val: n.search_val,
                            search_type: n.search_type,
                            page: n.page
                        }, function(t) {
                            if (n.init = !1, e.hideLoading(), e.stopPullDownRefresh(), console.log("search_res", t), 
                            200 == t.code) {
                                if (1 === n.page && t.info && t.info.length > 0 && (n.list = []), 1 === n.page && 0 == t.info.length && (n.list = []), 
                                n.list = n.list.concat(t.info), t.info.length < 10) return void (n.end = !0);
                                n.page += 1, n.list = t.info;
                            }
                        }) : e.hideLoading()) : e.hideLoading();
                    },
                    goDetail: function(e, t) {
                        console.log("id=" + e + ";table_name=" + t);
                        var a = this, n = {
                            type: t,
                            id: e
                        };
                        a.jump(n);
                    },
                    cancel: function() {
                        var e = this;
                        e.list = [], e.curr_kw = "";
                    }
                }
            };
            t.default = s;
        }).call(this, a("543d")["default"]);
    },
    5578: function(e, t, a) {},
    6750: function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a("1244"), c = a("6887");
        for (var o in c) "default" !== o && function(e) {
            a.d(t, e, function() {
                return c[e];
            });
        }(o);
        a("6b7c");
        var r = a("2877"), s = Object(r["a"])(c["default"], n["a"], n["b"], !1, null, null, null);
        t["default"] = s.exports;
    },
    6887: function(e, t, a) {
        "use strict";
        a.r(t);
        var n = a("4c89"), c = a.n(n);
        for (var o in n) "default" !== o && function(e) {
            a.d(t, e, function() {
                return n[e];
            });
        }(o);
        t["default"] = c.a;
    },
    "6b7c": function(e, t, a) {
        "use strict";
        var n = a("5578"), c = a.n(n);
        c.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/search/index-create-component", {
    "yb_shopv2/pages/search/index-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("6750"));
    }
}, [ [ "yb_shopv2/pages/search/index-create-component" ] ] ]);