(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/invitation-group/invitation-group" ], {
    "11bf": function(o, t, u) {
        "use strict";
        (function(o) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = i(u("c8bc")), e = i(u("3b18")), a = u("b1b6");
            function i(o) {
                return o && o.__esModule ? o : {
                    default: o
                };
            }
            var n = function() {
                return Promise.all([ u.e("common/vendor"), u.e("yb_shopv2/module/ModuleGoodList") ]).then(u.bind(null, "47e1"));
            }, d = {
                name: "invitation-group",
                data: function() {
                    return {
                        groupNo: 0,
                        list: [],
                        groupCount: 0,
                        avatarList: [],
                        orderId: 0,
                        groupStatus: 0,
                        goodId: 0,
                        defaultAvatar: u("5140")
                    };
                },
                mixins: [ r.default, e.default ],
                computed: {
                    groupFinish: function() {
                        return this.avatarList.length >= this.groupCount;
                    }
                },
                methods: {
                    page_onLoad: function(t) {
                        this.groupNo = t.group_no, console.log(t, "启动参数启动参数启动参数启动参数启动参数启动参数启动参数启动参数启动参数启动参数启动参数启动参数启动参数启动参数启动参数"), 
                        o.showLoading(), this.getGroupDetail();
                    },
                    page_onPullDownRefresh: function() {
                        this.getGroupDetail();
                    },
                    getGroupDetail: function() {
                        var t = this;
                        (0, a.get)("Group_getUserGroup", {
                            group_no: this.groupNo,
                            user_id: getApp().user.userid
                        }).then(function(u) {
                            o.hideLoading(), o.stopPullDownRefresh(), console.log(u, "拼团详情拼团详情拼团详情拼团详情拼团详情拼团详情拼团详情拼团详情拼团详情拼团详情拼团详情拼团详情"), 
                            t.groupCount = u.data.group.group_success, t.avatarList = u.data.group_user, t.list = [ {
                                endTime: 1e3 * u.data.group.end_time,
                                image: u.data.group.pic,
                                title: u.data.group.goods_name,
                                price: u.data.group.activity_price,
                                cate: "".concat(u.data.group.group_success, "人团").concat(u.data.group.group_virtual ? " · 已团" + u.data.group.group_virtual + "人" : ""),
                                link: {
                                    type: "goods",
                                    id: u.data.group.id,
                                    activity: "group"
                                }
                            } ], t.orderId = u.data.group.order_id, t.groupStatus = u.data.group.group_order_status, 
                            t.goodId = u.data.group.id, console.log(u, "ggggggggggggggggggggg");
                        });
                    },
                    goToOrderDetail: function() {
                        this.jump({
                            type: "order_detail",
                            order_id: this.orderId
                        });
                    },
                    goToGoodsDetail: function(o) {
                        "new" === o ? this.jump({
                            type: "goods",
                            id: this.goodId,
                            activity: "group"
                        }) : this.jump({
                            type: "goods",
                            id: this.goodId,
                            group_no: this.groupNo,
                            activity: "group"
                        });
                    }
                },
                components: {
                    ModuleGoodList: n
                }
            };
            t.default = d;
        }).call(this, u("543d")["default"]);
    },
    1550: function(o, t, u) {},
    "49ab": function(o, t, u) {
        "use strict";
        u.r(t);
        var r = u("11bf"), e = u.n(r);
        for (var a in r) "default" !== a && function(o) {
            u.d(t, o, function() {
                return r[o];
            });
        }(a);
        t["default"] = e.a;
    },
    "69c8": function(o, t, u) {
        "use strict";
        u.r(t);
        var r = u("766b"), e = u("49ab");
        for (var a in e) "default" !== a && function(o) {
            u.d(t, o, function() {
                return e[o];
            });
        }(a);
        u("a0da");
        var i = u("2877"), n = Object(i["a"])(e["default"], r["a"], r["b"], !1, null, null, null);
        t["default"] = n.exports;
    },
    "766b": function(o, t, u) {
        "use strict";
        var r = function() {
            var o = this, t = o.$createElement;
            o._self._c;
        }, e = [];
        u.d(t, "a", function() {
            return r;
        }), u.d(t, "b", function() {
            return e;
        });
    },
    a0da: function(o, t, u) {
        "use strict";
        var r = u("1550"), e = u.n(r);
        e.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/invitation-group/invitation-group-create-component", {
    "yb_shopv2/pages/invitation-group/invitation-group-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("69c8"));
    }
}, [ [ "yb_shopv2/pages/invitation-group/invitation-group-create-component" ] ] ]);