(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/member/about" ], {
    "3e61": function(e, t, n) {
        "use strict";
        var a = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, i = [];
        n.d(t, "a", function() {
            return a;
        }), n.d(t, "b", function() {
            return i;
        });
    },
    "7c1c4": function(e, t, n) {
        "use strict";
        var a = n("dc0d"), i = n.n(a);
        i.a;
    },
    a07e: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("3e61"), i = n("bfd5");
        for (var u in i) "default" !== u && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(u);
        n("7c1c4");
        var o = n("2877"), r = Object(o["a"])(i["default"], a["a"], a["b"], !1, null, null, null);
        t["default"] = r.exports;
    },
    bfd5: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("fa58"), i = n.n(a);
        for (var u in a) "default" !== u && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(u);
        t["default"] = i.a;
    },
    dc0d: function(e, t, n) {},
    fa58: function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = u(n("c8bc")), i = u(n("3b18"));
            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var o = function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/mpvue-wxparse/wxParse") ]).then(n.bind(null, "6bf0"));
            }, r = {
                mixins: [ a.default, i.default ],
                data: function() {
                    return {
                        id: "",
                        detail: {},
                        page_path: "pages/member/about",
                        currentData: 0,
                        clientHeight: ""
                    };
                },
                components: {
                    wxParse: o
                },
                methods: {
                    page_onLoad: function(t) {
                        this.id = t.id, e.showLoading({
                            title: "加载中"
                        }), this.getPageData();
                    },
                    getPageData: function() {
                        var t = this;
                        getApp().Req.get("Site_GetSiteAbout", {
                            id: this.id
                        }, function(n) {
                            e.hideLoading();
                            var a = n.info;
                            a.desc = a.desc.replace(/\<img/gi, '<img style="width:100%;height:auto" '), t.detail = a, 
                            t.title = n.info.name;
                        });
                    },
                    map: function() {
                        var e = this, t = {
                            type: "map",
                            type_name: e.detail.name,
                            id: "",
                            url: JSON.parse(e.detail.postion),
                            title: e.detail.name
                        };
                        e.jump(t);
                    },
                    phone: function() {
                        var e = this, t = {
                            type: "phone",
                            type_name: e.detail.phone,
                            id: "",
                            url: e.detail.phone,
                            title: e.detail.phone
                        };
                        e.jump(t);
                    }
                }
            };
            t.default = r;
        }).call(this, n("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/member/about-create-component", {
    "yb_shopv2/pages/member/about-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("a07e"));
    }
}, [ [ "yb_shopv2/pages/member/about-create-component" ] ] ]);