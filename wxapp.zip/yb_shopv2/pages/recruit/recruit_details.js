(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/recruit/recruit_details" ], {
    "0018": function(t, e, n) {
        "use strict";
        var i = n("7cb8"), a = n.n(i);
        a.a;
    },
    "06f3": function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("986b"), a = n.n(i);
        for (var o in i) "default" !== o && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e["default"] = a.a;
    },
    5811: function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("dbac"), a = n("06f3");
        for (var o in a) "default" !== o && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n("0018");
        var u = n("2877"), c = Object(u["a"])(a["default"], i["a"], i["b"], !1, null, null, null);
        e["default"] = c.exports;
    },
    "7cb8": function(t, e, n) {},
    "986b": function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = a(n("3b18"));
            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var o = function() {
                return Promise.all([ n.e("common/vendor"), n.e("components/mpvue-wxparse/wxParse") ]).then(n.bind(null, "6bf0"));
            }, u = {
                mixins: [ i.default ],
                data: function() {
                    return {
                        type: "recruit_details",
                        id: "",
                        detail: {},
                        page_path: "pages/recruit/recruit_details"
                    };
                },
                components: {
                    wxParse: o
                },
                methods: {
                    page_onLoad: function(e) {
                        this.id = e.id, t.showLoading({
                            title: "加载中"
                        }), this.getPageData();
                    },
                    getPageData: function() {
                        var e = this;
                        getApp().Req.get("recruit_details", {
                            id: this.id
                        }, function(n) {
                            t.hideLoading(), console.log("进入新的方法"), e.detail = n.info;
                        });
                    },
                    call: function() {
                        var e = this;
                        console.log(this.detail), t.showModal({
                            title: "提示",
                            content: "向 " + this.detail.name + " 拨打电话？",
                            showCancel: !0,
                            cancelText: "取消",
                            confirmText: "拨打",
                            success: function(n) {
                                console.log(n), 1 == n.confirm && t.makePhoneCall({
                                    phoneNumber: e.detail.mobile
                                });
                            }
                        });
                    }
                }
            };
            e.default = u;
        }).call(this, n("543d")["default"]);
    },
    dbac: function(t, e, n) {
        "use strict";
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
        n.d(e, "a", function() {
            return i;
        }), n.d(e, "b", function() {
            return a;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/recruit/recruit_details-create-component", {
    "yb_shopv2/pages/recruit/recruit_details-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("5811"));
    }
}, [ [ "yb_shopv2/pages/recruit/recruit_details-create-component" ] ] ]);