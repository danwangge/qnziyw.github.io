(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/confirm-order/confirm-order" ], {
    "053e": function(e, t, i) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = s(i("c8bc")), n = s(i("3b18")), o = (s(i("21b4")), i("b1b6"));
            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var a = function() {
                return i.e("yb_shopv2/component/CustomPrimaryList").then(i.bind(null, "a6ff"));
            }, d = function() {
                return Promise.all([ i.e("common/vendor"), i.e("yb_shopv2/module/ModuleGoodList") ]).then(i.bind(null, "47e1"));
            }, c = {
                name: "confirm-order",
                props: {
                    params: {
                        type: String,
                        default: "[]"
                    }
                },
                data: function() {
                    return {
                        orderData: {
                            freightPrice: "5.00",
                            discountPrice: "10.00"
                        },
                        productData: [],
                        canUseDeliverList: [],
                        activeDeliverMethod: -1,
                        canUseCouponList: [],
                        activeCouponMethod: -1,
                        canUsePayList: [ {
                            value: 0,
                            label: "微信"
                        } ],
                        activePayMethod: -1,
                        chooseAddress: {
                            id: 0,
                            title: "暂无收货地址",
                            right: "去添加",
                            link: {
                                type: "address",
                                parent: "confirm_order_address"
                            }
                        },
                        totalPrice: 0,
                        goodsPrice: 0,
                        deliverPrice: 0,
                        couponPrice: 0,
                        remark: "",
                        orderTimer: null,
                        page_path: "pages/confirm-order/confirm-order",
                        receiverName: "",
                        receiverPhone: "",
                        selfMentionIndex: -1,
                        selfmentionList: [],
                        errorMessage: "",
                        orderType: 1,
                        activityId: 0,
                        launchId: 0,
                        integral: 0,
                        cutMoney: 0,
                        groupNo: ""
                    };
                },
                mixins: [ r.default, n.default ],
                computed: {
                    selfAddress: function() {
                        return [ {
                            title: "选择自提点",
                            right: -1 !== this.selfMentionIndex && this.selfmentionList.length ? this.selfmentionList[this.selfMentionIndex].consigner : "请选择自提点",
                            link: {
                                type: "address",
                                parent: "confirm_order_selfmention",
                                list: JSON.stringify(this.selfmentionList)
                            }
                        }, {
                            title: "提货人姓名",
                            rightType: "input",
                            name: "receiverName",
                            hiddenArrow: !0,
                            input: {
                                value: this.receiverName,
                                placeholder: "输入提货人姓名"
                            }
                        }, {
                            title: "提货人手机号",
                            rightType: "input",
                            name: "receiverPhone",
                            hiddenArrow: !0,
                            input: {
                                value: this.receiverPhone,
                                placeholder: "输入提货人手机号"
                            }
                        } ];
                    },
                    noSubmitOrder: function() {
                        return 2 === this.activeDeliverMethod || this.chooseAddress.id ? 2 !== this.activeDeliverMethod || -1 !== this.selfMentionIndex && this.receiverName && this.receiverPhone ? !(3 !== this.activeDeliverMethod || !this.errorMessage) && this.errorMessage : "请确认自提信息" : "请确认收货地址";
                    },
                    allPrice: function() {
                        return (0 === this.productData.length ? 0 : 1 === this.productData.length ? this.productData[0].count * Number(this.productData[0].price) : this.productData.reduce(function(e, t) {
                            return "object" === typeof e ? e.count * Number(e.price) + t.count * Number(t.price) : e + t.count * Number(t.price);
                        })).toFixed(2);
                    },
                    allCount: function() {
                        return 0 === this.productData.length ? 0 : 1 === this.productData.length ? this.productData[0].count : this.productData.reduce(function(e, t) {
                            return "object" === typeof e ? e.count + t.count : e + t.count;
                        });
                    },
                    deliverMethods: function() {
                        var e = this;
                        return this.canUseDeliverList.length ? (this.canUseDeliverList.find(function(t) {
                            return e.activeDeliverMethod === t.value;
                        }) || (this.activeDeliverMethod = this.canUseDeliverList[0].value, this.getPayConfig()), 
                        {
                            title: "配送方式",
                            listName: "Deliver",
                            rightType: "picker",
                            pickerRange: this.canUseDeliverList,
                            pickerMode: "selector",
                            picker: {
                                value: this.activeDeliverMethod
                            }
                        }) : (this.activeDeliverMethod = -1, {
                            title: "配送方式",
                            right: "包邮",
                            hiddenArrow: !0
                        });
                    },
                    canCouponInfo: function() {
                        var e = this;
                        return this.canUseCouponList.length ? (this.canUseCouponList.find(function(t) {
                            return e.activeCouponMethod === t.value;
                        }) || (this.activeCouponMethod = this.canUseCouponList[0].value, this.getPayConfig()), 
                        {
                            title: "使用优惠券",
                            listName: "Coupon",
                            rightType: "picker",
                            pickerMode: "selector",
                            pickerRange: this.canUseCouponList,
                            pickerRangeKey: "name",
                            picker: {
                                value: this.activeCouponMethod
                            }
                        }) : (this.activeCouponMethod = -1, {
                            title: "使用优惠券",
                            right: "暂无可用优惠券",
                            hiddenArrow: !0,
                            hidden: 1 !== this.orderType
                        });
                    },
                    useIntegral: function() {
                        return 5 !== this.orderType ? {
                            title: "使用积分",
                            right: "该商品不能使用积分",
                            hiddenArrow: !0,
                            hidden: !0
                        } : {
                            title: "积分换购",
                            right: "消耗".concat(this.integral, "积分"),
                            hiddenArrow: !0
                        };
                    },
                    payMethod: function() {
                        var e = this;
                        return 1 === this.canUsePayList.length ? (this.activePayMethod = this.canUsePayList[0].value, 
                        {
                            title: "支付方式",
                            right: this.canUsePayList[0].label,
                            hiddenArrow: !0
                        }) : this.canUsePayList.length ? (this.canUsePayList.find(function(t) {
                            return e.activePayMethod === t.value;
                        }) || (this.activePayMethod = this.canUsePayList[0].value, this.getPayConfig()), 
                        {
                            title: "支付方式",
                            listName: "Pay",
                            rightType: "picker",
                            pickerRangeKey: "name",
                            pickerMode: "selector",
                            pickerRange: this.canUsePayList,
                            picker: {
                                value: this.activePayMethod
                            }
                        }) : void 0;
                    },
                    payInfo: function() {
                        return [ this.payMethod, this.deliverMethods, {
                            title: "留言",
                            rightType: "input",
                            hiddenArrow: !0,
                            name: "remark",
                            input: {
                                value: "",
                                placeholder: "选填，请先和商家协商一致",
                                width: 400
                            }
                        }, this.useIntegral, this.canCouponInfo ];
                    },
                    moneyInfo: function() {
                        return [ {
                            title: "商品金额",
                            tag: "(共".concat(this.allCount, "件商品)"),
                            right: "¥ ".concat(this.goodsPrice),
                            hiddenArrow: !0
                        }, {
                            title: "好友帮砍",
                            right: "- ¥ ".concat(this.cutMoney),
                            hiddenArrow: !0,
                            rightStyle: "color: #f83e3a",
                            hidden: !this.cutMoney
                        }, {
                            title: "运费",
                            right: "+ ¥ ".concat(this.deliverPrice),
                            hiddenArrow: !0,
                            rightStyle: "color: #f83e3a",
                            hidden: 0 === this.deliverPrice
                        }, {
                            title: "优惠券",
                            right: "- ¥ ".concat(this.couponPrice),
                            hiddenArrow: !0,
                            rightStyle: "color: #f83e3a",
                            hidden: 0 === this.couponPrice
                        } ];
                    },
                    orderPrice: function() {
                        return (Number(this.allPrice) + Number(this.orderData.freightPrice) - Number(this.orderData.discountPrice)).toFixed(2);
                    }
                },
                filters: {
                    formatterPriceYuan: function(e) {
                        return e ? e.match(/^\S+\./)[0] : "";
                    },
                    formatterPriceFen: function(e) {
                        return e ? e.replace(/^\S+\./, "") : "";
                    }
                },
                components: {
                    CustomPrimaryList: a,
                    ModuleGoodList: d
                },
                methods: {
                    getUserConfigAddress: function() {
                        var e = this;
                        getApp().userAddress.length ? (this.getCheckedAddress(), this.getPayConfig()) : this.getUserAddress().then(function() {
                            e.getCheckedAddress(), e.getPayConfig();
                        });
                    },
                    page_onShow: function() {
                        this.getUserConfigAddress();
                    },
                    page_onPullDownRefresh: function() {
                        e.stopPullDownRefresh();
                    },
                    page_onLoad: function(t) {
                        this.title = "确认订单", e.setNavigationBarColor({
                            frontColor: "#000000",
                            backgroundColor: "#ffffff"
                        }), this.orderType = Number(t.order_type), this.activityId = Number(t.activity_id), 
                        this.launchId = Number(t.launch_id), this.groupNo = "null" !== t.group_no && t.group_no || "";
                        try {
                            this.productData = JSON.parse(this.params);
                        } catch (t) {
                            this.productData = [];
                        }
                    },
                    getCheckedAddress: function() {
                        var e = getApp().userAddress.filter(function(e) {
                            return e.checked;
                        })[0];
                        if (!e) {
                            var t = getApp().userAddress.findIndex(function(e) {
                                return e.default && !e.edit;
                            });
                            -1 !== t && (getApp().userAddress[t].checked = 1, e = getApp().userAddress[t]);
                        }
                        e && (this.chooseAddress = {
                            id: e.id,
                            title: "".concat(e.consigner, "  ").concat(e.phone),
                            desc: "".concat(e.area.join("  "), "  ").concat(e.address),
                            icon: "../../static/icon/icon_address_36.png",
                            link: {
                                type: "address",
                                parent: "confirm_order_address"
                            }
                        });
                    },
                    getUserAddress: function() {
                        return (0, o.get)("Member_userAddressList", {
                            user_id: getApp().user.userid
                        }).then(function(e) {
                            return getApp().userAddress = e.data.map(function(e) {
                                return {
                                    id: e.id,
                                    areaCode: e.area,
                                    area: [ e.province, e.city, e.district ],
                                    consigner: e.consigner,
                                    phone: e.phone,
                                    address: e.address,
                                    default: e.is_default,
                                    edit: 0,
                                    postcode: e.zip_code,
                                    checked: !!e.is_default
                                };
                            }), Promise.resolve();
                        });
                    },
                    getPayConfig: function() {
                        var t = this;
                        this.orderTimer || (this.orderTimer = setTimeout(function() {
                            t.orderTimer = null, (0, o.get)("Order_orderPrice", Object.assign(t.chooseAddress.id ? {
                                address_id: t.chooseAddress.id
                            } : {}, -1 !== t.activeCouponMethod ? {
                                coupon_id: t.activeCouponMethod
                            } : {}, -1 !== t.activeDeliverMethod ? {
                                deliver_type: t.activeDeliverMethod
                            } : {
                                deliver_type: 1
                            }, -1 !== t.activePayMethod ? {
                                pay_type: t.activePayMethod
                            } : {}, t.activityId ? {
                                activity_id: t.activityId
                            } : {}, t.launchId ? {
                                launch_id: t.launchId
                            } : {}, t.groupNo ? {
                                group_no: t.groupNo
                            } : {}, {
                                user_id: getApp().user.userid,
                                order_type: t.orderType,
                                goods: JSON.stringify(t.productData.map(function(e) {
                                    return {
                                        goods_id: e.id,
                                        sku_id: e.skuId,
                                        num: e.count,
                                        template_id: e.shoppingId
                                    };
                                }))
                            })).then(function(i) {
                                console.log(i, "计算价格计算价格计算价格计算价格计算价格计算价格计算价格计算价格计算价格计算价格计算价格");
                                var r = {
                                    deliver: {
                                        id: 1,
                                        name: "快递配送"
                                    },
                                    self_mention: {
                                        id: 2,
                                        name: "到店自提"
                                    },
                                    same_city: {
                                        id: 3,
                                        name: "同城配送"
                                    }
                                };
                                t.totalPrice = i.data.total_price.toFixed(2), t.goodsPrice = Number(i.data.goods_prices.toFixed(2)), 
                                t.deliverPrice = Number(i.data.deliver_cost.toFixed(2)), t.couponPrice = Number(i.data.coupon_price.toFixed(2)), 
                                t.integral = Number(i.data.integral), t.cutMoney = Number(i.data.cut_money && i.data.cut_money.toFixed(2) || 0), 
                                t.selfmentionList = i.data.selfmention_list.map(function(e) {
                                    var t = JSON.parse(e.address);
                                    return {
                                        edit: !1,
                                        area: [ t.province, t.city, t.district ],
                                        address: t.addr,
                                        phone: e.mobile,
                                        consigner: e.name,
                                        id: e.id,
                                        link: {
                                            type: "map",
                                            url: {
                                                lat: t.postion_lat,
                                                lng: t.postion_lng,
                                                address: t.addr,
                                                city: t.city
                                            }
                                        },
                                        checked: !1
                                    };
                                }), 2 === t.activeDeliverMethod && (e.$off("set_selfmention"), e.$on("set_selfmention", function(e) {
                                    t.selfMentionIndex = e;
                                })), t.canUseDeliverList = i.data.deliver_type.map(function(e) {
                                    return e.label = r[e.key].name, e.value = r[e.key].id, e;
                                }), t.canUseCouponList = i.data.coupon_list.length ? i.data.coupon_list.map(function(e) {
                                    return e.label = e.title, e.value = e.id, e;
                                }).concat([ {
                                    value: 0,
                                    label: "不使用优惠券"
                                } ]) : [], t.errorMessage = "";
                            }).catch(function(e) {
                                t.errorMessage = e.message;
                            });
                        }, 100));
                    },
                    goPay: function() {
                        var t = this;
                        !1 === this.noSubmitOrder ? this.loading || (this.loading = !0, (0, o.get)("Order_createOrder", Object.assign(this.chooseAddress.id ? {
                            address_id: this.chooseAddress.id
                        } : {}, -1 !== this.activeCouponMethod ? {
                            coupon_id: this.activeCouponMethod
                        } : {}, -1 !== this.activePayMethod ? {
                            pay_type: this.activePayMethod
                        } : {}, -1 !== this.selfMentionIndex ? {
                            self_mention_id: this.selfmentionList[this.selfMentionIndex].id,
                            receiver_name: this.receiverName,
                            receiver_phone: this.receiverPhone
                        } : {}, this.activityId ? {
                            activity_id: this.activityId
                        } : {}, this.launchId ? {
                            launch_id: this.launchId
                        } : {}, this.groupNo ? {
                            group_no: this.groupNo
                        } : {}, {
                            deliver_type: -1 === this.activeDeliverMethod ? 1 : this.activeDeliverMethod,
                            user_id: getApp().user.userid,
                            buyer_remarks: this.remark,
                            order_type: this.orderType,
                            goods: JSON.stringify(this.productData.map(function(e) {
                                return {
                                    goods_id: e.id,
                                    sku_id: e.skuId,
                                    num: e.count,
                                    template_id: e.shoppingId
                                };
                            }))
                        })).then(function(e) {
                            return (0, o.payRequest)({
                                order_no: e.data.order_no,
                                order_type: 0,
                                is_pay: e.data.is_pay,
                                order_id: e.data.order_id
                            });
                        }).then(function(e) {
                            t.loading = !1;
                        }).catch(function(t) {
                            e.showToast({
                                title: t.msg
                            });
                        })) : e.showToast({
                            title: this.noSubmitOrder,
                            icon: "none"
                        });
                    },
                    changeGoodCount: function(e, t, i) {
                        this.productData[e].count = t, this.getPayConfig();
                    },
                    handlerListPicker: function(e, t, i) {
                        this["active".concat(e.listName, "Method")] = this["canUse".concat(e.listName, "List")][t].value, 
                        this.getPayConfig();
                    },
                    handlerListInput: function(e, t, i, r) {
                        this[e.name] = t;
                    },
                    selfAddressChange: function(e, t, i) {
                        this.selfMentionIndex = t;
                    }
                }
            };
            t.default = c;
        }).call(this, i("543d")["default"]);
    },
    "49c4": function(e, t, i) {
        "use strict";
        i.r(t);
        var r = i("053e"), n = i.n(r);
        for (var o in r) "default" !== o && function(e) {
            i.d(t, e, function() {
                return r[e];
            });
        }(o);
        t["default"] = n.a;
    },
    9049: function(e, t, i) {},
    9137: function(e, t, i) {
        "use strict";
        i.r(t);
        var r = i("dd38"), n = i("49c4");
        for (var o in n) "default" !== o && function(e) {
            i.d(t, e, function() {
                return n[e];
            });
        }(o);
        i("e77c");
        var s = i("2877"), a = Object(s["a"])(n["default"], r["a"], r["b"], !1, null, null, null);
        t["default"] = a.exports;
    },
    dd38: function(e, t, i) {
        "use strict";
        var r = function() {
            var e = this, t = e.$createElement, i = (e._self._c, e._f("formatterPriceYuan")(e.totalPrice)), r = e._f("formatterPriceFen")(e.totalPrice);
            e.$mp.data = Object.assign({}, {
                $root: {
                    f0: i,
                    f1: r
                }
            });
        }, n = [];
        i.d(t, "a", function() {
            return r;
        }), i.d(t, "b", function() {
            return n;
        });
    },
    e77c: function(e, t, i) {
        "use strict";
        var r = i("9049"), n = i.n(r);
        n.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/confirm-order/confirm-order-create-component", {
    "yb_shopv2/pages/confirm-order/confirm-order-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("9137"));
    }
}, [ [ "yb_shopv2/pages/confirm-order/confirm-order-create-component" ] ] ]);