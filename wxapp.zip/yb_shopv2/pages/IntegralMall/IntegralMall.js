(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/IntegralMall/IntegralMall" ], {
    "0511": function(t, n, o) {
        "use strict";
        var e = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, a = [];
        o.d(n, "a", function() {
            return e;
        }), o.d(n, "b", function() {
            return a;
        });
    },
    "304b": function(t, n, o) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = i(o("3b18")), a = i(o("c8bc"));
            o("21b4");
            function i(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var f = function() {
                return o.e("yb_shopv2/component/CustomNoData").then(o.bind(null, "8a57"));
            }, s = {
                components: {
                    nodata: f
                },
                mixins: [ e.default, a.default ],
                data: function() {
                    return {
                        pageHeight: "",
                        page: 1,
                        nodata: !1,
                        goodsInfo: [],
                        integral: 0
                    };
                },
                created: function() {},
                methods: {
                    page_onLoad: function(n) {
                        t.showLoading({
                            title: "加载中"
                        }), this.title = "积分商城", t.setNavigationBarColor({
                            frontColor: "#ffffff",
                            backgroundColor: "#EE4049"
                        }), this.getIntegral(), this.getGoodsInfo();
                    },
                    page_onPullDownRefresh: function() {
                        this.page = 1, this.getGoodsInfo(), this.getIntegral();
                    },
                    page_onReachBottom: function() {
                        this.nodata || (this.page += 1, this.getGoodsInfo());
                    },
                    getIntegral: function() {
                        var n = this;
                        getApp().Req.get("Member_getMember", {
                            user_id: getApp().user.userid
                        }, function(t) {
                            n.integral = t.data.integral, console.log(t, "成功获取积分");
                        }, function(n) {
                            t.showToast({
                                icon: "none",
                                title: n.msg
                            });
                        });
                    },
                    getGoodsInfo: function() {
                        var n = this;
                        1 == n.page && (n.goodsInfo = []), getApp().Req.get("Integralmall_getIntegralGoodsList", {
                            is_recommend: 0,
                            page: n.page
                        }, function(o) {
                            n.goodsInfo = n.goodsInfo.concat(o.data), 0 === o.data.length ? n.nodata = !0 : n.nodata = !1, 
                            t.stopPullDownRefresh(), t.hideLoading(), console.log(o, "成功获取商品列表");
                        }, function(n) {
                            t.stopPullDownRefresh(), t.hideLoading(), t.showToast({
                                icon: "none",
                                title: n.msg
                            });
                        });
                    }
                }
            };
            n.default = s;
        }).call(this, o("543d")["default"]);
    },
    "44ff": function(t, n, o) {},
    "8c04": function(t, n, o) {
        "use strict";
        o.r(n);
        var e = o("304b"), a = o.n(e);
        for (var i in e) "default" !== i && function(t) {
            o.d(n, t, function() {
                return e[t];
            });
        }(i);
        n["default"] = a.a;
    },
    d93c: function(t, n, o) {
        "use strict";
        o.r(n);
        var e = o("0511"), a = o("8c04");
        for (var i in a) "default" !== i && function(t) {
            o.d(n, t, function() {
                return a[t];
            });
        }(i);
        o("fe30");
        var f = o("2877"), s = Object(f["a"])(a["default"], e["a"], e["b"], !1, null, null, null);
        n["default"] = s.exports;
    },
    fe30: function(t, n, o) {
        "use strict";
        var e = o("44ff"), a = o.n(e);
        a.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/IntegralMall/IntegralMall-create-component", {
    "yb_shopv2/pages/IntegralMall/IntegralMall-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("d93c"));
    }
}, [ [ "yb_shopv2/pages/IntegralMall/IntegralMall-create-component" ] ] ]);