(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/bargain-record/bargain-record" ], {
    "135f": function(t, n, a) {
        "use strict";
        var e = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, i = [];
        a.d(n, "a", function() {
            return e;
        }), a.d(n, "b", function() {
            return i;
        });
    },
    "5f79": function(t, n, a) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = o(a("3b18")), i = o(a("c8bc")), u = o(a("ffc5")), c = a("b1b6");
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var d = function() {
                return a.e("yb_shopv2/component/CustomNoData").then(a.bind(null, "8a57"));
            }, r = {
                name: "bargain-record",
                data: function() {
                    return {
                        list: [],
                        launchId: 0,
                        activityId: 0,
                        init: !0,
                        defaultAvatar: a("5140")
                    };
                },
                mixins: [ e.default, i.default, u.default ],
                components: {
                    CustomNoData: d
                },
                methods: {
                    page_onLoad: function(n) {
                        this.title = "帮砍记录", this.launchId = n.launch_id, this.activityId = n.activity_id, 
                        t.showLoading(), this.getPageData();
                    },
                    getPageData: function() {
                        var n = this;
                        (0, c.get)("Bargain_getHelpList", {
                            launch_id: this.launchId,
                            activityId: this.activityId
                        }).then(function(a) {
                            t.hideLoading(), t.stopPullDownRefresh(), console.log(a, "砍价记录砍价记录砍价记录砍价记录砍价记录砍价记录砍价记录砍价记录砍价记录砍价记录砍价记录砍价记录"), 
                            n.list = 1 === n.page ? a.data : n.list.concat(a.data), a.data.length < 20 && (n.end = !0), 
                            n.init = !1;
                        }).catch(function(t) {
                            n.init = !1;
                        });
                    }
                }
            };
            n.default = r;
        }).call(this, a("543d")["default"]);
    },
    "6e27": function(t, n, a) {
        "use strict";
        a.r(n);
        var e = a("135f"), i = a("be08");
        for (var u in i) "default" !== u && function(t) {
            a.d(n, t, function() {
                return i[t];
            });
        }(u);
        a("c85d");
        var c = a("2877"), o = Object(c["a"])(i["default"], e["a"], e["b"], !1, null, null, null);
        n["default"] = o.exports;
    },
    be08: function(t, n, a) {
        "use strict";
        a.r(n);
        var e = a("5f79"), i = a.n(e);
        for (var u in e) "default" !== u && function(t) {
            a.d(n, t, function() {
                return e[t];
            });
        }(u);
        n["default"] = i.a;
    },
    c85d: function(t, n, a) {
        "use strict";
        var e = a("fc8d"), i = a.n(e);
        i.a;
    },
    fc8d: function(t, n, a) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/bargain-record/bargain-record-create-component", {
    "yb_shopv2/pages/bargain-record/bargain-record-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("6e27"));
    }
}, [ [ "yb_shopv2/pages/bargain-record/bargain-record-create-component" ] ] ]);