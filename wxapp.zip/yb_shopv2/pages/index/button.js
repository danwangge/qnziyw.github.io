(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/button" ], {
    "0058": function(t, n, e) {
        "use strict";
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, a = [];
        e.d(n, "a", function() {
            return u;
        }), e.d(n, "b", function() {
            return a;
        });
    },
    "1ace": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("5b4b"), a = e.n(u);
        for (var r in u) "default" !== r && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(r);
        n["default"] = a.a;
    },
    4833: function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("0058"), a = e("1ace");
        for (var r in a) "default" !== r && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        var c = e("2877"), f = Object(c["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        n["default"] = f.exports;
    },
    "5b4b": function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = a(e("c8bc"));
        function a(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var r = {
            mixins: [ u.default ]
        };
        n.default = r;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/button-create-component", {
    "yb_shopv2/pages/index/button-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("4833"));
    }
}, [ [ "yb_shopv2/pages/index/button-create-component" ] ] ]);