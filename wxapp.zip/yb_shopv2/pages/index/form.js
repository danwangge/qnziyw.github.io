(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/form" ], {
    "13de": function(e, t, i) {},
    1636: function(e, t, i) {
        "use strict";
        var o = i("13de"), r = i.n(o);
        r.a;
    },
    2260: function(e, t, i) {
        "use strict";
        var o = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, r = [];
        i.d(t, "a", function() {
            return o;
        }), i.d(t, "b", function() {
            return r;
        });
    },
    "5ca5": function(e, t, i) {
        "use strict";
        i.r(t);
        var o = i("c7e7"), r = i.n(o);
        for (var n in o) "default" !== n && function(e) {
            i.d(t, e, function() {
                return o[e];
            });
        }(n);
        t["default"] = r.a;
    },
    c7e7: function(e, t, i) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = n(i("a34a")), r = n(i("c8bc"));
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function s(e, t, i, o, r, n, s) {
                try {
                    var a = e[n](s), f = a.value;
                } catch (u) {
                    return void i(u);
                }
                a.done ? t(f) : Promise.resolve(f).then(o, r);
            }
            function a(e) {
                return function() {
                    var t = this, i = arguments;
                    return new Promise(function(o, r) {
                        var n = e.apply(t, i);
                        function a(e) {
                            s(n, o, r, a, f, "next", e);
                        }
                        function f(e) {
                            s(n, o, r, a, f, "throw", e);
                        }
                        a(void 0);
                    });
                };
            }
            var f = function() {
                return i.e("components/sunui-upimg/sunui-upimg-basic").then(i.bind(null, "7efb"));
            }, u = {
                created: function() {
                    var e = this;
                    if (void 0 != e.item.list[0]) {
                        var t = JSON.parse(JSON.stringify(e.item.list[0])), i = !0, o = !1, r = void 0;
                        try {
                            for (var n, s = t.values[Symbol.iterator](); !(i = (n = s.next()).done); i = !0) {
                                var a = n.value;
                                a.date_value = "", a.default_value = "";
                            }
                        } catch (f) {
                            o = !0, r = f;
                        } finally {
                            try {
                                i || null == s.return || s.return();
                            } finally {
                                if (o) throw r;
                            }
                        }
                        e.form_info = t;
                    } else e.form_info = [];
                    console.log("diyform", e.form_info);
                },
                mixins: [ r.default ],
                data: function() {
                    return {
                        years: [],
                        year: "",
                        months: [],
                        month: "",
                        days: [],
                        day: "",
                        value: [],
                        visible: !1,
                        form_info: [],
                        basicArr: [],
                        imgArr: [],
                        checkbox: [],
                        globle: getApp().common.globle,
                        curr_index: 0,
                        pass: !1
                    };
                },
                components: {
                    sunUiBasic: f
                },
                methods: {
                    getCheckbox: function(e, t) {
                        var i = this.form_info.values[e];
                        i.options[t].checked ? (this.$set(i.options[t], "checked", !1), this.checkbox[e].splice(t, 1)) : (this.$set(i.options[t], "checked", !0), 
                        void 0 == this.checkbox[e] && (this.checkbox[e] = []), this.checkbox[e].indexOf(i.options[t].op_name) < 0 && this.checkbox[e].push(i.options[t].op_name));
                    },
                    dateChange: function(e) {
                        var t = e.detail.value;
                        this.year = this.years[t[0]], this.month = this.months[t[1]], this.day = this.days[t[2]];
                        var i = this.year + "-" + this.month + "-" + this.day, o = this.form_info.values[this.curr_index];
                        this.$set(o, "date_value", i), o.date_value = i;
                    },
                    open_date: function(e) {
                        if (!this.visible) {
                            var t = new Date();
                            this.year = t.getFullYear(), this.month = t.getMonth() + 1, this.day = t.getDate(), 
                            this.value = [ 9999, this.month - 1, this.day - 1 ];
                            for (var i = 2e3; i <= t.getFullYear(); i++) this.years.push(i);
                            for (var o = 1; o <= 12; o++) this.months.push(o);
                            for (var r = 1; r <= 31; r++) this.days.push(r);
                            this.curr_index = e, this.visible = !0;
                        }
                    },
                    confirm: function() {
                        var e = this.form_info.values[this.curr_index];
                        if ("" == e.date_value) {
                            var t = this.year + "-" + this.month + "-" + this.day;
                            e.date_value = t;
                        }
                        this.visible = !1;
                    },
                    formSubmit: function(t) {
                        var i = this, o = JSON.stringify(t.detail.value), r = JSON.parse(o);
                        if (getApp().user.userid) {
                            for (var n = [], s = 0; s < i.form_info.values.length; s++) {
                                var a = {
                                    name: i.form_info.values[s].name,
                                    type: i.form_info.values[s].type,
                                    options: i.form_info.values[s].options
                                }, f = i.form_info.values[s].type + "_" + s;
                                if (1 == i.form_info.values[s].required && ("file" == i.form_info.values[s].type ? i.formCheck(i.imgArr) : "checkbox" == i.form_info.values[s].type ? i.formCheck(i.checkbox) : i.formCheck(r[f])), 
                                !i.pass) return;
                                if ("phone" == i.form_info.values[s].type) {
                                    var u = /^1[0-9]{10}$/;
                                    if (!u.test(r[f])) return void e.showToast({
                                        icon: "none",
                                        title: "请输入正确的手机号"
                                    });
                                }
                                if ("checkbox" == i.form_info.values[s].type) {
                                    var c = [];
                                    if (void 0 != this.checkbox[s]) for (var l in this.checkbox[s]) c.push(this.checkbox[s][l]);
                                    r[f] = c;
                                }
                                if ("file" == i.form_info.values[s].type) {
                                    var h = [];
                                    if (void 0 != this.imgArr[s]) for (var v in this.imgArr[s]) h.push(this.imgArr[s][v][0]);
                                    r[f] = h;
                                }
                                a.value = r[f], n.push(a);
                            }
                            console.log("form发生了submit事件，携带数据为1：", n), getApp().Req.get("form_submit", {
                                form_value: JSON.stringify(n),
                                form_id: this.form_info.id,
                                user_id: getApp().user.userid
                            }, function(t) {
                                if (t.code > 0) e.showToast({
                                    icon: "none",
                                    title: t.msg
                                }); else {
                                    e.showToast({
                                        title: "提交成功"
                                    });
                                    for (var o = 0; o < i.form_info.values.length; o++) {
                                        var r = i.form_info.values[o];
                                        if (r.default_value = "", r.date_value = "", "radio" == r.type || "checkbox" == r.type) {
                                            i.checkbox = [];
                                            for (var n = 0; n < r.options.length; n++) i.$set(r.options[n], "checked", !1);
                                        }
                                    }
                                    if (i.imgArr = [], i.basicArr.length > 0) {
                                        i.basicArr = [];
                                        for (var s = 0; s < i.$refs.uImageForm.length; s++) i.$refs.uImageForm[s].deleteAllImgs();
                                    }
                                }
                            });
                        } else e.showModal({
                            title: "提示",
                            content: "后台参数配置有误，请检查",
                            showCancel: !1,
                            confirmText: "确认"
                        });
                    },
                    formCheck: function(t) {
                        console.log("check_value", t), "" == t ? (e.showToast({
                            icon: "none",
                            title: "请填写完整信息"
                        }), this.pass = !1) : this.pass = !0;
                    },
                    formReset: function(e) {
                        console.log("清空数据", e);
                        for (var t = 0; t < this.form_info.values.length; t++) console.log("this.form_value", this.form_value[t]), 
                        this.form_info.date_value = "", this.form_value[t].value = "";
                    },
                    delImgInfo: function() {
                        var e = a(o.default.mark(function e(t, i) {
                            return o.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    console.log("你删除的图片地址为:", i, this.basicArr.splice(i.index, 1)), this.imgArr[t].splice(i.index, 1), 
                                    console.log("ffffff", this.imgArr);

                                  case 3:
                                  case "end":
                                    return e.stop();
                                }
                            }, e, this);
                        }));
                        function t(t, i) {
                            return e.apply(this, arguments);
                        }
                        return t;
                    }(),
                    upBasicData: function() {
                        var e = a(o.default.mark(function e(t, i) {
                            var r, n, s;
                            return o.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    this.curr_index = t, console.log("===>", i), r = [], n = 0, s = i.length;

                                  case 4:
                                    if (!(n < s)) {
                                        e.next = 18;
                                        break;
                                    }
                                    if (console.log(i[n].path_server, "图片路径"), e.prev = 6, "" == i[n].path_server) {
                                        e.next = 10;
                                        break;
                                    }
                                    return e.next = 10, r.push(i[n].path_server.split(","));

                                  case 10:
                                    e.next = 15;
                                    break;

                                  case 12:
                                    e.prev = 12, e.t0 = e["catch"](6), console.log("上传失败...");

                                  case 15:
                                    n++, e.next = 4;
                                    break;

                                  case 18:
                                    this.basicArr = r, this.imgArr[t] = r, console.log("this.imgArr", this.imgArr);

                                  case 21:
                                  case "end":
                                    return e.stop();
                                }
                            }, e, this, [ [ 6, 12 ] ]);
                        }));
                        function t(t, i) {
                            return e.apply(this, arguments);
                        }
                        return t;
                    }()
                }
            };
            t.default = u;
        }).call(this, i("543d")["default"]);
    },
    e2f1: function(e, t, i) {
        "use strict";
        i.r(t);
        var o = i("2260"), r = i("5ca5");
        for (var n in r) "default" !== n && function(e) {
            i.d(t, e, function() {
                return r[e];
            });
        }(n);
        i("1636");
        var s = i("2877"), a = Object(s["a"])(r["default"], o["a"], o["b"], !1, null, null, null);
        t["default"] = a.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/form-create-component", {
    "yb_shopv2/pages/index/form-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("e2f1"));
    }
}, [ [ "yb_shopv2/pages/index/form-create-component" ] ] ]);