(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/services1" ], {
    "052c": function(e, t, n) {
        "use strict";
        n.r(t);
        var u = n("ce18"), c = n.n(u);
        for (var r in u) "default" !== r && function(e) {
            n.d(t, e, function() {
                return u[e];
            });
        }(r);
        t["default"] = c.a;
    },
    "66cf": function(e, t, n) {
        "use strict";
        var u = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, c = [];
        n.d(t, "a", function() {
            return u;
        }), n.d(t, "b", function() {
            return c;
        });
    },
    "9f63a": function(e, t, n) {
        "use strict";
        var u = n("fcd9"), c = n.n(u);
        c.a;
    },
    ce18: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = r(n("c8bc")), c = r(n("5e9c"));
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        var a = {
            data: function() {
                return {
                    type: "services",
                    globle: getApp().common.globle
                };
            },
            mixins: [ u.default, c.default ]
        };
        t.default = a;
    },
    fb2e: function(e, t, n) {
        "use strict";
        n.r(t);
        var u = n("66cf"), c = n("052c");
        for (var r in c) "default" !== r && function(e) {
            n.d(t, e, function() {
                return c[e];
            });
        }(r);
        n("9f63a");
        var a = n("2877"), f = Object(a["a"])(c["default"], u["a"], u["b"], !1, null, null, null);
        t["default"] = f.exports;
    },
    fcd9: function(e, t, n) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/services1-create-component", {
    "yb_shopv2/pages/index/services1-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("fb2e"));
    }
}, [ [ "yb_shopv2/pages/index/services1-create-component" ] ] ]);