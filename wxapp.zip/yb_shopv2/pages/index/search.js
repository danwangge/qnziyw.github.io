(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/search" ], {
    3569: function(e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var n = c(r("c8bc"));
        function c(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        var a = {
            created: function() {
                var e = this;
                console.log("search", e.item);
            },
            mixins: [ n.default ],
            methods: {
                search: function() {
                    var e = this, t = {
                        type: "search",
                        type_name: "搜索",
                        search_keyword: e.item.search_keyword,
                        search_tip: e.item.search_tip,
                        search_article: e.item.search_article,
                        search_product: e.item.search_product
                    };
                    console.log(t), e.jump(t);
                }
            }
        };
        t.default = a;
    },
    "3dcd": function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r("3569"), c = r.n(n);
        for (var a in n) "default" !== a && function(e) {
            r.d(t, e, function() {
                return n[e];
            });
        }(a);
        t["default"] = c.a;
    },
    "635d": function(e, t, r) {
        "use strict";
        var n = r("7063"), c = r.n(n);
        c.a;
    },
    7063: function(e, t, r) {},
    ac40: function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r("f4e4"), c = r("3dcd");
        for (var a in c) "default" !== a && function(e) {
            r.d(t, e, function() {
                return c[e];
            });
        }(a);
        r("635d");
        var u = r("2877"), i = Object(u["a"])(c["default"], n["a"], n["b"], !1, null, null, null);
        t["default"] = i.exports;
    },
    f4e4: function(e, t, r) {
        "use strict";
        var n = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, c = [];
        r.d(t, "a", function() {
            return n;
        }), r.d(t, "b", function() {
            return c;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/search-create-component", {
    "yb_shopv2/pages/index/search-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("ac40"));
    }
}, [ [ "yb_shopv2/pages/index/search-create-component" ] ] ]);