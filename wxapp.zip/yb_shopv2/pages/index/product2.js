(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/product2" ], {
    6727: function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("c371"), r = e.n(u);
        for (var a in u) "default" !== a && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(a);
        n["default"] = r.a;
    },
    "6d22": function(t, n, e) {
        "use strict";
        var u = e("e571"), r = e.n(u);
        r.a;
    },
    "837c": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("9e63"), r = e("6727");
        for (var a in r) "default" !== a && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(a);
        e("6d22");
        var c = e("2877"), f = Object(c["a"])(r["default"], u["a"], u["b"], !1, null, null, null);
        n["default"] = f.exports;
    },
    "9e63": function(t, n, e) {
        "use strict";
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, r = [];
        e.d(n, "a", function() {
            return u;
        }), e.d(n, "b", function() {
            return r;
        });
    },
    c371: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = a(e("c8bc")), r = a(e("5e9c"));
        function a(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var c = {
            data: function() {
                return {
                    type: "product"
                };
            },
            mixins: [ u.default, r.default ]
        };
        n.default = c;
    },
    e571: function(t, n, e) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/product2-create-component", {
    "yb_shopv2/pages/index/product2-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("837c"));
    }
}, [ [ "yb_shopv2/pages/index/product2-create-component" ] ] ]);