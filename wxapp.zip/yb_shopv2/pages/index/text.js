(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/text" ], {
    "5faf": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("a958"), a = e("7301");
        for (var r in a) "default" !== r && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        var f = e("2877"), c = Object(f["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        n["default"] = c.exports;
    },
    7301: function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("da44"), a = e.n(u);
        for (var r in u) "default" !== r && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(r);
        n["default"] = a.a;
    },
    a958: function(t, n, e) {
        "use strict";
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, a = [];
        e.d(n, "a", function() {
            return u;
        }), e.d(n, "b", function() {
            return a;
        });
    },
    da44: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = a(e("c8bc"));
        function a(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var r = {
            mixins: [ u.default ]
        };
        n.default = r;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/text-create-component", {
    "yb_shopv2/pages/index/text-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("5faf"));
    }
}, [ [ "yb_shopv2/pages/index/text-create-component" ] ] ]);