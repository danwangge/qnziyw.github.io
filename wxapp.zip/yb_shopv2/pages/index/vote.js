(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/vote" ], {
    "019c": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("b061"), o = e.n(u);
        for (var a in u) "default" !== a && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(a);
        n["default"] = o.a;
    },
    "18aa": function(t, n, e) {
        "use strict";
        var u = e("a632"), o = e.n(u);
        o.a;
    },
    a632: function(t, n, e) {},
    b061: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = a(e("c8bc")), o = a(e("5e9c"));
        function a(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var r = function() {
            return e.e("yb_shopv2/pages/vote/timer").then(e.bind(null, "1d18"));
        }, c = {
            components: {
                timer: r
            },
            data: function() {
                return {
                    type: "vote",
                    globle: getApp().common.globle
                };
            },
            mixins: [ u.default, o.default ],
            created: function() {
                console.log("list***1111", this.list);
            },
            methods: {
                t: function() {}
            }
        };
        n.default = c;
    },
    be0d: function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("f915"), o = e("019c");
        for (var a in o) "default" !== a && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(a);
        e("18aa");
        var r = e("2877"), c = Object(r["a"])(o["default"], u["a"], u["b"], !1, null, null, null);
        n["default"] = c.exports;
    },
    f915: function(t, n, e) {
        "use strict";
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, o = [];
        e.d(n, "a", function() {
            return u;
        }), e.d(n, "b", function() {
            return o;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/vote-create-component", {
    "yb_shopv2/pages/index/vote-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("be0d"));
    }
}, [ [ "yb_shopv2/pages/index/vote-create-component" ] ] ]);