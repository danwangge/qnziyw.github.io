(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/product3" ], {
    "33a7": function(t, n, e) {
        "use strict";
        var u = e("75e0"), a = e.n(u);
        a.a;
    },
    "42ea": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("4b34"), a = e("687b");
        for (var r in a) "default" !== r && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        e("33a7");
        var c = e("2877"), f = Object(c["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        n["default"] = f.exports;
    },
    "46c1": function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = r(e("c8bc")), a = r(e("5e9c"));
        function r(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var c = {
            data: function() {
                return {
                    type: "product"
                };
            },
            mixins: [ u.default, a.default ]
        };
        n.default = c;
    },
    "4b34": function(t, n, e) {
        "use strict";
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, a = [];
        e.d(n, "a", function() {
            return u;
        }), e.d(n, "b", function() {
            return a;
        });
    },
    "687b": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("46c1"), a = e.n(u);
        for (var r in u) "default" !== r && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(r);
        n["default"] = a.a;
    },
    "75e0": function(t, n, e) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/product3-create-component", {
    "yb_shopv2/pages/index/product3-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("42ea"));
    }
}, [ [ "yb_shopv2/pages/index/product3-create-component" ] ] ]);