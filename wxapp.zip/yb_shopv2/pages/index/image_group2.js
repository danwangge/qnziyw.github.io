(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/image_group2" ], {
    "226b": function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = r(e("c8bc")), a = r(e("5e9c"));
        function r(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var f = {
            data: function() {
                return {
                    type: "images"
                };
            },
            mixins: [ u.default, a.default ]
        };
        n.default = f;
    },
    "26db": function(t, n, e) {
        "use strict";
        var u = e("e508"), a = e.n(u);
        a.a;
    },
    "61f0": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("226b"), a = e.n(u);
        for (var r in u) "default" !== r && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(r);
        n["default"] = a.a;
    },
    "65fc": function(t, n, e) {
        "use strict";
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, a = [];
        e.d(n, "a", function() {
            return u;
        }), e.d(n, "b", function() {
            return a;
        });
    },
    "7b62": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("65fc"), a = e("61f0");
        for (var r in a) "default" !== r && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        e("26db");
        var f = e("2877"), c = Object(f["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        n["default"] = c.exports;
    },
    e508: function(t, n, e) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/image_group2-create-component", {
    "yb_shopv2/pages/index/image_group2-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("7b62"));
    }
}, [ [ "yb_shopv2/pages/index/image_group2-create-component" ] ] ]);