(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/product1" ], {
    "5da0": function(t, n, u) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var e = a(u("c8bc")), r = a(u("5e9c"));
        function a(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var d = {
            data: function() {
                return {
                    type: "product"
                };
            },
            mixins: [ e.default, r.default ]
        };
        n.default = d;
    },
    7213: function(t, n, u) {
        "use strict";
        u.r(n);
        var e = u("5da0"), r = u.n(e);
        for (var a in e) "default" !== a && function(t) {
            u.d(n, t, function() {
                return e[t];
            });
        }(a);
        n["default"] = r.a;
    },
    9500: function(t, n, u) {
        "use strict";
        var e = u("d16d"), r = u.n(e);
        r.a;
    },
    d16d: function(t, n, u) {},
    d4fd: function(t, n, u) {
        "use strict";
        var e = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, r = [];
        u.d(n, "a", function() {
            return e;
        }), u.d(n, "b", function() {
            return r;
        });
    },
    d8f3: function(t, n, u) {
        "use strict";
        u.r(n);
        var e = u("d4fd"), r = u("7213");
        for (var a in r) "default" !== a && function(t) {
            u.d(n, t, function() {
                return r[t];
            });
        }(a);
        u("9500");
        var d = u("2877"), f = Object(d["a"])(r["default"], e["a"], e["b"], !1, null, null, null);
        n["default"] = f.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/product1-create-component", {
    "yb_shopv2/pages/index/product1-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("d8f3"));
    }
}, [ [ "yb_shopv2/pages/index/product1-create-component" ] ] ]);