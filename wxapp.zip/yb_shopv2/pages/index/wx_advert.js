(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/wx_advert" ], {
    5532: function(t, e, n) {},
    8701: function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("de4d"), a = n("e93a");
        for (var r in a) "default" !== r && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(r);
        n("f087");
        var c = n("2877"), f = Object(c["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        e["default"] = f.exports;
    },
    d00a: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var u = a(n("c8bc"));
        function a(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var r = {
            created: function() {
                var t = this;
                console.log("wx_advert", t.item);
            },
            mixins: [ u.default ]
        };
        e.default = r;
    },
    de4d: function(t, e, n) {
        "use strict";
        var u = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
        n.d(e, "a", function() {
            return u;
        }), n.d(e, "b", function() {
            return a;
        });
    },
    e93a: function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("d00a"), a = n.n(u);
        for (var r in u) "default" !== r && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(r);
        e["default"] = a.a;
    },
    f087: function(t, e, n) {
        "use strict";
        var u = n("5532"), a = n.n(u);
        a.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/wx_advert-create-component", {
    "yb_shopv2/pages/index/wx_advert-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("8701"));
    }
}, [ [ "yb_shopv2/pages/index/wx_advert-create-component" ] ] ]);