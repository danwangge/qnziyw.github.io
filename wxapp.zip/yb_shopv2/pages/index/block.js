(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/block" ], {
    "5afc": function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = a(e("c8bc"));
        function a(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }
        var f = function() {
            return e.e("yb_shopv2/pages/index/text").then(e.bind(null, "5faf"));
        }, r = function() {
            return e.e("yb_shopv2/pages/index/button").then(e.bind(null, "4833"));
        }, i = function() {
            return e.e("yb_shopv2/pages/index/image").then(e.bind(null, "92ef"));
        }, o = {
            mixins: [ u.default ],
            components: {
                btext: f,
                bbutton: r,
                bimage: i
            }
        };
        t.default = o;
    },
    b8fd: function(n, t, e) {
        "use strict";
        var u = e("ba1b"), a = e.n(u);
        a.a;
    },
    ba1b: function(n, t, e) {},
    bbd2: function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("5afc"), a = e.n(u);
        for (var f in u) "default" !== f && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(f);
        t["default"] = a.a;
    },
    c657: function(n, t, e) {
        "use strict";
        var u = function() {
            var n = this, t = n.$createElement;
            n._self._c;
        }, a = [];
        e.d(t, "a", function() {
            return u;
        }), e.d(t, "b", function() {
            return a;
        });
    },
    ff79: function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("c657"), a = e("bbd2");
        for (var f in a) "default" !== f && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(f);
        e("b8fd");
        var r = e("2877"), i = Object(r["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        t["default"] = i.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/block-create-component", {
    "yb_shopv2/pages/index/block-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("ff79"));
    }
}, [ [ "yb_shopv2/pages/index/block-create-component" ] ] ]);