(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/video" ], {
    "3f28": function(t, e, n) {},
    "7b60": function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("ea2a"), i = n("8994");
        for (var a in i) "default" !== a && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        n("a062");
        var u = n("2877"), r = Object(u["a"])(i["default"], o["a"], o["b"], !1, null, null, null);
        e["default"] = r.exports;
    },
    8994: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("adfa"), i = n.n(o);
        for (var a in o) "default" !== a && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        e["default"] = i.a;
    },
    a062: function(t, e, n) {
        "use strict";
        var o = n("3f28"), i = n.n(o);
        i.a;
    },
    adfa: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            props: {
                item: {}
            },
            data: function() {
                return {
                    video_info: {},
                    autoplay: !1
                };
            },
            created: function() {
                var t = this;
                t.video_info = t.item, console.log("video", t.video_info), "" != t.item.url && 2 == t.item.video_type && t.videoTransform();
            },
            mounted: function() {
                this.autoplay = !!Number(this.item.auto_play);
            },
            methods: {
                videoTransform: function() {
                    var t = this;
                    getApp().Req.get("Video_Video2Mp4", {
                        videoUrl: t.item.url
                    }, function(e) {
                        0 == e.code && (t.video_info.url = e.info);
                    });
                }
            }
        };
        e.default = o;
    },
    ea2a: function(t, e, n) {
        "use strict";
        var o = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, i = [];
        n.d(e, "a", function() {
            return o;
        }), n.d(e, "b", function() {
            return i;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/video-create-component", {
    "yb_shopv2/pages/index/video-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("7b60"));
    }
}, [ [ "yb_shopv2/pages/index/video-create-component" ] ] ]);