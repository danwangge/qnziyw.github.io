(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/headline" ], {
    "22a1": function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("9119"), a = e("c0af");
        for (var r in a) "default" !== r && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(r);
        e("a62c");
        var c = e("2877"), f = Object(c["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        t["default"] = f.exports;
    },
    9119: function(n, t, e) {
        "use strict";
        var u = function() {
            var n = this, t = n.$createElement;
            n._self._c;
        }, a = [];
        e.d(t, "a", function() {
            return u;
        }), e.d(t, "b", function() {
            return a;
        });
    },
    "9a87": function(n, t, e) {},
    a62c: function(n, t, e) {
        "use strict";
        var u = e("9a87"), a = e.n(u);
        a.a;
    },
    c0af: function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("e351"), a = e.n(u);
        for (var r in u) "default" !== r && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(r);
        t["default"] = a.a;
    },
    e351: function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = a(e("c8bc"));
        function a(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }
        var r = {
            mixins: [ u.default ]
        };
        t.default = r;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/headline-create-component", {
    "yb_shopv2/pages/index/headline-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("22a1"));
    }
}, [ [ "yb_shopv2/pages/index/headline-create-component" ] ] ]);