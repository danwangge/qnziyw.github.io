(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/index" ], {
    "08c0": function(n, e, o) {},
    "23cd": function(n, e, o) {
        "use strict";
        o.r(e);
        var t = o("40f4"), i = o.n(t);
        for (var a in t) "default" !== a && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(a);
        e["default"] = i.a;
    },
    3332: function(n, e, o) {
        "use strict";
        var t = function() {
            var n = this, e = n.$createElement;
            n._self._c;
        }, i = [];
        o.d(e, "a", function() {
            return t;
        }), o.d(e, "b", function() {
            return i;
        });
    },
    3565: function(n, e, o) {
        "use strict";
        var t = o("08c0"), i = o.n(t);
        i.a;
    },
    "40f4": function(n, e, o) {
        "use strict";
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = i(o("3b18"));
            function i(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            var a = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/lb") ]).then(o.bind(null, "14f5"));
            }, r = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/navc") ]).then(o.bind(null, "8032"));
            }, l = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/line") ]).then(o.bind(null, "181a"));
            }, s = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/headline") ]).then(o.bind(null, "22a1"));
            }, d = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/articles1") ]).then(o.bind(null, "cd8a"));
            }, u = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/articles2") ]).then(o.bind(null, "3cbb"));
            }, c = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/image_group1") ]).then(o.bind(null, "e204"));
            }, m = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/image_group2") ]).then(o.bind(null, "7b62"));
            }, p = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/product1") ]).then(o.bind(null, "d8f3"));
            }, f = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/product2") ]).then(o.bind(null, "837c"));
            }, v = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/product3") ]).then(o.bind(null, "42ea"));
            }, h = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/services1") ]).then(o.bind(null, "fb2e"));
            }, b = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/block") ]).then(o.bind(null, "ff79"));
            }, g = function() {
                return o.e("yb_shopv2/pages/index/video").then(o.bind(null, "7b60"));
            }, y = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/diy_comment") ]).then(o.bind(null, "f18a"));
            }, _ = function() {
                return o.e("yb_shopv2/component/auth").then(o.bind(null, "8b3d"));
            }, x = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/recruit") ]).then(o.bind(null, "9d29"));
            }, P = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/vote") ]).then(o.bind(null, "be0d"));
            }, w = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/search") ]).then(o.bind(null, "ac40"));
            }, O = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/wx_advert") ]).then(o.bind(null, "8701"));
            }, L = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/form") ]).then(o.bind(null, "e2f1"));
            }, M = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/map") ]).then(o.bind(null, "f285"));
            }, A = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/announcement") ]).then(o.bind(null, "98a8"));
            }, k = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/module/ModuleAudio") ]).then(o.bind(null, "8cd2"));
            }, D = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/module/ModuleGoodList") ]).then(o.bind(null, "47e1"));
            }, S = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/module/ModuleCoupon") ]).then(o.bind(null, "5950"));
            }, J = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/module/ModuleActivity") ]).then(o.bind(null, "1a89"));
            }, T = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/chat/sendmsg") ]).then(o.bind(null, "334f"));
            }, $ = {
                data: function() {
                    return {
                        title: "Hello",
                        dataList: [],
                        pageinfo: {},
                        loadingText: "加载中...",
                        id: 0,
                        styles: {},
                        animations: {},
                        page_path: "pages/index/index",
                        is_wx_platform: !1
                    };
                },
                components: {
                    lunbo: a,
                    naviag: r,
                    lineplace: l,
                    biaoti: s,
                    articles1: d,
                    articles2: u,
                    imagegroup1: c,
                    imagegroup2: m,
                    product1: p,
                    product2: f,
                    product3: v,
                    services1: h,
                    cblock: b,
                    videopart: g,
                    auth: _,
                    diycomment: y,
                    recruit: x,
                    vote: P,
                    search: w,
                    wxadvert: O,
                    diyform: L,
                    diymap: M,
                    announcement: A,
                    ModuleAudio: k,
                    ModuleGoodList: D,
                    ModuleCoupon: S,
                    ModuleActivity: J,
                    chat: T
                },
                watch: {
                    dataList: function(n) {
                        console.log(n);
                    }
                },
                methods: {
                    page_onLoad: function(e) {
                        this.is_wx_platform = !0, this.title = "", console.log("index onload: ", e);
                        var o = e.id;
                        this.id = o, n.showLoading({
                            title: "加载中"
                        }), this.getPageData();
                    },
                    page_onShow: function() {},
                    page_onPullDownRefresh: function() {
                        this.getPageData();
                    },
                    getPageData: function() {
                        var e = this;
                        getApp().Req.get("index_pagedata", {
                            id: this.id
                        }, function(o) {
                            o = JSON.stringify(o).replace(/<br\/\>/g, "\\n").replace(/<br\>/g, "\\n"), o = JSON.parse(o), 
                            e.title = o.info.page.name, console.log("pagedata", o), e.pageinfo = {};
                            try {
                                var t = o.info.styles.css, i = getApp().handleStyle(t);
                                e.styles = i[0], e.animations = i[1], e.dataList = [], e.$nextTick(function() {
                                    e.dataList = o.info.all_data, e.dataList.forEach(function(n) {
                                        e.$set(n, "dots_color", n["dots-color"]), e.$set(n, "dots_active_color", n["dots-active-color"]), 
                                        delete n["dots-color"], delete n["dots-active-color"];
                                        var o = n.id, t = n.type, i = {}, a = {};
                                        for (var r in e.styles) e.styles.hasOwnProperty(r) && r.indexOf(o) >= 0 && (i[r] = e.styles[r]);
                                        for (var l in e.animations) e.animations.hasOwnProperty(l) && l.indexOf(o) >= 0 && (a[l] = e.animations[l]);
                                        if ("block" === t) for (var s in n.sub) if (n.sub.hasOwnProperty(s)) {
                                            var d = n.sub[s];
                                            d["id"] = s;
                                            var u = {}, c = {};
                                            for (var m in e.styles) e.styles.hasOwnProperty(m) && m.indexOf(s) >= 0 && (u[m] = e.styles[m]);
                                            for (var p in e.animations) e.animations.hasOwnProperty(p) && p.indexOf(s) >= 0 && (c[p] = e.animations[p]);
                                            d.css = u, d.animation = c;
                                        }
                                        n.css = i, n.animation = a;
                                    }), e.pageinfo = o.info.page;
                                    getApp().Tool.IndexCacheKey;
                                    getApp().Tool.setPageStyle(e.pageinfo);
                                });
                            } catch (a) {
                                console.log(a, "出现错误1111111111111111111111111111111111111111111111");
                            }
                            n.hideLoading(), n.stopPullDownRefresh();
                        });
                    }
                },
                mixins: [ t.default ]
            };
            e.default = $;
        }).call(this, o("543d")["default"]);
    },
    6775: function(n, e, o) {
        "use strict";
        o.r(e);
        var t = o("3332"), i = o("23cd");
        for (var a in i) "default" !== a && function(n) {
            o.d(e, n, function() {
                return i[n];
            });
        }(a);
        o("3565");
        var r = o("2877"), l = Object(r["a"])(i["default"], t["a"], t["b"], !1, null, null, null);
        e["default"] = l.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/index-create-component", {
    "yb_shopv2/pages/index/index-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("6775"));
    }
}, [ [ "yb_shopv2/pages/index/index-create-component" ] ] ]);