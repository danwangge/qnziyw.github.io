(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/recruit" ], {
    4131: function(t, n, e) {},
    "56d9": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("d2d0"), r = e.n(u);
        for (var o in u) "default" !== o && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(o);
        n["default"] = r.a;
    },
    7586: function(t, n, e) {
        "use strict";
        var u = e("4131"), r = e.n(u);
        r.a;
    },
    9886: function(t, n, e) {
        "use strict";
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, r = [];
        e.d(n, "a", function() {
            return u;
        }), e.d(n, "b", function() {
            return r;
        });
    },
    "9d29": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("9886"), r = e("56d9");
        for (var o in r) "default" !== o && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(o);
        e("7586");
        var c = e("2877"), a = Object(c["a"])(r["default"], u["a"], u["b"], !1, null, null, null);
        n["default"] = a.exports;
    },
    d2d0: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = o(e("c8bc")), r = o(e("5e9c"));
        function o(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var c = {
            data: function() {
                return {
                    type: "recruit",
                    globle: getApp().common.globle || ""
                };
            },
            mixins: [ u.default, r.default ],
            created: function() {
                console.log(getApp().common.globle);
            }
        };
        n.default = c;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/recruit-create-component", {
    "yb_shopv2/pages/index/recruit-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("9d29"));
    }
}, [ [ "yb_shopv2/pages/index/recruit-create-component" ] ] ]);