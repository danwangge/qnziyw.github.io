(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/announcement" ], {
    "14cb": function(n, t, e) {},
    "2cde": function(n, t, e) {
        "use strict";
        var u = e("14cb"), a = e.n(u);
        a.a;
    },
    4102: function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("5cfd"), a = e.n(u);
        for (var c in u) "default" !== c && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(c);
        t["default"] = a.a;
    },
    "52a8": function(n, t, e) {
        "use strict";
        var u = function() {
            var n = this, t = n.$createElement;
            n._self._c;
        }, a = [];
        e.d(t, "a", function() {
            return u;
        }), e.d(t, "b", function() {
            return a;
        });
    },
    "5cfd": function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = c(e("c8bc")), a = c(e("5e9c"));
        function c(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }
        var r = {
            data: function() {
                return {
                    type: "announcement",
                    globle: getApp().common.globle
                };
            },
            created: function() {},
            mixins: [ u.default, a.default ],
            methods: {}
        };
        t.default = r;
    },
    "98a8": function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("52a8"), a = e("4102");
        for (var c in a) "default" !== c && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(c);
        e("2cde");
        var r = e("2877"), o = Object(r["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        t["default"] = o.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/announcement-create-component", {
    "yb_shopv2/pages/index/announcement-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("98a8"));
    }
}, [ [ "yb_shopv2/pages/index/announcement-create-component" ] ] ]);