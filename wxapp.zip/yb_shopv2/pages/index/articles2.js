(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/index/articles2" ], {
    "065c": function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = a(e("c8bc"));
        function a(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }
        var r = {
            mixins: [ u.default ]
        };
        t.default = r;
    },
    "1f28": function(n, t, e) {},
    "3cbb": function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("93eb"), a = e("6ad0");
        for (var r in a) "default" !== r && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(r);
        e("5f6c");
        var c = e("2877"), f = Object(c["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        t["default"] = f.exports;
    },
    "5f6c": function(n, t, e) {
        "use strict";
        var u = e("1f28"), a = e.n(u);
        a.a;
    },
    "6ad0": function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("065c"), a = e.n(u);
        for (var r in u) "default" !== r && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(r);
        t["default"] = a.a;
    },
    "93eb": function(n, t, e) {
        "use strict";
        var u = function() {
            var n = this, t = n.$createElement;
            n._self._c;
        }, a = [];
        e.d(t, "a", function() {
            return u;
        }), e.d(t, "b", function() {
            return a;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/index/articles2-create-component", {
    "yb_shopv2/pages/index/articles2-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("3cbb"));
    }
}, [ [ "yb_shopv2/pages/index/articles2-create-component" ] ] ]);