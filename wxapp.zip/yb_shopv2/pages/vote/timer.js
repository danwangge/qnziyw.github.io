(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/vote/timer" ], {
    "1d18": function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("1f1b"), o = e("2d1d");
        for (var s in o) "default" !== s && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(s);
        e("d194");
        var u = e("2877"), a = Object(u["a"])(o["default"], i["a"], i["b"], !1, null, null, null);
        n["default"] = a.exports;
    },
    "1f1b": function(t, n, e) {
        "use strict";
        var i = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, o = [];
        e.d(n, "a", function() {
            return i;
        }), e.d(n, "b", function() {
            return o;
        });
    },
    "2d1d": function(t, n, e) {
        "use strict";
        e.r(n);
        var i = e("7ec2"), o = e.n(i);
        for (var s in i) "default" !== s && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(s);
        n["default"] = o.a;
    },
    "7ec2": function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var i = {
            props: [ "start_time", "end_time" ],
            data: function() {
                return {
                    day: 0,
                    hour: 0,
                    minute: 0,
                    second: 0,
                    h: !0,
                    status: 0
                };
            },
            created: function() {
                console.log("timer");
                var t = this.start_time, n = this.end_time, e = "", i = "", o = Date.parse(new Date()) / 1e3;
                o < t ? (e = 0, i = t - o) : o > n ? e = 2 : (e = 1, i = n - o), 2 != e && (this.day = Math.floor(i / 86400), 
                this.hour = Math.floor(i % 86400 / 3600), this.minute = Math.floor(i % 86400 % 3600 / 60), 
                this.second = Math.floor(i % 86400 % 3600 % 60), this.val = setInterval(this.secondDown, 1e3)), 
                this.status = e;
            },
            methods: {
                secondDown: function() {
                    this.second > 0 ? this.second = this.second - 1 : (this.second = 59, this.minuteDown());
                },
                minuteDown: function() {
                    this.minute > 0 ? this.minute = this.minute - 1 : (this.minute = 59, this.hourDown());
                },
                hourDown: function() {
                    this.hour > 0 ? this.hour = this.hour - 1 : (this.hour = 24, this.dayDown());
                },
                dayDown: function() {
                    this.day > 0 ? this.day = this.day - 1 : (console.log("一结束"), this.h = !1, clearInterval(this.val));
                }
            }
        };
        n.default = i;
    },
    8618: function(t, n, e) {},
    d194: function(t, n, e) {
        "use strict";
        var i = e("8618"), o = e.n(i);
        o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/vote/timer-create-component", {
    "yb_shopv2/pages/vote/timer-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("1d18"));
    }
}, [ [ "yb_shopv2/pages/vote/timer-create-component" ] ] ]);