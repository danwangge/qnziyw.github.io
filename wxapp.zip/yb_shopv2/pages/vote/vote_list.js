(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/vote/vote_list" ], {
    "2d94": function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("544d"), a = n.n(o);
        for (var u in o) "default" !== u && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(u);
        e["default"] = a.a;
    },
    "544d": function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = a(n("3b18"));
        function a(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var u = function() {
            return Promise.all([ n.e("common/vendor"), n.e("yb_shopv2/pages/index/vote") ]).then(n.bind(null, "be0d"));
        }, r = {
            mixins: [ o.default ],
            data: function() {
                return {
                    cate: [],
                    topRefresh: 0,
                    bottomRefresh: 0,
                    item: {
                        class_ids: 0,
                        data_type: "auto",
                        id: "vote-list-auto",
                        num: 10,
                        order: "create_time",
                        showtitle: !0,
                        sort: "desc",
                        css: {},
                        animation: {},
                        list: []
                    },
                    page_path: "pages/vote/vote_list"
                };
            },
            components: {
                rlist: u
            }
        };
        e.default = r;
    },
    5978: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("c6a0"), a = n("2d94");
        for (var u in a) "default" !== u && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(u);
        var r = n("2877"), i = Object(r["a"])(a["default"], o["a"], o["b"], !1, null, null, null);
        e["default"] = i.exports;
    },
    c6a0: function(t, e, n) {
        "use strict";
        var o = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
        n.d(e, "a", function() {
            return o;
        }), n.d(e, "b", function() {
            return a;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/vote/vote_list-create-component", {
    "yb_shopv2/pages/vote/vote_list-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("5978"));
    }
}, [ [ "yb_shopv2/pages/vote/vote_list-create-component" ] ] ]);