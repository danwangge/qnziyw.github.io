(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/distribution/distribution" ], {
    "3b24": function(t, i, n) {
        "use strict";
        n.r(i);
        var e = n("84dd"), o = n("d18d");
        for (var a in o) "default" !== a && function(t) {
            n.d(i, t, function() {
                return o[t];
            });
        }(a);
        n("99db");
        var u = n("2877"), r = Object(u["a"])(o["default"], e["a"], e["b"], !1, null, null, null);
        i["default"] = r.exports;
    },
    "84dd": function(t, i, n) {
        "use strict";
        var e = function() {
            var t = this, i = t.$createElement;
            t._self._c;
        }, o = [];
        n.d(i, "a", function() {
            return e;
        }), n.d(i, "b", function() {
            return o;
        });
    },
    "85f4": function(t, i, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var e = u(n("c8bc")), o = u(n("3b18")), a = n("21b4");
            function u(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var r = function() {
                return n.e("yb_shopv2/component/CustomNoData").then(n.bind(null, "8a57"));
            }, s = {
                data: function() {
                    return {
                        applyDistribution: "",
                        distributionInfo: {},
                        tabArr: [ {
                            icon: "../../../static/image/team.png",
                            name: "我的团队"
                        }, {
                            icon: "../../../static/image/mineCustomer.png",
                            name: "我的客户",
                            url: ""
                        }, {
                            icon: "../../../static/image/commission.png",
                            name: "佣金明细",
                            url: ""
                        }, {
                            icon: "../../../static/image/orderDetail.png",
                            name: "订单明细",
                            url: ""
                        }, {
                            icon: "../../../static/image/cashWithdrawalDetail.png",
                            name: "提现明细",
                            url: ""
                        }, {
                            icon: "../../../static/image/mineCard.png",
                            name: "我的账户",
                            url: ""
                        }, {
                            icon: "../../../static/image/extension.png",
                            name: "推广全店",
                            url: ""
                        }, {
                            icon: "../../../static/image/invitationCustomer.png",
                            name: "邀请客户",
                            url: ""
                        } ]
                    };
                },
                components: {
                    nodata: r
                },
                mixins: [ e.default, o.default ],
                computed: {
                    pageHeight: function() {
                        return t.getSystemInfoSync().windowHeight;
                    }
                },
                methods: {
                    jumpCommon: function(t) {
                        0 != t && 1 != t && 2 != t && 4 != t && 5 != t || this.jump({
                            type: "page_IntegralDistributionList",
                            index: t
                        }), 3 == t && this.jump({
                            type: "distribution_order_detail"
                        }), 6 == t && (0, a.jump)("../../pages/distribution/child/ewmPoster?type=extension"), 
                        7 == t && (0, a.jump)("../../pages/distribution/child/ewmPoster?type=invitation");
                    },
                    page_onLoad: function(i) {
                        console.log(i, "分销参数分销参数"), t.showLoading({
                            title: "加载中"
                        });
                        var n = this;
                        getApp().distribution = {}, n.title = "分销中心", i.pid && (getApp().distribution.pid = i.pid, 
                        getApp().Req.get("Distribution_addCustomer", {
                            distribution_id: getApp().distribution.pid,
                            user_id: getApp().user.userid
                        })), t.$on("cwSuccess", function() {
                            n.getDistributionInfo();
                        }), n.getDistributionSet(), n.getDistributionInfo();
                    },
                    page_onPullDownRefresh: function() {
                        this.getDistributionInfo();
                    },
                    getDistributionSet: function() {
                        getApp().Req.get("Distribution_getDistributionSetting", {}, function(t) {
                            console.log(t, "分销商配置信息"), getApp().distribution.withdraw_type = [];
                            -1 != t.data.withdraw_type.indexOf("wechat") && getApp().distribution.withdraw_type.push("微信"), 
                            -1 != t.data.withdraw_type.indexOf("alipay") && getApp().distribution.withdraw_type.push("支付宝"), 
                            -1 != t.data.withdraw_type.indexOf("bank_card") && getApp().distribution.withdraw_type.push("银行卡");
                        });
                    },
                    getDistributionInfo: function() {
                        var i = this;
                        getApp().Req.get("Distribution_getDistributionUser", {
                            user_id: getApp().user.userid
                        }, function(n) {
                            i.distributionInfo = n.data, getApp().distribution.id = n.data.id, getApp().available_money = n.data.available_money, 
                            i.applyDistribution = "false", console.log(n, "分销商信息"), t.hideLoading(), t.stopPullDownRefresh();
                        }, function(n) {
                            i.applyDistribution = "true", t.hideLoading(), t.stopPullDownRefresh();
                        });
                    },
                    immediateApplication: function() {
                        (0, a.jump)("/yb_shopv2/native/all/index?type=page_apply_distribution", 2);
                    }
                }
            };
            i.default = s;
        }).call(this, n("543d")["default"]);
    },
    "99db": function(t, i, n) {
        "use strict";
        var e = n("e040"), o = n.n(e);
        o.a;
    },
    d18d: function(t, i, n) {
        "use strict";
        n.r(i);
        var e = n("85f4"), o = n.n(e);
        for (var a in e) "default" !== a && function(t) {
            n.d(i, t, function() {
                return e[t];
            });
        }(a);
        i["default"] = o.a;
    },
    e040: function(t, i, n) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/distribution/distribution-create-component", {
    "yb_shopv2/pages/distribution/distribution-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("3b24"));
    }
}, [ [ "yb_shopv2/pages/distribution/distribution-create-component" ] ] ]);