(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/distribution/child/orderDetail" ], {
    "39e7": function(t, n, e) {
        "use strict";
        e.r(n);
        var o = e("d06e"), a = e.n(o);
        for (var r in o) "default" !== r && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(r);
        n["default"] = a.a;
    },
    4508: function(t, n, e) {
        "use strict";
        e.r(n);
        var o = e("466b"), a = e("39e7");
        for (var r in a) "default" !== r && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        e("f7c7");
        var i = e("2877"), u = Object(i["a"])(a["default"], o["a"], o["b"], !1, null, null, null);
        n["default"] = u.exports;
    },
    "466b": function(t, n, e) {
        "use strict";
        var o = function() {
            var t = this, n = t.$createElement, e = (t._self._c, t.__map(t.orderInfo, function(n, e) {
                var o = t.timeFormat(n.create_time), a = t.timeFormat(n.settle_time);
                return {
                    $orig: t.__get_orig(n),
                    m0: o,
                    m1: a
                };
            }));
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e
                }
            });
        }, a = [];
        e.d(n, "a", function() {
            return o;
        }), e.d(n, "b", function() {
            return a;
        });
    },
    "7ebb": function(t, n, e) {},
    d06e: function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = r(e("3b18")), a = e("21b4");
            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var i = function() {
                return e.e("yb_shopv2/component/CustomNoData").then(e.bind(null, "8a57"));
            }, u = {
                mixins: [ o.default ],
                components: {
                    nodata: i
                },
                data: function() {
                    return {
                        params: {
                            distribution_id: getApp().distribution.id,
                            page: 1,
                            status: 0
                        },
                        nodata: !1,
                        cur: 0,
                        titArr: [ "全部", "待结算", "已结算", "无效" ],
                        orderInfo: []
                    };
                },
                methods: {
                    timeFormat: function(t) {
                        return (0, a.time_format)(t);
                    },
                    sel: function(n) {
                        t.showLoading({
                            title: "加载中"
                        }), this.params.status = this.cur = n, this.params.page = 1, this.getOrderInfo();
                    },
                    page_onLoad: function(n) {
                        console.log((0, a.time_format)(0)), t.showLoading({
                            title: "加载中"
                        }), this.title = "订单明细", this.getOrderInfo();
                    },
                    page_onPullDownRefresh: function() {
                        this.params.page = 1, this.getOrderInfo();
                    },
                    page_onReachBottom: function() {
                        this.nodata || (this.params.page += 1, this.getOrderInfo());
                    },
                    getOrderInfo: function() {
                        var n = this;
                        1 == n.params.page && (n.orderInfo = []), getApp().Req.get("Distribution_getOrderList", n.params, function(e) {
                            n.orderInfo = n.orderInfo.concat(e.data), 0 == e.data.length ? n.nodata = !0 : n.nodata = !1, 
                            t.stopPullDownRefresh(), t.hideLoading(), console.log(e, "得到订单信息成功");
                        }, function(n) {
                            t.stopPullDownRefresh(), t.hideLoading(), t.showToast({
                                icon: "none",
                                title: "获取订单信息失败，请稍后再试"
                            });
                        });
                    }
                }
            };
            n.default = u;
        }).call(this, e("543d")["default"]);
    },
    f7c7: function(t, n, e) {
        "use strict";
        var o = e("7ebb"), a = e.n(o);
        a.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/distribution/child/orderDetail-create-component", {
    "yb_shopv2/pages/distribution/child/orderDetail-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("4508"));
    }
}, [ [ "yb_shopv2/pages/distribution/child/orderDetail-create-component" ] ] ]);