(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/distribution/child/ewmPoster" ], {
    "19f8": function(t, e, i) {
        "use strict";
        (function(t) {
            i("1a02");
            o(i("66fd"));
            var e = o(i("604f"));
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(e.default);
        }).call(this, i("543d")["createPage"]);
    },
    3624: function(t, e, i) {
        "use strict";
        i.r(e);
        var o = i("8231"), n = i.n(o);
        for (var a in o) "default" !== a && function(t) {
            i.d(e, t, function() {
                return o[t];
            });
        }(a);
        e["default"] = n.a;
    },
    "5c1b": function(t, e, i) {
        "use strict";
        var o = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, n = [];
        i.d(e, "a", function() {
            return o;
        }), i.d(e, "b", function() {
            return n;
        });
    },
    "604f": function(t, e, i) {
        "use strict";
        i.r(e);
        var o = i("5c1b"), n = i("3624");
        for (var a in n) "default" !== a && function(t) {
            i.d(e, t, function() {
                return n[t];
            });
        }(a);
        i("d645");
        var s = i("2877"), f = Object(s["a"])(n["default"], o["a"], o["b"], !1, null, null, null);
        e["default"] = f.exports;
    },
    8231: function(t, e, i) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = a(i("3b18")), n = (a(i("16c3")), i("575c"));
            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var s = {
                mixins: [ o.default ],
                data: function() {
                    return {
                        width: 344,
                        height: 500,
                        type: ""
                    };
                },
                onPullDownRefresh: function() {
                    this.getPoster();
                },
                onLoad: function(e) {
                    t.showLoading({
                        title: "加载中"
                    }), this.type = e.type, this.getPoster();
                },
                methods: {
                    getPoster: function() {
                        var e = this, i = t.getStorageSync("user"), o = "";
                        o = "extension" == e.type.type ? "推广全店" : "邀请客户", t.setNavigationBarTitle({
                            title: o
                        });
                        var a = t.createCanvasContext("firstCanvas"), s = {
                            width: 60,
                            offsetTop: 60
                        }, f = {
                            width: a.measureText(i.nick_name).width,
                            height: 20,
                            offsetTop: 100,
                            bdRadius: 10,
                            bgColor: "#FFEFE1",
                            padding: 15
                        }, d = {
                            offsetTop: 170,
                            offsetLeft: 15
                        }, r = {
                            width: 140,
                            offsetTop: 235
                        };
                        t.getImageInfo({
                            src: i.user_headimg,
                            success: function(o) {
                                i.user_headimg = o.path, console.log(i.user_headimg, "临时图片信息"), "extension" == e.type ? a.drawImage("../../../../static/image/ewmBg02.png", 0, 0, e.width, e.height) : a.drawImage("../../../../static/image/ewmBg01.png", 0, 0, e.width, e.height), 
                                a.save(), a.beginPath(), a.arc(e.width / 2, s.offsetTop, s.width / 2, 0, 2 * Math.PI), 
                                a.clip(), a.drawImage(i.user_headimg, e.width / 2 - s.width / 2, s.offsetTop - s.width / 2, s.width, s.width), 
                                a.restore(), a.save();
                                var h = f.width + 2 * f.padding;
                                e.roundRect(a, e.width / 2 - h / 2, f.offsetTop, h, f.height, f.bdRadius, f.bgColor, f.bgColor), 
                                a.setFontSize(14), a.setFillStyle("#DA3C0B"), a.setTextAlign("center"), a.fillText(i.nick_name, e.width / 2, f.offsetTop + f.height - 5), 
                                a.restore(), a.save(), a.beginPath(), a.setFontSize(24), a.setFillStyle("#ffffff"), 
                                "extension" == e.type ? a.fillText("扫描小程序  更多惊喜等您来！", d.offsetLeft, d.offsetTop) : (a.fillText("扫描小程序", d.offsetLeft + 20, d.offsetTop - 10), 
                                a.fillText("快来加入我们吧！", d.offsetLeft + 120, d.offsetTop + 20)), getApp().Req.get("Qrcode_getQrCode", {
                                    path: "/yb_shopv2/native/all/index?type=page_distribution&pid=" + getApp().distribution.id
                                }, function(i) {
                                    console.log(i, "获取二维码信息成功"), (0, n.base64src)(i.data, function(i) {
                                        t.hideLoading(), a.drawImage(i, e.width / 2 - r.width / 2, r.offsetTop, r.width, r.width), 
                                        a.save(), a.draw(), t.stopPullDownRefresh();
                                    });
                                }, function(e) {
                                    t.showToast({
                                        icon: "",
                                        title: "获取二维码信息失败，请稍后再试"
                                    });
                                });
                            }
                        });
                    },
                    roundRect: function(t, e, i, o, n, a, s, f) {
                        t.beginPath(), t.arc(e + a, i + a, a, Math.PI, 1.5 * Math.PI), t.moveTo(e + a, i), 
                        t.lineTo(e + o - a, i), t.arc(e + o - a, i + a, a, 1.5 * Math.PI, 2 * Math.PI), 
                        t.lineTo(e + o, i + n - a), t.arc(e + o - a, i + n - a, a, 0, .5 * Math.PI), t.lineTo(e + a, i + n), 
                        t.arc(e + a, i + n - a, a, .5 * Math.PI, Math.PI), t.lineTo(e, i + a), s && (t.setFillStyle(s), 
                        t.fill()), f && (t.setStrokeStyle(f), t.stroke()), t.clip();
                    },
                    saveImage: function() {
                        t.canvasToTempFilePath({
                            x: 0,
                            y: 0,
                            width: this.width,
                            height: this.height,
                            destWidth: this.width,
                            destHeight: this.height,
                            canvasId: "firstCanvas",
                            success: function(e) {
                                console.log(e.tempFilePath, "图片地址路径"), t.saveImageToPhotosAlbum({
                                    filePath: e.tempFilePath,
                                    success: function() {
                                        t.showToast({
                                            icon: "none",
                                            title: "图片已保存到手机相册"
                                        });
                                    }
                                });
                            }
                        });
                    }
                }
            };
            e.default = s;
        }).call(this, i("543d")["default"]);
    },
    "8dd1": function(t, e, i) {},
    d645: function(t, e, i) {
        "use strict";
        var o = i("8dd1"), n = i.n(o);
        n.a;
    }
}, [ [ "19f8", "common/runtime", "common/vendor" ] ] ]);