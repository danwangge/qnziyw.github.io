(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/express/express" ], {
    "425c": function(e, n, t) {
        "use strict";
        var r = function() {
            var e = this, n = e.$createElement;
            e._self._c;
        }, u = [];
        t.d(n, "a", function() {
            return r;
        }), t.d(n, "b", function() {
            return u;
        });
    },
    "44c6": function(e, n, t) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = u(t("3b18"));
        function u(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        var o = {
            props: {
                orderId: {
                    type: [ String, Number ],
                    default: 0
                }
            },
            mixins: [ r.default ],
            data: function() {
                return {
                    info: {
                        express_name: "",
                        express_no: "",
                        express_info: []
                    }
                };
            },
            mounted: function() {
                var e = this;
                getApp().Req.get("Order_getExpressInfo", {
                    order_id: this.orderId
                }, function(n) {
                    200 == n.code ? e.info = n.info : e.info = {};
                });
            },
            methods: {
                page_onLoad: function() {
                    this.title = "物流信息";
                }
            }
        };
        n.default = o;
    },
    6885: function(e, n, t) {},
    "76dc": function(e, n, t) {
        "use strict";
        var r = t("6885"), u = t.n(r);
        u.a;
    },
    "79b9": function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("425c"), u = t("afc7");
        for (var o in u) "default" !== o && function(e) {
            t.d(n, e, function() {
                return u[e];
            });
        }(o);
        t("76dc");
        var i = t("2877"), a = Object(i["a"])(u["default"], r["a"], r["b"], !1, null, null, null);
        n["default"] = a.exports;
    },
    afc7: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("44c6"), u = t.n(r);
        for (var o in r) "default" !== o && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        n["default"] = u.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/express/express-create-component", {
    "yb_shopv2/pages/express/express-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("79b9"));
    }
}, [ [ "yb_shopv2/pages/express/express-create-component" ] ] ]);