(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/null-page/null-page" ], {
    "003c": function(n, t, e) {},
    2155: function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = {
            name: "null-data"
        };
        t.default = u;
    },
    "7bdf": function(n, t, e) {
        "use strict";
        var u = function() {
            var n = this, t = n.$createElement;
            n._self._c;
        }, a = [];
        e.d(t, "a", function() {
            return u;
        }), e.d(t, "b", function() {
            return a;
        });
    },
    b6fd: function(n, t, e) {
        "use strict";
        var u = e("003c"), a = e.n(u);
        a.a;
    },
    c19c: function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("7bdf"), a = e("fd4b");
        for (var c in a) "default" !== c && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(c);
        e("b6fd");
        var f = e("2877"), r = Object(f["a"])(a["default"], u["a"], u["b"], !1, null, null, null);
        t["default"] = r.exports;
    },
    f844: function(n, t, e) {
        "use strict";
        (function(n) {
            e("1a02");
            u(e("66fd"));
            var t = u(e("c19c"));
            function u(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            n(t.default);
        }).call(this, e("543d")["createPage"]);
    },
    fd4b: function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("2155"), a = e.n(u);
        for (var c in u) "default" !== c && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(c);
        t["default"] = a.a;
    }
}, [ [ "f844", "common/runtime", "common/vendor" ] ] ]);