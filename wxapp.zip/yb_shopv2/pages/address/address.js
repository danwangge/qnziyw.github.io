(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/address/address" ], {
    "027e": function(e, t, s) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = l(s("3b18")), n = l(s("c8bc")), r = s("b1b6");
            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var a = function() {
                return s.e("yb_shopv2/component/CustomButton").then(s.bind(null, "088b"));
            }, o = function() {
                return s.e("yb_shopv2/component/CustomPicker").then(s.bind(null, "5605"));
            }, d = {
                name: "address",
                props: {
                    parent: {
                        type: String,
                        default: ""
                    },
                    sourceList: {
                        type: String,
                        default: ""
                    }
                },
                mixins: [ i.default, n.default ],
                data: function() {
                    return {
                        list: [],
                        checkedId: 1,
                        validate: {
                            consigner: [ {
                                rule: /\S+/,
                                message: "收件人名称不能为空"
                            } ],
                            phone: [ {
                                rule: /\S+/,
                                message: "收件人手机号不能为空"
                            }, {
                                rule: /^1[3456789]\d{9}$/,
                                message: "请输入正确手机号"
                            } ],
                            areaCode: [ {
                                rule: /\S+/,
                                message: "请选择收货位置"
                            } ],
                            address: [ {
                                rule: /\S+/,
                                message: "请填写收货详细地址"
                            } ]
                        },
                        errorMsg: {
                            message: "",
                            name: "",
                            index: -1
                        },
                        page_path: "pages/address/address"
                    };
                },
                computed: {
                    globalColor: function() {
                        return getApp().common.globle.color;
                    },
                    editStatus: function() {
                        return this.list.filter(function(e) {
                            return e.edit;
                        }).length;
                    }
                },
                mounted: function() {
                    "confirm_order_selfmention" === this.parent && this.sourceList.length ? (console.log("加载自提列表！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！"), 
                    this.list = JSON.parse(this.sourceList)) : this.getPageData();
                },
                watch: {
                    sourceList: function(e) {
                        "confirm_order_selfmention" === this.parent && (this.list = e);
                    },
                    list: {
                        handler: function(e) {
                            "confirm_order_selfmention" !== this.parent && (this.errorMsg.message = "", this.errorMsg.name = "", 
                            this.errorMsg.index = -1, getApp().userAddress = e);
                        },
                        deep: !0
                    }
                },
                components: {
                    CustomButton: a,
                    CustomPicker: o
                },
                methods: {
                    page_onLoad: function(t) {
                        "confirm_order_selfmention" !== this.parent ? (this.title = "收货地址列表", e.showLoading({
                            title: "加载中"
                        })) : this.title = "自提点列表", e.setNavigationBarColor({
                            frontColor: "#000000",
                            backgroundColor: "#ffffff"
                        });
                    },
                    handlerAddressActive: function(t, s) {
                        this.parent && t.id && !t.edit && (this.list.forEach(function(e) {
                            e.checked = !1;
                        }), this.list[s].checked = !0, "confirm_order_selfmention" === this.parent && e.$emit("set_selfmention", s), 
                        this.$nextTick(function() {
                            e.navigateBack();
                        }));
                    },
                    handlerAddressEdit: function(e, t, s) {
                        t[s] = e.detail.value;
                    },
                    handlerSubmitData: function(e) {
                        return Object.assign(e.id ? {
                            id: e.id
                        } : {}, {
                            user_id: getApp().user.userid,
                            consigner: e.consigner,
                            area: e.areaCode,
                            phone: e.phone,
                            address: e.address,
                            zip_code: e.postcode,
                            is_default: e.default
                        });
                    },
                    switchEditStatus: function(t, s, i) {
                        var n = this;
                        if ("save" !== s && "cancel" !== s && this.editStatus) e.showToast({
                            title: "请先完成正在编辑的地址",
                            icon: "none"
                        }); else if ("save" === s) {
                            for (var l in this.validate) if (this.validate.hasOwnProperty(l)) for (var a = 0; a < this.validate[l].length; a++) if (!this.validate[l][a].rule.test(t[l])) return this.errorMsg.message = this.validate[l][a].message, 
                            this.errorMsg.name = l, void (this.errorMsg.index = i);
                            delete t.cacheData, (0, r.get)("Member_userAddress", this.handlerSubmitData(t)).then(function(s) {
                                t.edit = !t.edit, t.id = Number(s.data), console.log(s, "更新数据！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！"), 
                                e.showToast({
                                    title: "保存成功！"
                                }), "confirm_order_address" === n.parent && n.handlerAddressActive(t, i);
                            }).catch(function(e) {
                                console.log(e);
                            });
                        } else if ("edit" === s) t.edit = !t.edit, t.cacheData = JSON.stringify(t); else if ("cancel" === s) {
                            t.edit = !t.edit, void 0 === t.id && this.list.splice(i, 1);
                            var o = JSON.parse(t.cacheData);
                            for (var d in o) o.hasOwnProperty(d) && "edit" !== d && (t[d] = o[d]);
                            delete t.cacheData;
                        }
                    },
                    getPageData: function() {
                        var t = this;
                        getApp().userAddress.length ? (this.list = getApp().userAddress, e.hideLoading(), 
                        e.stopPullDownRefresh()) : (0, r.get)("Member_userAddressList", {
                            user_id: getApp().user.userid
                        }).then(function(s) {
                            console.log(s, "llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll"), 
                            e.hideLoading(), e.stopPullDownRefresh(), t.list = getApp().userAddress = s.data.map(function(e) {
                                return {
                                    id: e.id,
                                    areaCode: e.area,
                                    area: [ e.province, e.city, e.district ],
                                    consigner: e.consigner,
                                    phone: e.phone,
                                    address: e.address,
                                    default: e.is_default,
                                    edit: 0,
                                    postcode: e.zip_code,
                                    checked: !!e.is_default
                                };
                            });
                        });
                    },
                    radioClick: function(t) {
                        var s = this;
                        if (!t.default) {
                            var i = -1;
                            this.list.forEach(function(e, t) {
                                1 === e.default && (i = t, e.default = 0);
                            }), t.default = 1, t.edit || (0, r.get)("Member_userAddress", this.handlerSubmitData(t)).then(function(t) {
                                e.showToast({
                                    title: "更新成功！"
                                });
                            }).cache(function(e) {
                                t.default = 0, s.list[i].default = 1;
                            });
                        }
                    },
                    deleteAddress: function(t, s) {
                        var i = this;
                        s.default ? e.showToast({
                            icon: "none",
                            title: "默认地址不能删除"
                        }) : e.showModal({
                            title: "提示",
                            content: "确认将该收货地址删除？删除后无法恢复",
                            confirmColor: "#ff4040",
                            success: function(n) {
                                n.confirm ? (0, r.get)("Member_userAddressDel", {
                                    user_id: getApp().user.userid,
                                    id: s.id
                                }).then(function(s) {
                                    i.list.splice(t, 1), e.showToast({
                                        title: "删除成功！"
                                    });
                                }) : n.cancel && console.log("取消删除");
                            }
                        });
                    },
                    appendAddress: function() {
                        if (this.editStatus) {
                            var e = this.list.findIndex(function(e) {
                                return e.edit;
                            });
                            this.switchEditStatus(this.list[e], "save", e);
                        } else this.list.unshift({
                            consigner: "",
                            phone: "",
                            areaCode: [ "", "", "" ],
                            area: [ "请选择所在区域", "", "" ],
                            address: "",
                            default: 0 === this.list.length ? 1 : 0,
                            edit: 1,
                            postcode: "",
                            checked: !1
                        });
                    },
                    cityChooseConfirm: function(e, t) {
                        e.area = t.detail.value, e.areaCode = t.detail.code[2];
                    }
                }
            };
            t.default = d;
        }).call(this, s("543d")["default"]);
    },
    "03c0": function(e, t, s) {
        "use strict";
        s.r(t);
        var i = s("abe9"), n = s("0ecf");
        for (var r in n) "default" !== r && function(e) {
            s.d(t, e, function() {
                return n[e];
            });
        }(r);
        s("de78");
        var l = s("2877"), a = Object(l["a"])(n["default"], i["a"], i["b"], !1, null, null, null);
        t["default"] = a.exports;
    },
    "0ecf": function(e, t, s) {
        "use strict";
        s.r(t);
        var i = s("027e"), n = s.n(i);
        for (var r in i) "default" !== r && function(e) {
            s.d(t, e, function() {
                return i[e];
            });
        }(r);
        t["default"] = n.a;
    },
    6787: function(e, t, s) {},
    abe9: function(e, t, s) {
        "use strict";
        var i = function() {
            var e = this, t = e.$createElement, s = (e._self._c, e.__map(e.list, function(t, s) {
                var i = t.area.join("  ");
                return {
                    $orig: e.__get_orig(t),
                    g0: i
                };
            }));
            e.$mp.data = Object.assign({}, {
                $root: {
                    l0: s
                }
            });
        }, n = [];
        s.d(t, "a", function() {
            return i;
        }), s.d(t, "b", function() {
            return n;
        });
    },
    de78: function(e, t, s) {
        "use strict";
        var i = s("6787"), n = s.n(i);
        n.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/address/address-create-component", {
    "yb_shopv2/pages/address/address-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("03c0"));
    }
}, [ [ "yb_shopv2/pages/address/address-create-component" ] ] ]);