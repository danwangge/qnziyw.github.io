(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/image/index" ], {
    "0fd0": function(t, e, o) {},
    "17de": function(t, e, o) {
        "use strict";
        o.r(e);
        var a = o("fd43"), i = o("ecfd");
        for (var n in i) "default" !== n && function(t) {
            o.d(e, t, function() {
                return i[t];
            });
        }(n);
        o("e399");
        var r = o("2877"), s = Object(r["a"])(i["default"], a["a"], a["b"], !1, null, null, null);
        e["default"] = s.exports;
    },
    c832: function(t, e, o) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = i(o("3b18"));
            function i(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var n = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/pages/index/image_group2") ]).then(o.bind(null, "7b62"));
            }, r = {
                mixins: [ a.default ],
                data: function() {
                    return {
                        topRefresh: 0,
                        bottomRefresh: 0,
                        item: {
                            class_ids: 0,
                            data_type: "",
                            id: "images-list-auto",
                            num: 20,
                            order: "id",
                            showtitle: !1,
                            sort: "desc",
                            css: {
                                "images-list-auto": "background-color:rgba(255, 255, 255, 1.0);background:rgba(255, 255, 255, 1.0);",
                                "images-list-auto &group_item": "border-top:1px solid rgba(241, 241, 241, 1.0);border-right:1px solid rgba(241, 241, 241, 1.0);border-bottom:1px solid rgba(241, 241, 241, 1.0);border-left:1px solid rgba(241, 241, 241, 1.0);background-color:rgba(255, 255, 255, 1.0);background:rgba(255, 255, 255, 1.0);border-radius:4px 4px 4px 4px;box-shadow:0px 2px 12px rgba(0, 0, 0,0.10);",
                                "images-list-auto &group_title": "display:none;",
                                "images-list-auto &item_image": "height:150px;"
                            },
                            animation: {},
                            list: []
                        },
                        page_path: "pages/image/index"
                    };
                },
                components: {
                    ilist: n
                },
                methods: {
                    page_onLoad: function(e) {
                        this.title = "相册", t.showLoading({
                            title: "加载中"
                        }), this.item.class_ids = e.id, this.item.data_type = "auto";
                    },
                    page_onPullDownRefresh: function() {
                        this.topRefresh += 1;
                    },
                    page_onReachBottom: function() {
                        this.bottomRefresh += 1;
                    }
                }
            };
            e.default = r;
        }).call(this, o("543d")["default"]);
    },
    e399: function(t, e, o) {
        "use strict";
        var a = o("0fd0"), i = o.n(a);
        i.a;
    },
    ecfd: function(t, e, o) {
        "use strict";
        o.r(e);
        var a = o("c832"), i = o.n(a);
        for (var n in a) "default" !== n && function(t) {
            o.d(e, t, function() {
                return a[t];
            });
        }(n);
        e["default"] = i.a;
    },
    fd43: function(t, e, o) {
        "use strict";
        var a = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, i = [];
        o.d(e, "a", function() {
            return a;
        }), o.d(e, "b", function() {
            return i;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/image/index-create-component", {
    "yb_shopv2/pages/image/index-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("17de"));
    }
}, [ [ "yb_shopv2/pages/image/index-create-component" ] ] ]);