(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/bargain/bargain" ], {
    "14f8": function(t, i, e) {
        "use strict";
        var n = e("d30e"), o = e.n(n);
        o.a;
    },
    a2b7: function(t, i, e) {
        "use strict";
        e.r(i);
        var n = e("e745"), o = e.n(n);
        for (var a in n) "default" !== a && function(t) {
            e.d(i, t, function() {
                return n[t];
            });
        }(a);
        i["default"] = o.a;
    },
    be8d: function(t, i, e) {
        "use strict";
        var n = function() {
            var t = this, i = t.$createElement, e = (t._self._c, Number(t.activityInfo.current_price)), n = Number(t.activityInfo.lowest_price), o = Number(t.activityInfo.current_price), a = Number(t.activityInfo.lowest_price), s = Number(t.activityInfo.current_price), u = Number(t.activityInfo.lowest_price);
            t.$mp.data = Object.assign({}, {
                $root: {
                    m0: e,
                    m1: n,
                    m2: o,
                    m3: a,
                    m4: s,
                    m5: u
                }
            });
        }, o = [];
        e.d(i, "a", function() {
            return n;
        }), e.d(i, "b", function() {
            return o;
        });
    },
    ce12: function(t, i, e) {
        "use strict";
        e.r(i);
        var n = e("be8d"), o = e("a2b7");
        for (var a in o) "default" !== a && function(t) {
            e.d(i, t, function() {
                return o[t];
            });
        }(a);
        e("14f8");
        var s = e("2877"), u = Object(s["a"])(o["default"], n["a"], n["b"], !1, null, null, null);
        i["default"] = u.exports;
    },
    d30e: function(t, i, e) {},
    e745: function(t, i, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var n = u(e("3b18")), o = u(e("c8bc")), a = e("b1b6"), s = u(e("21b4"));
            function u(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var c = function() {
                return e.e("yb_shopv2/component/CustomCountDown").then(e.bind(null, "ad8f"));
            }, r = {
                name: "bargain",
                data: function() {
                    return {
                        visible: !1,
                        show: !1,
                        animation: !0,
                        posterVisible: !1,
                        posterShow: !1,
                        posterAnimation: !0,
                        posterCanvasShow: !1,
                        activityId: 0,
                        launchId: 0,
                        activityInfo: {},
                        productInfo: {},
                        cutMoney: "0.00",
                        qrcodeUrl: "",
                        defaultAvatar: e("5140"),
                        cacheFilePath: ""
                    };
                },
                mixins: [ n.default, o.default ],
                computed: {
                    processWidth: function() {
                        return (Number(this.activityInfo.high_price) - Number(this.activityInfo.current_price)) / (Number(this.activityInfo.high_price) - Number(this.activityInfo.lowest_price)) * 100 + "%";
                    },
                    userId: function() {
                        return Number(getApp().user.userid);
                    }
                },
                components: {
                    CustomCountDown: c
                },
                methods: {
                    page_onLoad: function(i) {
                        var e = this;
                        this.title = "砍价详情", this.activityId = i.activity_id, this.launchId = i.launch_id, 
                        t.showLoading({
                            title: "加载中..."
                        }), Promise.all([ this.getBargainDetailInfo(), this.getShareQrcode() ]).then(function(t) {
                            e.renderCanvas();
                        });
                    },
                    page_onPullDownRefresh: function() {
                        t.showLoading({
                            title: "加载中..."
                        }), this.getBargainDetailInfo(), this.getShareQrcode();
                    },
                    getBargainDetailInfo: function() {
                        var i = this;
                        return (0, a.get)("Bargain_getBargainUser", {
                            launch_id: this.launchId,
                            activity_id: this.activityId
                        }).then(function(e) {
                            return t.hideLoading(), t.stopPullDownRefresh(), i.activityInfo = e.data.activity, 
                            i.productInfo = e.data.goods, console.log(e, "砍价详情砍价详情砍价详情砍价详情砍价详情砍价详情砍价详情砍价详情砍价详情砍价详情砍价详情砍价详情砍价详情"), 
                            (0, a.get)("Bargain_getHelpPrice", {
                                user_id: getApp().user.userid,
                                launch_id: i.launchId,
                                activity_id: i.activityId
                            });
                        }).then(function(t) {
                            return console.log(t, "砍价成功砍价成功砍价成功砍价成功砍价成功砍价成功砍价成功砍价成功砍价成功砍价成功砍价成功砍价成功"), t.data.is_help || (i.activityInfo.current_price = t.data.current_price, 
                            i.cutMoney = t.data.cut_money, setTimeout(function() {
                                i.dialogShow();
                            }, 300)), Promise.resolve();
                        }).catch(function(t) {
                            console.log(t, "砍价失败砍价失败砍价失败砍价失败砍价失败砍价失败砍价失败砍价失败砍价失败砍价失败砍价失败砍价失败砍价失败");
                        });
                    },
                    shareBargain: function(i) {
                        var e = this;
                        "share" === i ? (this.dialogHide("fast"), this.jump({
                            type: "share"
                        })) : "save" === i && t.authorize({
                            scope: "scope.writePhotosAlbum",
                            success: function() {
                                e.savePoster();
                            },
                            fail: function(t) {
                                console.log(t, "调用失败调用失败调用失败调用失败调用失败调用失败调用失败调用失败");
                            }
                        });
                    },
                    goToOrderConfirm: function() {
                        var t = {};
                        t.id = this.productInfo.id, t.title = this.productInfo.goods_name, t.count = this.productInfo.num, 
                        t.image = this.productInfo.pic, t.skuId = this.productInfo.sku_id, t.cate = this.productInfo.spec_name_group, 
                        t.shoppingId = this.productInfo.shipping_id, t.price = this.activityInfo.high_price, 
                        t.hideCount = !0, this.jump({
                            type: "confirm_order",
                            params: JSON.stringify([ t ]),
                            order_type: 2,
                            activity_id: this.activityInfo && this.activityInfo.activity_id || null,
                            launch_id: this.launchId
                        });
                    },
                    dialogShow: function() {
                        var t = this;
                        this.visible = !0, this.show = !0, this.$nextTick(function() {
                            t.animation = !1;
                        });
                    },
                    dialogHide: function(t) {
                        var i = this;
                        this.show = !1, this.animation = !0, setTimeout(function() {
                            i.visible = !1;
                        }, "fast" === t ? 0 : 300);
                    },
                    getShareQrcode: function() {
                        var t = this;
                        return (0, a.get)("Qrcode_getQrCode", {
                            path: "yb_shopv2/native/all/index?type=bargain_detail&activity_id=".concat(this.activityId, "&launch_id=").concat(this.launchId)
                        }).then(function(i) {
                            return t.qrcodeUrl = i.data, Promise.resolve();
                        });
                    },
                    posterDialogShow: function() {
                        var t = this;
                        this.posterVisible = !0, this.posterShow = !0, this.$nextTick(function() {
                            t.posterAnimation = !1, setTimeout(function() {
                                t.posterCanvasShow = !0, t.renderCanvas();
                            }, 300);
                        });
                    },
                    posterDialogHide: function() {
                        var t = this;
                        this.posterAnimation = !0, this.posterShow = !1, this.posterCanvasShow = !1, setTimeout(function() {
                            t.posterVisible = !1;
                        }, 300);
                    },
                    renderCanvas: function() {
                        var i = this, e = t.createCanvasContext("poster-canvas", this), n = this, o = a(this.productInfo.goods_name, 12, 2);
                        function a(t, i, e) {
                            for (var n = [], o = 0, a = 0; a < t.length; a++) a === t.length - 1 ? n.push(t.substr(o, i)) : a % i === 0 && 0 !== a && (n.push(t.substr(o, i)), 
                            o = a);
                            return e && n.length > e && (n.splice(e, n.length - e), n[n.length - 1] = n[n.length - 1] + "..."), 
                            n;
                        }
                        Promise.all([ this.activityInfo.user_headimg ? new Promise(function(e, n) {
                            t.getImageInfo({
                                src: i.activityInfo.user_headimg,
                                success: function(t) {
                                    e(t.path);
                                },
                                fail: function(t) {
                                    n(t);
                                }
                            });
                        }) : s.default.base64src(this.defaultAvatar, "temp_default_avatar"), new Promise(function(e, n) {
                            t.getImageInfo({
                                src: i.productInfo.pic,
                                success: function(t) {
                                    e(t.path);
                                },
                                fail: function(t) {
                                    n(t);
                                }
                            });
                        }), s.default.base64src(this.qrcodeUrl, "temp_bargain_qrcode") ]).then(function(a) {
                            console.log(a[0], "头像头像头像头像头像头像头像头像头像头像头像头像头像头像头像头像头像头像头像头像"), console.log(a[1], "商品图片商品图片商品图片商品图片商品图片商品图片商品图片商品图片商品图片商品图片商品图片商品图片"), 
                            console.log(a[2], "二维码二维码二维码二维码二维码二维码二维码二维码二维码二维码二维码二维码二维码二维码"), e.fillStyle = "#ffffff", 
                            e.fillRect(0, 0, t.upx2px(630), t.upx2px(740)), e.beginPath(), e.moveTo(0, 0), e.lineTo(t.upx2px(630), 0), 
                            e.lineTo(t.upx2px(630), t.upx2px(380)), e.lineTo(0, t.upx2px(380)), e.lineTo(0, 0), 
                            e.closePath(), e.lineWidth = 1, e.strokeStyle = "#F83E3A", e.stroke(), e.fillStyle = "#F83E3A", 
                            e.fill(), e.save(), e.beginPath(), e.arc(t.upx2px(64), t.upx2px(64), t.upx2px(34), 0, 2 * Math.PI), 
                            e.closePath(), e.clip(), e.drawImage(a[0], t.upx2px(32), t.upx2px(32), t.upx2px(68), t.upx2px(68)), 
                            e.restore(), e.font = "10px Arial", e.fillStyle = "#ffffff", e.fillText("".concat(i.activityInfo.nick_name || "未设置昵称", "发现一件好物，帮TA砍价到底吧"), t.upx2px(118), t.upx2px(70)), 
                            e.save(), e.beginPath(), e.moveTo(t.upx2px(30), t.upx2px(128)), e.lineTo(t.upx2px(600), t.upx2px(128)), 
                            e.lineTo(t.upx2px(600), t.upx2px(350)), e.lineTo(t.upx2px(30), t.upx2px(350)), e.fillStyle = "#ffffff", 
                            e.fill(), e.save(), e.beginPath(), e.moveTo(t.upx2px(50), t.upx2px(148)), e.lineTo(t.upx2px(230), t.upx2px(148)), 
                            e.lineTo(t.upx2px(230), t.upx2px(328)), e.lineTo(t.upx2px(50), t.upx2px(328)), e.closePath(), 
                            e.clip(), e.drawImage(a[1], t.upx2px(50), t.upx2px(148), t.upx2px(180), t.upx2px(180)), 
                            e.restore(), e.font = "11px Arial", e.fillStyle = "#444444", o.forEach(function(i, n) {
                                e.fillText(i, t.upx2px(250), t.upx2px(180) + n * t.upx2px(26));
                            }), e.font = "10px Arial", e.fillStyle = "#F83E3A", e.fillText("最低价￥".concat(i.activityInfo.lowest_price), t.upx2px(250), t.upx2px(310)), 
                            e.fillStyle = "#666666", e.fillText("我正在看这个，觉得不错！", t.upx2px(30), t.upx2px(544)), 
                            e.fillText("长按识别小程序，一起来看吧~", t.upx2px(30), t.upx2px(584)), e.save(), e.beginPath(), 
                            e.moveTo(t.upx2px(350), t.upx2px(430)), e.lineTo(t.upx2px(600), t.upx2px(430)), 
                            e.lineTo(t.upx2px(600), t.upx2px(680)), e.lineTo(t.upx2px(350), t.upx2px(680)), 
                            e.closePath(), e.clip(), e.drawImage(a[2], t.upx2px(350), t.upx2px(430), t.upx2px(250), t.upx2px(250)), 
                            e.restore(), e.draw(!1, t.canvasToTempFilePath({
                                x: 0,
                                y: 0,
                                width: t.upx2px(630),
                                height: t.upx2px(740),
                                destWidth: t.upx2px(630),
                                destHeight: t.upx2px(740),
                                canvasId: "poster-canvas",
                                success: function(t) {
                                    console.log(t.tempFilePath, "图片地址路径"), n.cacheFilePath = t.tempFilePath;
                                },
                                fail: function(t) {
                                    console.log(t, "保存出错保存出错保存出错保存出错保存出错保存出错保存出错保存出错保存出错保存出错保存出错保存出错");
                                }
                            }, i));
                        }).catch(function(t) {
                            console.log(t, "绘制canvas出错绘制canvas出错绘制canvas出错绘制canvas出错绘制canvas出错绘制canvas出错绘制canvas出错");
                        });
                    },
                    savePoster: function() {
                        var i = this;
                        t.saveImageToPhotosAlbum({
                            filePath: this.cacheFilePath,
                            success: function(e) {
                                t.showToast({
                                    icon: "none",
                                    title: "图片已保存到手机相册"
                                }), i.posterDialogHide();
                            },
                            fail: function(t) {
                                console.log(t, "保存失败保存失败保存失败保存失败保存失败保存失败保存失败保存失败保存失败保存失败保存失败保存失败");
                            }
                        });
                    }
                }
            };
            i.default = r;
        }).call(this, e("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/bargain/bargain-create-component", {
    "yb_shopv2/pages/bargain/bargain-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("ce12"));
    }
}, [ [ "yb_shopv2/pages/bargain/bargain-create-component" ] ] ]);