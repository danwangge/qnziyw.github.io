(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/web/index" ], {
    7370: function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var i = a(n("3b18"));
        function a(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        var u = {
            mixins: [ i.default ],
            data: function() {
                return {
                    link: {},
                    page_path: "pages/web/index"
                };
            },
            methods: {
                page_onLoad: function(e) {
                    console.log(e, "webviewwebviewwebviewwebviewwebviewwebviewwebviewwebviewwebviewwebviewwebviewwebviewwebviewwebview"), 
                    this.link = e, this.title = e.title;
                }
            }
        };
        t.default = u;
    },
    "7a78": function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("e8de"), a = n("c2fc");
        for (var u in a) "default" !== u && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(u);
        n("a108");
        var o = n("2877"), r = Object(o["a"])(a["default"], i["a"], i["b"], !1, null, null, null);
        t["default"] = r.exports;
    },
    a108: function(e, t, n) {
        "use strict";
        var i = n("a381"), a = n.n(i);
        a.a;
    },
    a381: function(e, t, n) {},
    c2fc: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n("7370"), a = n.n(i);
        for (var u in i) "default" !== u && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(u);
        t["default"] = a.a;
    },
    e8de: function(e, t, n) {
        "use strict";
        var i = function() {
            var e = this, t = e.$createElement, n = (e._self._c, decodeURIComponent(e.link.url));
            e.$mp.data = Object.assign({}, {
                $root: {
                    m0: n
                }
            });
        }, a = [];
        n.d(t, "a", function() {
            return i;
        }), n.d(t, "b", function() {
            return a;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/web/index-create-component", {
    "yb_shopv2/pages/web/index-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("7a78"));
    }
}, [ [ "yb_shopv2/pages/web/index-create-component" ] ] ]);