(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/chat/sendmsg" ], {
    1823: function(t, a, e) {
        "use strict";
        e.r(a);
        var s = e("fe9c"), n = e.n(s);
        for (var o in s) "default" !== o && function(t) {
            e.d(a, t, function() {
                return s[t];
            });
        }(o);
        a["default"] = n.a;
    },
    "2c65": function(t, a, e) {
        "use strict";
        var s = function() {
            var t = this, a = t.$createElement;
            t._self._c;
        }, n = [];
        e.d(a, "a", function() {
            return s;
        }), e.d(a, "b", function() {
            return n;
        });
    },
    "334f": function(t, a, e) {
        "use strict";
        e.r(a);
        var s = e("2c65"), n = e("1823");
        for (var o in n) "default" !== o && function(t) {
            e.d(a, t, function() {
                return n[t];
            });
        }(o);
        e("a548");
        var i = e("2877"), c = Object(i["a"])(n["default"], s["a"], s["b"], !1, null, null, null);
        a["default"] = c.exports;
    },
    a548: function(t, a, e) {
        "use strict";
        var s = e("dff9"), n = e.n(s);
        n.a;
    },
    dff9: function(t, a, e) {},
    fe9c: function(t, a, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(a, "__esModule", {
                value: !0
            }), a.default = void 0;
            var s = n(e("05d4"));
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var o = "", i = wx.getSystemInfoSync().windowHeight, c = {
                data: function() {
                    return {
                        params: {
                            staff_chatid: getApp().staff.staff_chatid,
                            user_openid: getApp().user.openid,
                            page: 1,
                            target: "2",
                            send_type: "1",
                            status: "2"
                        },
                        staff_info: {},
                        val: "",
                        user_avatar: getApp().user.user_headimg,
                        staff_avatar: "/static/image/chat-kf.png",
                        navArr: [ {
                            url: "/static/image/chat-lxr.png",
                            txt: "保存联系人"
                        }, {
                            url: "/static/image/chat-wx.png",
                            txt: "加微信"
                        }, {
                            url: "/static/image/chat-dh.png",
                            txt: "打电话"
                        } ],
                        chatArr: [],
                        scrolltop: "",
                        scrollHeight: "",
                        bottom: 0,
                        nodata: !1,
                        res: {
                            type: "",
                            msg: ""
                        }
                    };
                },
                onShow: function() {
                    this.socket.sendHeat();
                },
                created: function(a) {
                    var e = this, n = this;
                    n.user_avatar = getApp().user.user_headimg || "/static/image/chat-tx.png", this.socket = new s.default(), 
                    this.socket.start(this.params.user_openid), this.scrollHeight = i - 80;
                    var c = n.params;
                    console.log(c), getApp().Req.get("Chat_getStaffInfo", c, function(t) {
                        console.log(t.data, "单个信息"), n.staff_info = t.data, n.staff_avatar = t.data.avatar || "/static/image/chat-kf.png";
                    }), this.socket.open(function() {
                        setTimeout(function() {
                            e.socket.msgs("status_update", "我上线了，更改已读", e.params.staff_chatid, 0);
                        }, 100);
                    }), t.$on("APP_ONSHOW", function() {
                        n.socket.sendHeat(), n.params.page = 1, n.nodata = !1, n.getData(!0);
                    }), t.$on("SOCKET_MSG", function(t) {
                        if (t.toid == n.params.staff_chatid && ("read" == t.type && n.readMsg(), "status_update" == t.type && n.readMsg(), 
                        "say" == t.type || "image" == t.type)) {
                            n.socket.msgs("read", 2, t.toid), n.res.type = "say", n.res.msg = 1, o = n.formatDateTime();
                            var a = {
                                create_time: o,
                                content: t.msg,
                                target: 1
                            };
                            "image" == t.type ? a.send_type = 2 : a.send_type = 1, n.chatArr.push(a), n.scrolltop = "msg" + (n.chatArr.length - 1);
                        }
                    }), n.getData(!0);
                },
                mounted: function() {
                    this.scrolltop = "msg" + (this.chatArr.length - 1);
                },
                methods: {
                    readMsg: function() {
                        getApp().Req.get("Chat_msgStatus", this.params, function(t) {}), this.chatArr.forEach(function(t) {
                            2 == t.status && (t.status = 1);
                        });
                    },
                    getData: function(t) {
                        var a = this;
                        if (!a.nodata) {
                            var e = a.params;
                            getApp().Req.get("Chat_getMessage", e, function(e) {
                                console.log(e, "进入聊天页面，获得聊天记录"), 1 == e.code ? (1 === a.params.page && (a.chatArr = []), 
                                a.chatArr = e.data.concat(a.chatArr), t && (a.scrolltop = "msg" + (a.chatArr.length - 1)), 
                                a.params.page++) : a.nodata = !0;
                            });
                        }
                    },
                    fdPhoto: function(a) {
                        t.previewImage({
                            current: a,
                            urls: [ a ]
                        });
                    },
                    jump: function(a) {
                        var e = this;
                        0 == a && (e.staff_info.phone ? t.addPhoneContact({
                            firstName: e.staff_info.user_name || "客服人员",
                            mobilePhoneNumber: e.staff_info.phone,
                            success: function() {
                                console.log("success");
                            },
                            fail: function() {
                                console.log("fail");
                            }
                        }) : t.showToast({
                            icon: "none",
                            title: "暂无客服人员电话"
                        })), 1 == a && (e.staff_info.wx_num ? t.showModal({
                            title: "客服微信号",
                            content: e.staff_info.wx_num,
                            confirmText: "点击复制",
                            confirmColor: "#000",
                            success: function(a) {
                                a.confirm ? t.setClipboardData({
                                    data: e.staff_info.wx_num,
                                    success: function() {
                                        t.showToast({
                                            icon: "none",
                                            title: "复制成功"
                                        });
                                    }
                                }) : a.cancel;
                            }
                        }) : t.showToast({
                            icon: "none",
                            title: "暂无客服人员微信号"
                        })), 2 == a && (e.staff_info.phone ? t.showModal({
                            title: "是否要拨打这个电话？",
                            content: e.staff_info.phone,
                            success: function(a) {
                                a.confirm ? t.makePhoneCall({
                                    phoneNumber: e.staff_info.phone
                                }) : a.cancel && console.log("用户点击取消");
                            }
                        }) : t.showToast({
                            icon: "none",
                            title: "暂无客服人员电话"
                        }));
                    },
                    focus: function(t) {
                        this.bottom = t.detail.height, this.scrollHeight = i - t.detail.height - 80;
                    },
                    blur: function() {
                        this.bottom = 0, this.scrollHeight = i - 80, this.scrolltop = "msg" + (this.chatArr.length - 1);
                    },
                    send: function() {
                        o = this.formatDateTime();
                        var t = this, a = this.params;
                        a["content"] = this.val, a["send_type"] = 1, getApp().Req.get("Chat_putMessage", a, function(t) {
                            console.log(t, "发送单条消息，存了入数据库");
                        }), console.log(this.params.staff_chatid), this.socket.send(this.val, this.params.staff_chatid), 
                        o = t.formatDateTime();
                        var e = {
                            create_time: o,
                            content: t.val,
                            target: 2,
                            status: 2,
                            send_type: 1
                        };
                        this.chatArr.push(e), this.val = "", this.scrolltop = "msg" + (this.chatArr.length - 1);
                    },
                    upload: function() {
                        var a = this;
                        t.chooseImage({
                            success: function(t) {
                                var e = t.tempFilePaths;
                                getApp().Req.uploadfile("Chat_msgUpload", {}, e[0], function(t) {
                                    if (console.log(t), 1 == t.code) {
                                        o = a.formatDateTime();
                                        var e = {
                                            id: a.params.id,
                                            target: 2,
                                            status: 2,
                                            create_time: o,
                                            content: t.url,
                                            send_type: 2
                                        };
                                        a.chatArr.push(e);
                                        var s = a.params;
                                        s["content"] = t.url, s["send_type"] = 2, getApp().Req.get("Chat_putMessage", s, function(t) {
                                            console.log(t, "发送单条消息，存了入数据库");
                                        }), a.socket.send(t.url, a.params.staff_chatid, 1);
                                    }
                                });
                            }
                        });
                    },
                    upper: function() {
                        this.getData();
                    },
                    formatDateTime: function() {
                        var t = new Date(), a = t.getFullYear(), e = t.getMonth() + 1;
                        e = e < 10 ? "0" + e : e;
                        var s = t.getDate();
                        s = s < 10 ? "0" + s : s;
                        var n = t.getHours();
                        n = n < 10 ? "0" + n : n;
                        var o = t.getMinutes();
                        o = o < 10 ? "0" + o : o;
                        var i = t.getSeconds();
                        return i = i < 10 ? "0" + i : i, a + "-" + e + "-" + s + " " + n + ":" + o + ":" + i;
                    }
                },
                destroyed: function() {
                    this.socket.close(), t.$off("SOCKET_MSG"), t.$off("APP_ONSHOW");
                }
            };
            a.default = c;
        }).call(this, e("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/chat/sendmsg-create-component", {
    "yb_shopv2/pages/chat/sendmsg-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("334f"));
    }
}, [ [ "yb_shopv2/pages/chat/sendmsg-create-component" ] ] ]);