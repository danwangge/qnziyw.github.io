(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/good-list/good-list" ], {
    "137b": function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = s(n("c8bc")), o = s(n("3b18")), i = s(n("ffc5")), u = n("b1b6");
            function s(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var l = function() {
                return Promise.all([ n.e("common/vendor"), n.e("yb_shopv2/module/ModuleGoodList") ]).then(n.bind(null, "47e1"));
            }, r = {
                name: "goods-list",
                props: {
                    classId: {
                        type: Number,
                        default: 0
                    }
                },
                data: function() {
                    return {
                        list: [],
                        page_path: "pages/good-list/good-list"
                    };
                },
                mixins: [ a.default, o.default, i.default ],
                components: {
                    ModuleGoodList: l
                },
                mounted: function() {
                    this.getPageData();
                },
                methods: {
                    page_onPullDownRefresh: function() {
                        this.page = 1, this.getPageData();
                    },
                    getPageData: function() {
                        var t = this;
                        (0, u.get)("Goods_getGoods", {
                            class_id: this.classId,
                            page: this.page,
                            page_size: this.pageSize,
                            user_id: getApp().user.userid
                        }).then(function(n) {
                            e.stopPullDownRefresh();
                            var a = n.data.map(function(e) {
                                return {
                                    id: e.id,
                                    image: e.pic,
                                    title: e.goods_name,
                                    price: e.price,
                                    level: e.level
                                };
                            });
                            t.list = 1 === t.page ? a : t.list.concat(a);
                        });
                    }
                }
            };
            t.default = r;
        }).call(this, n("543d")["default"]);
    },
    8696: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("137b"), o = n.n(a);
        for (var i in a) "default" !== i && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(i);
        t["default"] = o.a;
    },
    cca7: function(e, t, n) {
        "use strict";
        var a = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, o = [];
        n.d(t, "a", function() {
            return a;
        }), n.d(t, "b", function() {
            return o;
        });
    },
    cf26: function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("cca7"), o = n("8696");
        for (var i in o) "default" !== i && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        var u = n("2877"), s = Object(u["a"])(o["default"], a["a"], a["b"], !1, null, null, null);
        t["default"] = s.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/good-list/good-list-create-component", {
    "yb_shopv2/pages/good-list/good-list-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("cf26"));
    }
}, [ [ "yb_shopv2/pages/good-list/good-list-create-component" ] ] ]);