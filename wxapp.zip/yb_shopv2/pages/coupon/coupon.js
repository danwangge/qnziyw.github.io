(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/coupon/coupon" ], {
    "66a3": function(t, n, o) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = i(o("c8bc")), a = i(o("3b18")), u = i(o("ffc5")), g = o("b1b6");
            function i(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var s = function() {
                return o.e("yb_shopv2/component/CustomTabBar").then(o.bind(null, "080c"));
            }, r = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/module/ModuleCoupon") ]).then(o.bind(null, "5950"));
            }, c = {
                name: "coupon",
                props: {
                    params: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        couponStatus: [ {
                            title: "未使用",
                            id: 0
                        }, {
                            title: "已使用",
                            id: 1
                        }, {
                            title: "已过期",
                            id: 2
                        } ],
                        list: [],
                        couponStatusCur: 0,
                        page_path: "pages/coupon/coupon"
                    };
                },
                mixins: [ e.default, a.default, u.default ],
                computed: {
                    filterCouponList: function() {
                        var t = this;
                        return "private" === this.params ? this.list.filter(function(n) {
                            return n.status === t.couponStatus[t.couponStatusCur].id;
                        }) : this.list;
                    }
                },
                mounted: function() {
                    this.getPageData();
                },
                components: {
                    CustomTabBar: s,
                    ModuleCoupon: r
                },
                methods: {
                    page_onLoad: function(n) {
                        this.title = "public" === this.params ? "优惠券列表" : "我的优惠券", t.showLoading({
                            title: "加载中"
                        }), t.setNavigationBarColor({
                            frontColor: "#000000",
                            backgroundColor: "#ffffff"
                        });
                    },
                    couponStatusChange: function(t) {
                        this.couponStatusCur = t, this.page = 1, this.getPageData();
                    },
                    proxyGetData: function() {
                        this.page = 1, this.getPageData();
                    },
                    getPageData: function() {
                        var n = this;
                        "public" === this.params ? (0, g.get)("Shop_getCouponList", {
                            page: this.page,
                            user_id: getApp().user.userid
                        }).then(function(o) {
                            console.log(o, "gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg"), 
                            t.hideLoading(), t.stopPullDownRefresh(), n.list = 1 === n.page ? o.data : n.list.concat(o.data), 
                            o.data.length < 20 && (n.end = !0);
                        }) : (0, g.get)("Shop_getUserCouponList", {
                            user_id: getApp().user.userid,
                            status: this.couponStatus[this.couponStatusCur].id,
                            page: this.page
                        }).then(function(o) {
                            t.hideLoading(), t.stopPullDownRefresh(), console.log(o.data);
                            var e = o.data.map(function(t) {
                                return t.statusText = "未使用", t;
                            });
                            n.list = 1 === n.page ? e : n.list.concat(e), e.length < 20 && (n.end = !0);
                        });
                    }
                }
            };
            n.default = c;
        }).call(this, o("543d")["default"]);
    },
    "6ba3": function(t, n, o) {
        "use strict";
        o.r(n);
        var e = o("66a3"), a = o.n(e);
        for (var u in e) "default" !== u && function(t) {
            o.d(n, t, function() {
                return e[t];
            });
        }(u);
        n["default"] = a.a;
    },
    "745b": function(t, n, o) {
        "use strict";
        var e = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, a = [];
        o.d(n, "a", function() {
            return e;
        }), o.d(n, "b", function() {
            return a;
        });
    },
    "92dc": function(t, n, o) {},
    c8cd: function(t, n, o) {
        "use strict";
        var e = o("92dc"), a = o.n(e);
        a.a;
    },
    e938: function(t, n, o) {
        "use strict";
        o.r(n);
        var e = o("745b"), a = o("6ba3");
        for (var u in a) "default" !== u && function(t) {
            o.d(n, t, function() {
                return a[t];
            });
        }(u);
        o("c8cd");
        var g = o("2877"), i = Object(g["a"])(a["default"], e["a"], e["b"], !1, null, null, null);
        n["default"] = i.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/coupon/coupon-create-component", {
    "yb_shopv2/pages/coupon/coupon-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("e938"));
    }
}, [ [ "yb_shopv2/pages/coupon/coupon-create-component" ] ] ]);