(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/mine-order/mine-order" ], {
    "397a": function(t, e, o) {
        "use strict";
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, n = [];
        o.d(e, "a", function() {
            return i;
        }), o.d(e, "b", function() {
            return n;
        });
    },
    "467f": function(t, e, o) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            a(o("21b4"));
            var i = o("b1b6"), n = a(o("c8bc")), r = a(o("ffc5")), s = a(o("3b18"));
            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var d = function() {
                return o.e("yb_shopv2/component/CustomTabBar").then(o.bind(null, "080c"));
            }, u = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/module/ModuleGoodList") ]).then(o.bind(null, "47e1"));
            }, c = function() {
                return o.e("yb_shopv2/component/CustomNoData").then(o.bind(null, "8a57"));
            }, m = {
                name: "mine-order",
                data: function() {
                    return {
                        list: [],
                        statusList: [ {
                            title: "全部",
                            id: -1
                        }, {
                            title: "待支付",
                            id: 0
                        }, {
                            title: "待发货",
                            id: 1
                        }, {
                            title: "待收货",
                            id: 2
                        }, {
                            title: "待评价",
                            id: 3
                        }, {
                            title: "退款中",
                            id: 5
                        } ],
                        orderStatusCur: 0,
                        init: !0,
                        commentVisible: !1,
                        commentShow: !1,
                        commentAnimation: !0,
                        refundVisible: !1,
                        refundShow: !1,
                        refundAnimation: !0,
                        orderType: 0,
                        activeCommentGood: {},
                        activeOrder: {},
                        refundReason: "",
                        page_path: "pages/mine-order/mine-order"
                    };
                },
                mixins: [ n.default, s.default, r.default ],
                computed: {},
                components: {
                    CustomTabBar: d,
                    ModuleGoodList: u,
                    CustomNoData: c
                },
                methods: {
                    page_onLoad: function(e) {
                        this.title = e.title || "我的订单", t.showLoading({
                            title: "加载中"
                        }), t.setNavigationBarColor({
                            frontColor: "#000000",
                            backgroundColor: "#ffffff"
                        }), this.orderStatusCur = e.tab || 0, this.orderType = e.order_type || 0, this.getPageData();
                    },
                    goToBargainDetail: function(t) {
                        0 !== t.status && this.jump({
                            type: "bargain_detail",
                            launch_id: t.id,
                            activity_id: t.activity_id
                        });
                    },
                    changeOrderStatus: function(e, o, n) {
                        var r = this;
                        if ("delete" === n) t.showModal({
                            title: "提示",
                            content: "确认将该订单删除？删除后无法恢复",
                            confirmColor: "#ff4040",
                            success: function(n) {
                                n.confirm ? (0, i.get)("Order_updOrderStatus", {
                                    order_id: o.order_id,
                                    status: -1,
                                    user_id: getApp().user.userid
                                }).then(function(o) {
                                    t.showToast({
                                        title: "删除成功！"
                                    }), r.list.splice(e, 1);
                                }) : n.cancel && console.log("取消删除");
                            }
                        }); else if ("cancel" === n) t.showModal({
                            title: "提示",
                            content: "确认取消该订单？",
                            confirmColor: "#ff4040",
                            success: function(e) {
                                e.confirm ? (0, i.get)("Order_updOrderStatus", {
                                    order_id: o.order_id,
                                    status: 6,
                                    user_id: getApp().user.userid
                                }).then(function(e) {
                                    t.showToast({
                                        title: "取消成功！"
                                    }), r.page = 1, r.getPageData();
                                }) : e.cancel && console.log("取消");
                            }
                        }); else if ("pay" === n) {
                            if (this.payLoading) return;
                            this.payLoading = !0, (0, i.payRequest)({
                                order_no: o.order_no,
                                order_id: o.order_id,
                                order_type: 0
                            }).then(function(t) {
                                r.payLoading = !1;
                            }).catch(function(t) {
                                console.log(getApp().user.openid, "openidopenidopenidopenidopenidopenidopenidopenidopenidopenidopenidopenidopenidopenid"), 
                                r.payLoading = !1;
                            });
                        } else "confirm" === n ? t.showModal({
                            title: "提示",
                            content: "确认已经收到购买的物品？",
                            confirmColor: "#ff4040",
                            success: function(e) {
                                e.confirm ? (0, i.get)("Order_updOrderStatus", {
                                    order_id: o.order_id,
                                    status: 3,
                                    user_id: getApp().user.userid
                                }).then(function(e) {
                                    t.showToast({
                                        title: "确认成功！"
                                    }), r.orderStatusCur = 4, r.page = 1, r.getPageData();
                                }) : e.cancel && console.log("取消");
                            }
                        }) : "sale" === n ? (this.activeOrder = JSON.parse(JSON.stringify(this.list[e])), 
                        this.activeOrder.goods_item = this.activeOrder.goods_item.map(function(t) {
                            return t.can_comment = !1, t;
                        }), this.refundVisible = !0, this.refundShow = !0, this.refundAnimation = !1) : "group" === n && this.jump({
                            type: "invitation_group",
                            group_no: o.group_no
                        });
                    },
                    orderStatusChange: function(t) {
                        this.orderStatusCur = t, this.page = 1, this.getPageData();
                    },
                    getPageData: function() {
                        var e = this;
                        Promise.all([ 2 == this.orderType ? (0, i.get)("Bargain_getBargainUserList", {
                            user_id: getApp().user.userid,
                            page: this.page,
                            status: -1
                        }) : this.orderType ? (0, i.get)("Order_userOrderList", {
                            user_id: getApp().user.userid,
                            page: this.page,
                            status: -1,
                            order_type: this.orderType
                        }) : (0, i.get)("Order_userOrderList", {
                            user_id: getApp().user.userid,
                            page: this.page,
                            status: this.statusList[this.orderStatusCur].id
                        }) ]).then(function(o) {
                            o = o[0], console.log(o, "订单列表订单列表订单列表订单列表订单列表订单列表订单列表订单列表订单列表订单列表订单列表订单列表"), e.init = !1, 
                            t.hideLoading(), t.stopPullDownRefresh();
                            var i = o.data.map(function(t) {
                                return t.goods_item = t.goods_item.map(function(e) {
                                    return {
                                        title: e.goods_name,
                                        id: e.goods_id,
                                        cate: e.sku_info,
                                        count: e.num,
                                        price: e.goods_price,
                                        image: e.pic_url,
                                        can_comment: !!e.is_comment,
                                        integral: t.integral || 0
                                    };
                                }), t;
                            });
                            e.list = 1 === e.page ? i : e.list.concat(i), i.length < 20 && (e.end = !0);
                        });
                    },
                    goToGoodComment: function(e, o) {
                        var i = this, n = JSON.parse(JSON.stringify(o));
                        delete n.can_comment, this.activeCommentGood = n, this.activeOrder = JSON.parse(JSON.stringify(this.list[e])), 
                        this.activeCommentGood.commentImage = [], this.activeCommentGood.commentContent = "", 
                        this.activeCommentGood.star = 0, t.$on("submitComment", function() {
                            i.page = 1, i.getPageData();
                        }), this.jump({
                            type: "comment",
                            goods: JSON.stringify(this.activeCommentGood),
                            order: JSON.stringify(this.activeOrder)
                        });
                    },
                    appendCommentImage: function() {
                        var e = this;
                        t.chooseImage({
                            count: 5,
                            success: function(o) {
                                var n = o.tempFilePaths;
                                t.showToast({
                                    title: "图片上传中...",
                                    icon: "none"
                                }), Promise.all(n.map(function(t) {
                                    return (0, i.updateFile)("Member_uploadFile", {}, t);
                                })).then(function(o) {
                                    t.showToast({
                                        title: "上传成功！"
                                    }), e.activeCommentGood.commentImage = e.activeCommentGood.commentImage.concat(o.map(function(t) {
                                        return t.info.url;
                                    }));
                                });
                            }
                        });
                    },
                    deleteCommentImage: function(t, e) {
                        this.activeCommentGood.commentImage.splice(e, 1);
                    },
                    publishComment: function() {
                        var e = this;
                        this.activeCommentGood.commentContent ? (0, i.get)("Order_orderComment", {
                            order_id: this.activeOrder.order_id,
                            goods_id: this.activeCommentGood.id,
                            user_id: getApp().user.userid,
                            content: this.activeCommentGood.commentContent,
                            img_group: JSON.stringify(this.activeCommentGood.commentImage)
                        }).then(function(o) {
                            t.showToast({
                                title: "发布成功！"
                            }), e.page = 1, e.getPageData(), e.commentAnimation = !0, setTimeout(function() {
                                e.commentShow = !1, e.$nextTick(function() {
                                    e.commentVisible = !1;
                                });
                            }, 300);
                        }) : t.showToast({
                            title: "请输入评价内容",
                            icon: "none"
                        });
                    },
                    publishRefund: function() {
                        var e = this;
                        this.refundReason ? (0, i.get)("Order_updOrderStatus", {
                            order_id: this.activeOrder.order_id,
                            user_id: getApp().user.userid,
                            status: 4,
                            refund_reason: this.refundReason
                        }).then(function(o) {
                            t.showToast({
                                title: "提交成功！"
                            }), e.page = 1, e.getPageData(), e.refundAnimation = !0, setTimeout(function() {
                                e.refundShow = !1, e.$nextTick(function() {
                                    e.refundVisible = !1;
                                });
                            }, 300);
                        }) : t.showToast({
                            title: "请输入售后信息",
                            icon: "none"
                        });
                    },
                    goToExpress: function(t, e) {
                        this.jump({
                            type: "express",
                            id: e.order_id
                        });
                    },
                    cancelDialog: function(t) {
                        var e = this;
                        this["".concat(t, "Animation")] = !0, setTimeout(function() {
                            e["".concat(t, "Show")] = !1, e.$nextTick(function() {
                                e["".concat(t, "Visible")] = !1;
                            });
                        }, 300);
                    }
                }
            };
            e.default = m;
        }).call(this, o("543d")["default"]);
    },
    "500d": function(t, e, o) {
        "use strict";
        o.r(e);
        var i = o("397a"), n = o("b379");
        for (var r in n) "default" !== r && function(t) {
            o.d(e, t, function() {
                return n[t];
            });
        }(r);
        o("6c44");
        var s = o("2877"), a = Object(s["a"])(n["default"], i["a"], i["b"], !1, null, null, null);
        e["default"] = a.exports;
    },
    "6c44": function(t, e, o) {
        "use strict";
        var i = o("9142"), n = o.n(i);
        n.a;
    },
    9142: function(t, e, o) {},
    b379: function(t, e, o) {
        "use strict";
        o.r(e);
        var i = o("467f"), n = o.n(i);
        for (var r in i) "default" !== r && function(t) {
            o.d(e, t, function() {
                return i[t];
            });
        }(r);
        e["default"] = n.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/mine-order/mine-order-create-component", {
    "yb_shopv2/pages/mine-order/mine-order-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("500d"));
    }
}, [ [ "yb_shopv2/pages/mine-order/mine-order-create-component" ] ] ]);