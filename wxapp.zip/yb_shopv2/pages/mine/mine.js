(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/mine/mine" ], {
    "0d33": function(t, n, i) {
        "use strict";
        i.r(n);
        var e = i("ae5f"), o = i.n(e);
        for (var c in e) "default" !== c && function(t) {
            i.d(n, t, function() {
                return e[t];
            });
        }(c);
        n["default"] = o.a;
    },
    "3c88": function(t, n, i) {
        "use strict";
        var e = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, o = [];
        i.d(n, "a", function() {
            return e;
        }), i.d(n, "b", function() {
            return o;
        });
    },
    "591c": function(t, n, i) {
        "use strict";
        var e = i("bfad"), o = i.n(e);
        o.a;
    },
    "5af1": function(t, n, i) {
        "use strict";
        i.r(n);
        var e = i("3c88"), o = i("0d33");
        for (var c in o) "default" !== c && function(t) {
            i.d(n, t, function() {
                return o[t];
            });
        }(c);
        i("591c");
        var s = i("2877"), r = Object(s["a"])(o["default"], e["a"], e["b"], !1, null, null, null);
        n["default"] = r.exports;
    },
    ae5f: function(t, n, i) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = s(i("c8bc")), o = s(i("3b18")), c = i("b1b6");
            i("21b4");
            function s(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var r = function() {
                return i.e("yb_shopv2/component/CustomPrimaryList").then(i.bind(null, "a6ff"));
            }, a = {
                name: "mine",
                props: {},
                data: function() {
                    return {
                        pageUserInfo: {},
                        page_path: "pages/member/index",
                        defaultAvatar: i("5140"),
                        payCount: 0,
                        deliverCount: 0,
                        takeCount: 0,
                        commentCount: 0,
                        level: {},
                        styleType: "",
                        primaryList: [ {
                            title: "我的收藏",
                            icon: "../../static/icon/icon_mine_36_2.png",
                            style2_icon: "../../static/icon/icon_mine_style2_1.png",
                            link: {
                                type: "collection"
                            }
                        }, {
                            title: "我的优惠券",
                            icon: "../../static/icon/icon_mine_36_3.png",
                            style2_icon: "../../static/icon/icon_mine_style2_2.png",
                            link: {
                                type: "coupon",
                                params: "private"
                            }
                        }, {
                            title: "积分商城",
                            icon: "../../static/icon/integralMall_icon.png",
                            style2_icon: "../../static/icon/icon_mine_style2_12.png",
                            link: {
                                type: "page_integral_mall",
                                params: "private"
                            }
                        }, {
                            title: "分销中心",
                            icon: "../../static/icon/distribution_icon.png",
                            style2_icon: "../../static/icon/icon_mine_style2_5.png",
                            link: {
                                type: "page_distribution",
                                params: "private"
                            }
                        }, {
                            title: "我的拼团",
                            icon: "../../static/icon/icon_mine_36_8.png",
                            style2_icon: "../../static/icon/icon_mine_style2_7.png",
                            link: {
                                type: "mine_order",
                                order_type: 4,
                                title: "我的拼团"
                            }
                        }, {
                            title: "我的砍价",
                            icon: "../../static/icon/icon_mine_36_9.png",
                            style2_icon: "../../static/icon/icon_mine_style2_6.png",
                            link: {
                                type: "mine_order",
                                order_type: 2,
                                title: "我的砍价"
                            }
                        }, {
                            title: "我的秒杀",
                            icon: "../../static/icon/icon_mine_36_10.png",
                            style2_icon: "../../static/icon/icon_mine_style2_8.png",
                            link: {
                                type: "mine_order",
                                order_type: 3,
                                title: "我的秒杀"
                            }
                        }, {
                            title: "我的换购",
                            icon: "../../static/icon/icon_mine_36_11.png",
                            style2_icon: "../../static/icon/icon_mine_style2_4.png",
                            link: {
                                type: "mine_order",
                                order_type: 5,
                                title: "我的换购"
                            }
                        }, {
                            title: "我的评价",
                            icon: "../../static/icon/icon_mine_36_4.png",
                            style2_icon: "../../static/icon/icon_mine_style2_3.png",
                            link: {
                                type: "mine_evaluate"
                            }
                        }, {
                            title: "收货地址",
                            icon: "../../static/icon/icon_mine_36_5.png",
                            style2_icon: "../../static/icon/icon_mine_style2_9.png",
                            link: {
                                type: "address"
                            }
                        }, {
                            title: "联系客服",
                            icon: "../../static/icon/icon_mine_36_6.png",
                            style2_icon: "../../static/icon/icon_mine_style2_10.png",
                            link: {
                                type: "phone",
                                url: getApp().business && getApp().business.phone
                            }
                        }, {
                            title: "关于我们",
                            icon: "../../static/icon/icon_mine_36_7.png",
                            style2_icon: "../../static/icon/icon_mine_style2_11.png",
                            link: {
                                type: "about",
                                detail: JSON.stringify(getApp().business)
                            }
                        } ]
                    };
                },
                mixins: [ e.default, o.default ],
                watch: {
                    userInfo: function(t) {
                        t.id && (this.pageUserInfo = t);
                    }
                },
                computed: {
                    baseList: function() {
                        return [ {
                            title: "我的订单",
                            right: "全部订单",
                            rightStyle: "color: #777",
                            link: {
                                type: "mine_order",
                                tab: 0
                            },
                            children: [ {
                                title: "待付款",
                                icon: "../../static/icon/icon_mine_order_48_1.png",
                                count: this.payCount,
                                link: {
                                    type: "mine_order",
                                    tab: 1
                                }
                            }, {
                                title: "待发货",
                                icon: "../../static/icon/icon_mine_order_48_2.png",
                                count: this.deliverCount,
                                link: {
                                    type: "mine_order",
                                    tab: 2
                                }
                            }, {
                                title: "待收货",
                                icon: "../../static/icon/icon_mine_order_48_3.png",
                                count: this.takeCount,
                                link: {
                                    type: "mine_order",
                                    tab: 3
                                }
                            }, {
                                title: "待评价",
                                icon: "../../static/icon/icon_mine_order_48_5.png",
                                count: this.commentCount,
                                link: {
                                    type: "mine_order",
                                    tab: 4
                                }
                            }, {
                                title: "退款/售后",
                                icon: "../../static/icon/icon_mine_order_48_4.png",
                                link: {
                                    type: "mine_order",
                                    tab: 5
                                }
                            } ]
                        } ];
                    },
                    mineList: function() {
                        if ("style2" === this.styleType) return [ this.baseList, this.primaryList ];
                        for (var t = [], n = JSON.parse(JSON.stringify(this.primaryList || [])), i = 0, e = n.length; i < e; i += 4) t.push(n.slice(i, i + 4));
                        return [ this.baseList ].concat(t);
                    },
                    getGlobalColor: function() {
                        return getApp() && getApp().common.globle.color;
                    }
                },
                components: {
                    CustomPrimaryList: r
                },
                methods: {
                    page_onPullDownRefresh: function() {
                        this.getPageData();
                    },
                    getPageData: function() {
                        var n = this;
                        (0, c.get)("Member_getUserCenter", {
                            user_id: getApp().user.userid
                        }).then(function(i) {
                            t.stopPullDownRefresh(), n.$set(n, "level", i.data.level), n.payCount = i.data.order.pay_count, 
                            n.deliverCount = i.data.order.deliver_count, n.takeCount = i.data.order.take_count, 
                            n.commentCount = i.data.order.comment_count;
                        });
                    },
                    page_onLoad: function(n) {
                        this.title = "个人中心", t.setNavigationBarColor({
                            frontColor: "#ffffff",
                            backgroundColor: getApp() && getApp().common.globle.color.toHexColor()
                        }), this.styleType = 2 === n.type_index ? "style2" : "style1", this.primaryList = n.list ? n.list.filter(function(t) {
                            return !t.hidden;
                        }).map(function(t) {
                            return "phone" === t.link.type ? t.link.url = getApp().business && getApp().business.phone : "about" === t.link.type && (t.link.detail = JSON.stringify(getApp().business)), 
                            t;
                        }) : this.primaryList;
                    },
                    page_onShow: function() {
                        this.pageUserInfo = getApp().user, this.pageUserInfo.userid && this.getPageData();
                    },
                    handlerListClick: function(t, n, i) {
                        0 === t && 0 === i && n && this.jump({
                            type: n
                        });
                    },
                    goToInformation: function() {
                        this.jump({
                            type: "information"
                        });
                    }
                }
            };
            n.default = a;
        }).call(this, i("543d")["default"]);
    },
    bfad: function(t, n, i) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/mine/mine-create-component", {
    "yb_shopv2/pages/mine/mine-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("5af1"));
    }
}, [ [ "yb_shopv2/pages/mine/mine-create-component" ] ] ]);