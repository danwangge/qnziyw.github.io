(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/pages/collection/collection" ], {
    5376: function(e, t, o) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = a(o("c8bc")), i = a(o("3b18")), l = o("b1b6"), c = a(o("ffc5"));
            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var u = function() {
                return Promise.all([ o.e("common/vendor"), o.e("yb_shopv2/module/ModuleGoodList") ]).then(o.bind(null, "47e1"));
            }, r = {
                name: "collection",
                data: function() {
                    return {
                        list: [],
                        page_path: "pages/collection/collection"
                    };
                },
                mixins: [ n.default, i.default, c.default ],
                components: {
                    ModuleGoodList: u
                },
                mounted: function() {
                    this.getPageData();
                },
                methods: {
                    page_onLoad: function(t) {
                        this.title = "我的收藏", e.showLoading({
                            title: "加载中"
                        }), e.setNavigationBarColor({
                            frontColor: "#000000",
                            backgroundColor: "#ffffff"
                        });
                    },
                    getPageData: function() {
                        var t = this;
                        (0, l.get)("Member_userCollectionList", {
                            user_id: getApp().user.userid,
                            page: this.page
                        }).then(function(o) {
                            e.hideLoading(), e.stopPullDownRefresh(), console.log(o.data, "收藏列表收藏列表收藏列表收藏列表收藏列表收藏列表收藏列表收藏列表收藏列表收藏列表收藏列表");
                            var n = o.data.map(function(e) {
                                return {
                                    title: e.goods_name,
                                    id: e.goods_id,
                                    image: e.pic,
                                    price: e.price,
                                    desc: e.promote_word,
                                    collection: e.n
                                };
                            });
                            1 === t.page ? t.list = n : t.list = t.list.concat(n), n.length < 20 && (t.end = !0);
                        });
                    },
                    handlerCollectionDelete: function(t, o) {
                        var n = this;
                        e.showModal({
                            title: "提示",
                            content: "取消收藏该商品？",
                            confirmColor: "#ff4040",
                            success: function(i) {
                                i.confirm ? (0, l.get)("Member_userCollectionEdit", {
                                    user_id: getApp().user.userid,
                                    goods_id: o.id
                                }).then(function(o) {
                                    n.list.splice(t, 1), e.showToast({
                                        title: "取消成功！"
                                    });
                                }) : i.cancel && console.log("取消删除");
                            }
                        });
                    }
                }
            };
            t.default = r;
        }).call(this, o("543d")["default"]);
    },
    "58d2": function(e, t, o) {
        "use strict";
        o.r(t);
        var n = o("e1f8"), i = o("95ce");
        for (var l in i) "default" !== l && function(e) {
            o.d(t, e, function() {
                return i[e];
            });
        }(l);
        var c = o("2877"), a = Object(c["a"])(i["default"], n["a"], n["b"], !1, null, null, null);
        t["default"] = a.exports;
    },
    "95ce": function(e, t, o) {
        "use strict";
        o.r(t);
        var n = o("5376"), i = o.n(n);
        for (var l in n) "default" !== l && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(l);
        t["default"] = i.a;
    },
    e1f8: function(e, t, o) {
        "use strict";
        var n = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, i = [];
        o.d(t, "a", function() {
            return n;
        }), o.d(t, "b", function() {
            return i;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/pages/collection/collection-create-component", {
    "yb_shopv2/pages/collection/collection-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("58d2"));
    }
}, [ [ "yb_shopv2/pages/collection/collection-create-component" ] ] ]);