(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/module/ModuleCategory" ], {
    2882: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = n("b1b6"), o = u(n("c8bc"));
        function u(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var r = function() {
            return n.e("yb_shopv2/component/CustomTabBar").then(n.bind(null, "080c"));
        }, s = function() {
            return Promise.all([ n.e("common/vendor"), n.e("yb_shopv2/module/ModuleGoodList") ]).then(n.bind(null, "47e1"));
        }, a = {
            name: "ModuleCategory",
            props: {
                level: {
                    type: String,
                    default: ""
                },
                styleType: {
                    type: String,
                    default: ""
                },
                sourceList: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                tabbar: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    cur: 0,
                    secondCur: 0,
                    init: !0,
                    page: 1,
                    activeId: 0,
                    goods: []
                };
            },
            mixins: [ o.default ],
            computed: {
                list: function() {
                    return this.recursion(1, 3, 0, this.sourceList, this.goods) || [];
                },
                querySubmitData: function() {
                    return {
                        class_id: this.activeId,
                        page: this.page,
                        page_size: 20,
                        user_id: getApp().user.userid
                    };
                }
            },
            watch: {
                sourceList: function(t) {
                    t.length && (this.init = !0, this.getGoodsFindClass());
                }
            },
            mounted: function() {},
            components: {
                CustomTabBar: r,
                ModuleGoodList: s
            },
            methods: {
                recursion: function(t, e, n, i, o) {
                    var u = this;
                    return i.filter(function(e) {
                        return e.level === t && e.pid === n;
                    }).map(function(n) {
                        return {
                            children: t === e ? [] : u.recursion(t + 1, e, n.id, i, o),
                            id: n.id,
                            sort: n.sort,
                            title: n.cate_name,
                            goods: n.id === u.activeId ? o : []
                        };
                    });
                },
                getGoodsFindClass: function() {
                    var t = this;
                    this.activeId = "level1" === this.level ? this.list[this.cur].id : this.list[this.cur].children[this.secondCur].id, 
                    (0, i.get)("Goods_getGoods", this.querySubmitData).then(function(e) {
                        var n = e.data.map(function(t) {
                            return {
                                id: t.id,
                                image: t.pic,
                                title: t.goods_name,
                                price: t.price,
                                level: t.level
                            };
                        });
                        t.goods = 1 === t.page ? n : t.goods.concat(n);
                    });
                },
                handlerCur: function(t, e) {
                    this[t] = e, this.page = 1, this.getGoodsFindClass();
                },
                handlerModuleScroll: function(t) {
                    this.activeId === t && (this.page++, this.getGoodsFindClass());
                }
            }
        };
        e.default = a;
    },
    "2ede": function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("2882"), o = n.n(i);
        for (var u in i) "default" !== u && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(u);
        e["default"] = o.a;
    },
    "345e": function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("6b68"), o = n("2ede");
        for (var u in o) "default" !== u && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(u);
        n("ee99");
        var r = n("2877"), s = Object(r["a"])(o["default"], i["a"], i["b"], !1, null, null, null);
        e["default"] = s.exports;
    },
    "6b68": function(t, e, n) {
        "use strict";
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, o = [];
        n.d(e, "a", function() {
            return i;
        }), n.d(e, "b", function() {
            return o;
        });
    },
    "91f4": function(t, e, n) {},
    ee99: function(t, e, n) {
        "use strict";
        var i = n("91f4"), o = n.n(i);
        o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/module/ModuleCategory-create-component", {
    "yb_shopv2/module/ModuleCategory-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("345e"));
    }
}, [ [ "yb_shopv2/module/ModuleCategory-create-component" ] ] ]);