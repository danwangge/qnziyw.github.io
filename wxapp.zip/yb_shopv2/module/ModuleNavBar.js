(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/module/ModuleNavBar" ], {
    "0516": function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = r(e("c8bc"));
        function r(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var o = {
            name: "ModuleNavBar",
            props: {
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                size: {
                    type: String,
                    default: ""
                }
            },
            computed: {
                getGlobalColor: function() {
                    return getApp().common.globle.color;
                }
            },
            mixins: [ u.default ],
            methods: {
                navJump: function(t, n) {
                    n.linkType;
                    this.jump(t);
                },
                handlerIconPath: function(t) {
                    return "string" === typeof t ? t.replace(/^\.\.\/\.\./, "") : t;
                }
            }
        };
        n.default = o;
    },
    "6f0d": function(t, n, e) {},
    7757: function(t, n, e) {
        "use strict";
        var u = e("6f0d"), r = e.n(u);
        r.a;
    },
    9627: function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("0516"), r = e.n(u);
        for (var o in u) "default" !== o && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(o);
        n["default"] = r.a;
    },
    be41: function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("f7ed"), r = e("9627");
        for (var o in r) "default" !== o && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(o);
        e("7757");
        var a = e("2877"), l = Object(a["a"])(r["default"], u["a"], u["b"], !1, null, null, null);
        n["default"] = l.exports;
    },
    f7ed: function(t, n, e) {
        "use strict";
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, r = [];
        e.d(n, "a", function() {
            return u;
        }), e.d(n, "b", function() {
            return r;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/module/ModuleNavBar-create-component", {
    "yb_shopv2/module/ModuleNavBar-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("be41"));
    }
}, [ [ "yb_shopv2/module/ModuleNavBar-create-component" ] ] ]);