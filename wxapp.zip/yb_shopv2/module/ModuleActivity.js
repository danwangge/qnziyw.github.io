(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/module/ModuleActivity" ], {
    "00b0": function(t, e, n) {
        "use strict";
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, o = [];
        n.d(e, "a", function() {
            return i;
        }), n.d(e, "b", function() {
            return o;
        });
    },
    "01e9": function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var i = u(n("c8bc")), o = u(n("1981"));
        function u(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var l = function() {
            return n.e("yb_shopv2/component/CustomCountDown").then(n.bind(null, "ad8f"));
        }, r = function() {
            return Promise.all([ n.e("common/vendor"), n.e("yb_shopv2/module/ModuleGoodList") ]).then(n.bind(null, "47e1"));
        }, a = {
            name: "ModuleBargain",
            props: {
                type: {
                    type: String,
                    default: ""
                },
                styleType: {
                    type: [ String, Number ],
                    default: "1"
                },
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                }
            },
            mixins: [ i.default, o.default ],
            data: function() {
                return {
                    activityMap: {
                        diy_bargain: {
                            title: "砍价活动",
                            buttonText: "去砍价",
                            type: "bargain",
                            moreLink: {
                                type: "bargain_list",
                                title: "砍价"
                            }
                        },
                        diy_seckill: {
                            title: "秒杀活动",
                            buttonText: "去秒杀",
                            type: "seckill",
                            moreLink: {
                                type: "seckill_list",
                                title: "秒杀"
                            }
                        },
                        diy_group: {
                            title: "拼团活动",
                            buttonText: "去拼团",
                            type: "group",
                            moreLink: {
                                type: "group_list",
                                title: "拼团"
                            }
                        },
                        diy_integral: {
                            title: "积分换购",
                            type: "integral",
                            buttonText: "",
                            buttonHidden: !0,
                            moreLink: {
                                type: "page_integral_mall",
                                title: "积分商城"
                            }
                        }
                    },
                    styleMap: {
                        1: "style3",
                        2: "style9",
                        3: "style10"
                    }
                };
            },
            computed: {
                listType: function() {
                    return this.activityMap[this.type] && this.activityMap[this.type].type;
                },
                allEndTime: function() {
                    var t = JSON.parse(JSON.stringify(this.list));
                    return t.sort(function(t, e) {
                        return t.end_time - e.end_time;
                    }), 1e3 * t[0].end_time;
                },
                globalColor: function() {
                    return getApp().common.globle.color;
                }
            },
            components: {
                CustomCountDown: l,
                ModuleGoodList: r
            }
        };
        e.default = a;
    },
    "1a89": function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("00b0"), o = n("ce76");
        for (var u in o) "default" !== u && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(u);
        n("9279");
        var l = n("2877"), r = Object(l["a"])(o["default"], i["a"], i["b"], !1, null, null, null);
        e["default"] = r.exports;
    },
    9279: function(t, e, n) {
        "use strict";
        var i = n("c423"), o = n.n(i);
        o.a;
    },
    c423: function(t, e, n) {},
    ce76: function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("01e9"), o = n.n(i);
        for (var u in i) "default" !== u && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(u);
        e["default"] = o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/module/ModuleActivity-create-component", {
    "yb_shopv2/module/ModuleActivity-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("1a89"));
    }
}, [ [ "yb_shopv2/module/ModuleActivity-create-component" ] ] ]);