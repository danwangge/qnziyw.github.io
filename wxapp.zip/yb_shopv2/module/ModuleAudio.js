(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/module/ModuleAudio" ], {
    "04bf": function(t, i, n) {
        "use strict";
        var u = function() {
            var t = this, i = t.$createElement, n = (t._self._c, t._f("formatSecond")(t.time)), u = t._f("formatSecond")(t.allTime);
            t.$mp.data = Object.assign({}, {
                $root: {
                    f0: n,
                    f1: u
                }
            });
        }, o = [];
        n.d(i, "a", function() {
            return u;
        }), n.d(i, "b", function() {
            return o;
        });
    },
    1328: function(t, i, n) {
        "use strict";
        n.r(i);
        var u = n("5fa3"), o = n.n(u);
        for (var a in u) "default" !== a && function(t) {
            n.d(i, t, function() {
                return u[t];
            });
        }(a);
        i["default"] = o.a;
    },
    "5fa3": function(t, i, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var u = o(n("c8bc"));
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            var a = {
                name: "ModuleAudio",
                props: {},
                mixins: [ u.default ],
                data: function() {
                    return {
                        show: !0,
                        current: {
                            poster: "https://img-cdn-qiniu.dcloud.net.cn/uniapp/audio/music.jpg",
                            name: "致爱丽丝",
                            author: "暂无",
                            src: "https://img-cdn-qiniu.dcloud.net.cn/uniapp/audio/music.mp3"
                        },
                        audioAction: {
                            method: "pause"
                        },
                        audio: null,
                        time: 0,
                        allTime: 0,
                        status: 0,
                        interval: null,
                        initAudio: !0
                    };
                },
                filters: {
                    formatSecond: function(t) {
                        var i = Math.floor(t / 60), n = Math.floor(t % 60);
                        return "".concat(i < 10 ? "0" + i : i, ":").concat(n < 10 ? "0" + n : n);
                    }
                },
                mounted: function() {
                    var i = this;
                    this.audio = t.createInnerAudioContext(), wx.setInnerAudioOption ? wx.setInnerAudioOption({
                        obeyMuteSwitch: !1
                    }) : this.audio.obeyMuteSwitch = !1, this.audio.autoplay = !0, this.audio.src = this.item.url, 
                    this.audio.onCanplay(function() {
                        i.audio.duration, setTimeout(function() {
                            i.allTime = i.audio.duration;
                        }, 30);
                    }), this.audio.onTimeUpdate(function() {
                        i.allTime = i.audio.duration;
                    }), this.audio.onPlay(function() {
                        i.status = 1, i.initAudio && (Number(i.item.auto_play) ? i.initAudio = !1 : (i.audio.stop(), 
                        i.initAudio = !1));
                    }), this.audio.onPause(function() {
                        i.status = 2;
                    }), this.audio.onStop(function() {
                        i.status = 0, i.time = 0;
                    }), this.audio.onEnded(function() {
                        i.status = 0, i.time = 0;
                    }), this.interval = setInterval(function() {
                        i.time = Math.ceil(i.audio.currentTime);
                    }, 1050);
                },
                destroyed: function() {
                    this.audio && this.audio.destroy(), clearInterval(this.interval);
                },
                methods: {
                    controlPlay: function() {
                        this.audio && (0 === this.status || 2 === this.status ? this.audio.play() : this.audio.pause());
                    }
                }
            };
            i.default = a;
        }).call(this, n("543d")["default"]);
    },
    "60b9": function(t, i, n) {
        "use strict";
        var u = n("92e2"), o = n.n(u);
        o.a;
    },
    "8cd2": function(t, i, n) {
        "use strict";
        n.r(i);
        var u = n("04bf"), o = n("1328");
        for (var a in o) "default" !== a && function(t) {
            n.d(i, t, function() {
                return o[t];
            });
        }(a);
        n("60b9");
        var e = n("2877"), d = Object(e["a"])(o["default"], u["a"], u["b"], !1, null, null, null);
        i["default"] = d.exports;
    },
    "92e2": function(t, i, n) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/module/ModuleAudio-create-component", {
    "yb_shopv2/module/ModuleAudio-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("8cd2"));
    }
}, [ [ "yb_shopv2/module/ModuleAudio-create-component" ] ] ]);