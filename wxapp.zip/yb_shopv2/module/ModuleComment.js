(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_shopv2/module/ModuleComment" ], {
    "298a": function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("4cd4"), o = e("7263");
        for (var r in o) "default" !== r && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(r);
        e("46ea");
        var a = e("2877"), l = Object(a["a"])(o["default"], u["a"], u["b"], !1, null, null, null);
        t["default"] = l.exports;
    },
    "46ea": function(n, t, e) {
        "use strict";
        var u = e("4d24"), o = e.n(u);
        o.a;
    },
    "4cd4": function(n, t, e) {
        "use strict";
        var u = function() {
            var n = this, t = n.$createElement;
            n._self._c;
        }, o = [];
        e.d(t, "a", function() {
            return u;
        }), e.d(t, "b", function() {
            return o;
        });
    },
    "4d24": function(n, t, e) {},
    7263: function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("c163"), o = e.n(u);
        for (var r in u) "default" !== r && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(r);
        t["default"] = o.a;
    },
    c163: function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = o(e("c8bc"));
        function o(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }
        var r = function() {
            return Promise.all([ e.e("common/vendor"), e.e("yb_shopv2/module/ModuleGoodList") ]).then(e.bind(null, "47e1"));
        }, a = function() {
            return e.e("yb_shopv2/component/CustomStar").then(e.bind(null, "98c8"));
        }, l = {
            name: "ModuleComment",
            props: {
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                }
            },
            data: function() {
                return {
                    defaultAvatar: e("5140")
                };
            },
            mounted: function() {
                var n = this;
                setInterval(function() {
                    console.log(n.list);
                }, 2e3);
            },
            mixins: [ u.default ],
            components: {
                ModuleGoodList: r,
                CustomStar: a
            }
        };
        t.default = l;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "yb_shopv2/module/ModuleComment-create-component", {
    "yb_shopv2/module/ModuleComment-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("298a"));
    }
}, [ [ "yb_shopv2/module/ModuleComment-create-component" ] ] ]);