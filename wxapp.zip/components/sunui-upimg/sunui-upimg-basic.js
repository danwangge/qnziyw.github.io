(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/sunui-upimg/sunui-upimg-basic" ], {
    "063a": function(t, e, n) {},
    "0c29": function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var u = r(n("a34a"));
            function r(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function a(t, e, n, u, r, a, i) {
                try {
                    var o = t[a](i), c = o.value;
                } catch (l) {
                    return void n(l);
                }
                o.done ? e(c) : Promise.resolve(c).then(u, r);
            }
            function i(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(u, r) {
                        var i = t.apply(e, n);
                        function o(t) {
                            a(i, u, r, o, c, "next", t);
                        }
                        function c(t) {
                            a(i, u, r, o, c, "throw", t);
                        }
                        o(void 0);
                    });
                };
            }
            var o = {
                data: function() {
                    return {
                        upload_after_list: [],
                        upload_picture_list: [],
                        upload_after_length: 0
                    };
                },
                name: "sunui-upimg",
                props: {
                    upImgConfig: {
                        type: Object,
                        default: function() {
                            var t = getApp().siteInfo, e = getApp().platForm, n = t.siteroot + "?i=" + t.uniacid + "&v=" + t.version + "&from=wxapp&c=entry&a=wxapp&do=index_uploadFile&path=services&m=yb_guanwang&platForm=" + e + "&sign=5201314";
                            return {
                                basicConfig: {
                                    url: n
                                },
                                notli: !0,
                                sourceType: "all",
                                sizeType: !0,
                                upBgColor: "#f9f9f9",
                                upIconColor: "#333333",
                                delBtnLocation: "",
                                isAddImage: !1,
                                iconReplace: ""
                            };
                        }
                    },
                    upImgId: {
                        type: String,
                        default: "feil_1"
                    },
                    upImgCount: {
                        type: Number,
                        default: 9
                    }
                },
                created: function() {},
                methods: {
                    initServerImage: function(t) {
                        this.upload_picture_list = t;
                    },
                    chooseImage: function(t) {
                        _(this, parseInt(t), this.upImgConfig);
                    },
                    uploadimage: function(t) {
                        p(this, t);
                    },
                    deleteImg: function(t) {
                        f(t, this);
                    },
                    previewImg: function(t) {
                        g(t, this);
                    },
                    previewImgs: function(t) {
                        m(t, this);
                    },
                    deleteAllImgs: function() {
                        d(this);
                    }
                }
            };
            e.default = o;
            var c = function(e, n, u, r, a) {
                0 == n.code ? (console.log("%c 后端上传(成功返回地址):".concat(n.info), "color:#1AAD19"), 
                r[a]["path_server"] = n.info.url, e.upload_picture_list = r, e.upload_picture_list[a].upload_percent = 100, 
                s(e, r, u.count), t.hideLoading()) : (t.showLoading({
                    title: "上传失败!"
                }), e.upload_picture_list = [], e.upload_after_list = [], e.upload_after_length = 0, 
                setTimeout(function() {
                    t.hideLoading();
                }, 2e3));
            }, l = function() {
                var e = i(u.default.mark(function e(n, r, a, o) {
                    var l;
                    return u.default.wrap(function(e) {
                        while (1) switch (e.prev = e.next) {
                          case 0:
                            return l = {
                                url: r.basicConfig.url || ""
                            }, e.next = 3, t.uploadFile({
                                url: l.url,
                                filePath: a[o]["path"],
                                name: "file_upload",
                                formData: {},
                                header: {
                                    "content-type": "application/json"
                                },
                                success: function() {
                                    var t = i(u.default.mark(function t(e) {
                                        var i;
                                        return u.default.wrap(function(t) {
                                            while (1) switch (t.prev = t.next) {
                                              case 0:
                                                if (200 != e.statusCode) {
                                                    t.next = 8;
                                                    break;
                                                }
                                                if (i = e.data.info ? e.data : JSON.parse(e.data), !e.data.info) {
                                                    t.next = 6;
                                                    break;
                                                }
                                                c(n, i, r, a, o), t.next = 8;
                                                break;

                                              case 6:
                                                return t.next = 8, getApp().Req.uploadImage("Chat_msgUpload", {}, a[o]["path"], function(t) {
                                                    i.info.url = t.url, c(n, i, r, a, o);
                                                });

                                              case 8:
                                              case "end":
                                                return t.stop();
                                            }
                                        }, t, this);
                                    }));
                                    function e(e) {
                                        return t.apply(this, arguments);
                                    }
                                    return e;
                                }()
                            });

                          case 3:
                            e.sent;

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t, n, u, r) {
                    return e.apply(this, arguments);
                };
            }(), s = function() {
                var t = i(u.default.mark(function t(e, n, r) {
                    return u.default.wrap(function(t) {
                        while (1) switch (t.prev = t.next) {
                          case 0:
                            return t.next = 2, e.$emit("onUpImg", e.upload_picture_list, e.upImgId);

                          case 2:
                          case "end":
                            return t.stop();
                        }
                    }, t, this);
                }));
                return function(e, n, u) {
                    return t.apply(this, arguments);
                };
            }(), p = function() {
                var t = i(u.default.mark(function t(e, n) {
                    var r, a;
                    return u.default.wrap(function(t) {
                        while (1) switch (t.prev = t.next) {
                          case 0:
                            r = 0, a = e.upload_picture_list.length;

                          case 1:
                            if (!(r < a)) {
                                t.next = 8;
                                break;
                            }
                            if (0 != e.upload_picture_list[r]["upload_percent"]) {
                                t.next = 5;
                                break;
                            }
                            return t.next = 5, l(e, n, e.upload_picture_list, r);

                          case 5:
                            r++, t.next = 1;
                            break;

                          case 8:
                          case "end":
                            return t.stop();
                        }
                    }, t, this);
                }));
                return function(e, n) {
                    return t.apply(this, arguments);
                };
            }(), f = function() {
                var t = i(u.default.mark(function t(e, n) {
                    return u.default.wrap(function(t) {
                        while (1) switch (t.prev = t.next) {
                          case 0:
                            return t.next = 2, n.$emit("onImgDel", {
                                url: e.currentTarget.dataset.url,
                                index: e.currentTarget.dataset.index,
                                upImgId: n.upImgId
                            });

                          case 2:
                            n.upload_picture_list.splice(e.currentTarget.dataset.index, 1), n.upload_after_list.splice(e.currentTarget.dataset.index, 1), 
                            n.upload_after_length = n.upload_after_list.length, n.upload_picture_list = n.upload_picture_list;

                          case 6:
                          case "end":
                            return t.stop();
                        }
                    }, t, this);
                }));
                return function(e, n) {
                    return t.apply(this, arguments);
                };
            }(), d = function() {
                var t = i(u.default.mark(function t(e) {
                    return u.default.wrap(function(t) {
                        while (1) switch (t.prev = t.next) {
                          case 0:
                            e.upload_picture_list = [], e.upload_after_list, e.upload_picture_list = e.upload_picture_list;

                          case 3:
                          case "end":
                            return t.stop();
                        }
                    }, t, this);
                }));
                return function(e) {
                    return t.apply(this, arguments);
                };
            }(), _ = function(e, n, r) {
                var a = {
                    basicConfig: {
                        url: r.basicConfig.url
                    },
                    count: n,
                    notli: r.notli,
                    sourceType: r.sourceType,
                    sizeType: r.sizeType,
                    tips: r.tips || !1
                };
                t.chooseImage({
                    count: 0 == e.upload_after_list.length ? a.count : a.count - e.upload_after_list.length,
                    sizeType: "" == a.sizeType || void 0 == a.sizeType || 1 == a.sizeType ? [ "compressed" ] : [ "original" ],
                    sourceType: "" == a.sourceType || void 0 == a.sourceType ? [ "album", "camera" ] : "camera" == a.sourceType ? [ "camera" ] : "album" == a.sourceType ? [ "album" ] : [ "album", "camera" ],
                    success: function() {
                        var t = i(u.default.mark(function t(n) {
                            var r, i;
                            return u.default.wrap(function(t) {
                                while (1) switch (t.prev = t.next) {
                                  case 0:
                                    for (r = 0, i = n.tempFiles.length; r < i; r++) n.tempFiles[r]["upload_percent"] = 0, 
                                    n.tempFiles[r]["path_server"] = "", e.upload_picture_list.push(n.tempFiles[r]), 
                                    e.upload_picture_list.length > a.count && (e.upload_picture_list = e.upload_picture_list.slice(0, a.count));
                                    return t.next = 3, h(e, n, a);

                                  case 3:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        function n(e) {
                            return t.apply(this, arguments);
                        }
                        return n;
                    }()
                });
            }, h = function(t, e, n) {
                !n.notli && n.count == t.upload_picture_list.length && p(t, n), n.notli && p(t, n), 
                t.upload_after_list = t.upload_after_list.concat(e.tempFilePaths).slice(0, n.count), 
                t.upload_after_length = t.upload_after_list.length, t.upload_picture_list = t.upload_picture_list.slice(0, n.count);
            }, g = function(e, n) {
                t.previewImage({
                    current: n.upload_after_list[e.currentTarget.dataset.index],
                    urls: n.upload_after_list
                });
            }, m = function() {
                var e = i(u.default.mark(function e(n, r) {
                    var a, i, o;
                    return u.default.wrap(function(e) {
                        while (1) switch (e.prev = e.next) {
                          case 0:
                            for (a = [], i = 0, o = r.upload_picture_list.length; i < o; i++) a.push(r.upload_picture_list[i].path_server);
                            t.previewImage({
                                current: n.currentTarget.dataset.src,
                                urls: a
                            });

                          case 3:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t, n) {
                    return e.apply(this, arguments);
                };
            }();
        }).call(this, n("543d")["default"]);
    },
    "7efb": function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("e2cd"), r = n("9794");
        for (var a in r) "default" !== a && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(a);
        n("a83f");
        var i = n("2877"), o = Object(i["a"])(r["default"], u["a"], u["b"], !1, null, "355ac6c8", null);
        e["default"] = o.exports;
    },
    9794: function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("0c29"), r = n.n(u);
        for (var a in u) "default" !== a && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(a);
        e["default"] = r.a;
    },
    a83f: function(t, e, n) {
        "use strict";
        var u = n("063a"), r = n.n(u);
        r.a;
    },
    e2cd: function(t, e, n) {
        "use strict";
        var u = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, r = [];
        n.d(e, "a", function() {
            return u;
        }), n.d(e, "b", function() {
            return r;
        });
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/sunui-upimg/sunui-upimg-basic-create-component", {
    "components/sunui-upimg/sunui-upimg-basic-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("7efb"));
    }
}, [ [ "components/sunui-upimg/sunui-upimg-basic-create-component" ] ] ]);