(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/sl-filter/popup-layer" ], {
    "2fb0": function(t, a, n) {
        "use strict";
        var e = n("6208"), o = n.n(e);
        o.a;
    },
    4513: function(t, a, n) {
        "use strict";
        n.r(a);
        var e = n("df97"), o = n.n(e);
        for (var r in e) "default" !== r && function(t) {
            n.d(a, t, function() {
                return e[t];
            });
        }(r);
        a["default"] = o.a;
    },
    "4ff1": function(t, a, n) {
        "use strict";
        n.r(a);
        var e = n("7d3e"), o = n("4513");
        for (var r in o) "default" !== r && function(t) {
            n.d(a, t, function() {
                return o[t];
            });
        }(r);
        n("2fb0");
        var i = n("2877"), s = Object(i["a"])(o["default"], e["a"], e["b"], !1, null, null, null);
        a["default"] = s.exports;
    },
    6208: function(t, a, n) {},
    "7d3e": function(t, a, n) {
        "use strict";
        var e = function() {
            var t = this, a = t.$createElement;
            t._self._c;
        }, o = [];
        n.d(a, "a", function() {
            return e;
        }), n.d(a, "b", function() {
            return o;
        });
    },
    df97: function(t, a, n) {
        "use strict";
        Object.defineProperty(a, "__esModule", {
            value: !0
        }), a.default = void 0;
        var e = {
            name: "popup-layer",
            props: {
                direction: {
                    type: String,
                    default: "top"
                },
                autoClose: {
                    type: Boolean,
                    default: !0
                },
                isTransNav: {
                    type: Boolean,
                    default: !1
                },
                navHeight: {
                    type: Number,
                    default: 0
                }
            },
            data: function() {
                return {
                    ifshow: !1,
                    translateValue: -100,
                    timer: null,
                    iftoggle: !1
                };
            },
            computed: {
                _translate: function() {
                    if (this.isTransNav) {
                        var t = {
                            top: "transform:translateY(".concat(-this.translateValue, "%)"),
                            bottom: "transform:translateY(calc(".concat(this.translateValue, "% + ").concat(this.navHeight, "px))"),
                            left: "transform:translateX(".concat(-this.translateValue, "%)"),
                            right: "transform:translateX(".concat(this.translateValue, "%)")
                        };
                        return t[this.direction];
                    }
                    var a = {
                        top: "transform:translateY(".concat(-this.translateValue, "%)"),
                        bottom: "transform:translateY(".concat(this.translateValue, "%)"),
                        left: "transform:translateX(".concat(-this.translateValue, "%)"),
                        right: "transform:translateX(".concat(this.translateValue, "%)")
                    };
                    return a[this.direction];
                },
                _location: function() {
                    var t = {
                        top: "bottom:0px;width:100%;",
                        bottom: "top:0px;width:100%;",
                        left: "right:0px;height:100%;",
                        right: "left:0px;height:100%;"
                    };
                    return t[this.direction] + this._translate;
                }
            },
            methods: {
                show: function() {
                    var t = this;
                    this.ifshow = !0;
                    setTimeout(function() {
                        t.translateValue = 0, null;
                    }, 100), setTimeout(function() {
                        t.iftoggle = !0, null;
                    }, 300);
                },
                close: function() {
                    var t = this;
                    null === this.timer && this.iftoggle && (this.translateValue = -100 - this.navHeight, 
                    this.timer = setTimeout(function() {
                        t.ifshow = !1, t.timer = null, t.iftoggle = !1;
                    }, 300), this.$emit("close"));
                },
                ableClose: function() {
                    this.autoClose && this.close();
                },
                stopEvent: function(t) {}
            }
        };
        a.default = e;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/sl-filter/popup-layer-create-component", {
    "components/sl-filter/popup-layer-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("4ff1"));
    }
}, [ [ "components/sl-filter/popup-layer-create-component" ] ] ]);