module.exports = {
    name: "yb_shopv2",
    uniacid: "5",
    version: "1.0.0",
    siteroot: "https://wx.fsfqcm.com/app/index.php",
    native_tabbar: false
};